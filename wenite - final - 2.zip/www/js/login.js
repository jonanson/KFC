
/*********************** VARIABLES ****************************/

var username_value;
var password_value;
var sessionKey;
var user_id;
var myAlertURL;
var url_menu = "../www/mainMenu.html";


$(document).ready(function() {
    app.initialize();
    //backbutton management:closeApp();
    document.addEventListener("backbutton", function(e) {
        e.preventDefault();
        navigator.app.exitApp();
    }, false);
});

/*********************** FUNCTIONS ****************************/

/**
*
*This function sends the parameters to the server and deals with the response, letting the user log in or not.
*
*@username      - The value of the username field.
*
*@pass          - The value of the password field.
*
*@idPlace       - The id of the place to log in.
*
**/
function login(username, pass, idPlace) {
	overlay_on();
    encrypt(pass,idPlace,function(encryptedPassword){       /* Encripts the password */

        getLoginResponse(username, encryptedPassword, idPlace, function(weNightLoginResponse){  /* Sending the parameters*/
            var mostrar;
            var type = weNightLoginResponse.returnMessage.type;     

            if (weNightLoginResponse.userSession == undefined ){
                mostrar = weNightLoginResponse.returnMessage.message;
            }else{
                
                mostrar = weNightLoginResponse.returnMessage.message;

                sessionKey = weNightLoginResponse.userSession.sessionKey;
                user_id = weNightLoginResponse.userSession.idUser;
                
            }
                        
            if(type == 1){      /* If the response is affirmative, we set the sessionkey in the session storage */
                                /* We also create an alert with the message received from the server */
                setUservars();
                //app.initialize();
                //app.sendToken(user_id);
                window.location = 'mainMenu.html';

            }else{              /* If the response is negative, we create an alert message received from the server */
                                                         
                createSNAlert(mostrar, "red", "fade", "none"); 
            }
            overlay_off();
        });

    });

}

/**
*
*This function gets the values of the username and password and calls the login function.
*
**/
function loginAction(){
        
    username_value = document.getElementById("usernameField").value;
    
    password_value = document.getElementById("passwordField").value;
    
    login(username_value, password_value, 0);
}


/*
*
*
*
*/
function setUservars(){
    
    window.sessionStorage.setItem("username", username_value);
    window.sessionStorage.setItem("idUser", user_id);
    window.sessionStorage.setItem("sessionKey", sessionKey);

    
    
}

