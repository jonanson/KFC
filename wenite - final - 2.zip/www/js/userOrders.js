var idUser = window.sessionStorage.getItem("idUser");
var username = window.sessionStorage.getItem("username");
var myCart = [];
var opened = false;
var selectedTab;
var historic_user_orders = null;

/** ********************* FUNCTIONS *************************** */
app_push_orders.initialize();

$(document).ready(
		function() {
			completeInfoSideNav();
			if (JSON.parse(sessionStorage.getItem("myCart")) != null) {
				myCart = JSON.parse(sessionStorage.getItem("myCart"));
				if (myCart.length > 0) {
					setCartImage(true);

				} else {
					setCartImage(false);
				}

			} else {
				myCart = [];
				setCartImage(false);
			}
			var token = window.sessionStorage.getItem("pushToken");
			// we save teh origin for coming back
			if (sessionStorage.getItem("originPage") != null) {
				window.sessionStorage.removeItem("originPage");
			}
			if (window.sessionStorage.getItem("historic_user_orders") != null) {
				historic_user_orders = window.sessionStorage
						.getItem("historic_user_orders");
			}
			;
			window.sessionStorage.setItem("originPage", "userOrders.html");
			penddingOrders(function() {
				changeTab("historial");
			});

			// backbutton management: set app to background run
			document.addEventListener("backbutton", function(e) {
				e.preventDefault();
				window.location.href = "mainMenu.html";
			}, false);

		});
/*
 * This function changes the sidebar's width for it to open to the user.
 * 
 */
function openNav() {
	opened = true;
	document.getElementById("mySidenav").style.width = "70%";
	document.getElementById("mySidenav").style.border = "solid 2px #14143A";
}

/*
 * This function changes the sidebar's width for it to close to the user.
 * 
 */
function closeNav() {
	opened = false;
	document.getElementById("mySidenav").style.width = "0";
	document.getElementById("mySidenav").style.border = "none";
}

function openOrCloseNav() {
	if (opened == true) {
		closeNav();
	} else {
		openNav();
	}
}

function completeInfoSideNav() {

	var divUser = document.createElement("div");
	divUser.setAttribute("id", "userNameDiv");

	var userImg = document.createElement("img");
	userImg.setAttribute("class", "button_save_changes btn");
	userImg.setAttribute("id", "userImg");
	userImg.setAttribute("style", "width:30%;height: 30%;float:left");
	userImg.setAttribute("src", "./img/loguser_icon.png");
	// document.getElementById("link0").appendChild(userImg);

	document.getElementById("link0").appendChild(divUser);
	document.getElementById("userNameDiv").innerHTML = username;

}

function go_toCart() {

	var temp_item = JSON.parse(sessionStorage.getItem("temp_item"));
	var myCart = [];
	if (sessionStorage.getItem("myCart") != null) {
		myCart = JSON.parse(sessionStorage.getItem("myCart"));
	}

	if (temp_item != null) {

		myCart.push(temp_item);
		window.sessionStorage.setItem("myCart", JSON.stringify(myCart));

	}

	window.location.href = "cart.html";

}

function createRow(order, callback) {

	// getOrderDrinksResponse(order.id, function(weNightListResponse) {
	// var drinks = weNightListResponse.drinks;
	// $("#ordersTable").find('tbody').append(
	// $('<tr>').attr('id', 'row_' + order.id).attr('class',
	// 'row_title')
	//
	// .append(
	// $('<td>').attr('class', 'row_title_txt').text(
	// 'Pedido del ' + order.placementDate)).append(
	// $('<td>').attr('class', 'row_title_opt').attr(
	// 'onclick',
	// 'reOrder("' + order.orderPrice + '","'
	// + order.id + '");').append(
	// $('<input>').attr('type', 'image').attr('src',
	// './img/icons/reorder.png').attr(
	// 'class', 'row_title_opt_img'))));

	getOrderDrinksResponse(order.id, function(weNightListResponse) {
		var drinks = weNightListResponse.drinks;
		$("#ordersTable").find('tbody').append(
				$('<tr>').attr('id', 'row_' + order.id).attr('class',
						'row_title')

				.append(
						$('<td>').attr('class', 'row_title_txt').text(
								'Pedido del ' + order.placementDate)).append(
						$('<td>').attr('class', 'row_title_opt')));

		var sel_info_opt_col = document.createElement("div");
		sel_info_opt_col.setAttribute("id", "sel_info_opt_col" + order.id);
		sel_info_opt_col.className = "col-xs-4 col-sm-4 sel_info_opt_col";
		document.getElementById('row_' + order.id)
				.appendChild(sel_info_opt_col);
		create_optAreas(order.id);
		populate_optAreas(order.id);
		action_animateOpts(order.id);

		var drinksNumber = 0;
		if(drinks != undefined) {
			drinksNumber = drinks.length;
		}
		var y;

		for (y = 0; y < drinksNumber; y++) {
			var drink = drinks[y];
			$("#ordersTable").find('tbody').append(
					$('<tr>').attr('class', 'row_content').text(
							' - ' + drink.description));
		}// for
		$("#ordersTable").find('tbody').append(
				$('<tr>').attr('class', 'row_content').append(
						$('<div>').attr('class', 'price_order').text(
								'Precio total: ' + order.orderPrice + ' €')));
		$("#ordersTable").find('tbody').append($('</br>'));
		overlay_off();
	});
	callback();
}

function reOrder(orderPrice, orderId) {

	if (sessionStorage.getItem("subtotal") != null) {
		window.sessionStorage.removeItem("subtotal");
	}
	window.sessionStorage.setItem("subtotal", orderPrice);

	if (sessionStorage.getItem("reOrderId") != null) {
		window.sessionStorage.removeItem("reOrderId");
	}
	window.sessionStorage.setItem("reOrderId", orderId);

	window.location.href = "checkout.html";
}

function changeTab(tab) {

	// document.getElementById("bodyforms").innerHTML = "";
	currentRow = 0;
	document.getElementsByClassName("row_title").remove();
	document.getElementsByClassName("row_content").remove();

	if (tab == "favoritos") {

		// document.getElementById("toggle_data").disabled = false;
		document.getElementById("toggle_hist").className = "tablinks";
		document.getElementById("toggle_fav").className = "selected_tablinks";

		createFavTab();
		selectedTab = "favoritos";

	} else if (tab == "historial") {

		document.getElementById("toggle_fav").className = "tablinks";
		document.getElementById("toggle_hist").className = "selected_tablinks";
		createHistTab();
		selectedTab = "historial";

	}
}

function createFavTab() {
	overlay_on();

	getVipOrdersOfUserResponse(idUser, 0, function(weNightListResponse) {

		var orders = weNightListResponse.orders;
		// window.sessionStorage.setItem("historic_user_orders", orders);
		var x;
		var length = 0;
		if(orders!=undefined) {
			length = orders.length;

		} else {
			overlay_off();
		}
		for (x = 0; x < length; x++) {
			var order = orders[x];
			createRow(order, function() {

			});
		}
	});
}

function createHistTab() {

	/*
	 * if (historic_user_orders != null && historic_user_orders!= undefined &&
	 * historic_user_orders!="undefined") { overlay_on(); var length =
	 * historic_user_orders.length; for (x = 0; x < length; x++) { var drinks;
	 * var order = historic_user_orders[x]; createRow(order, function() {
	 * 
	 * }); } overlay_off(); } else {
	 */
	overlay_on();

	getUserOrdersAtPlaceResponse(idUser, 0, function(weNightListResponse) {

		var orders = weNightListResponse.orders;
		// window.sessionStorage.setItem("historic_user_orders", orders);
		var x;
		var length = 0;
		if(orders!=undefined) {
			length = orders.length;

		}

		for (x = 0; x < length; x++) {
			var order = orders[x];
			createRow(order, function() {

			});
		}
	});
	// }

}

function penddingOrders(callback) {

	overlay_on();
	getUserNotAttendedOrdersResponse(idUser, 0, function(weNightListResponse) {
		var orders = weNightListResponse.orders;
		// window.sessionStorage.setItem("historic_user_orders", orders);
		var x;
		var title;
		var descriptions = [];
		var color;
		var clas="notes";
		var length = 0;
		if(orders!=undefined) {
			length = orders.length;

		}
		if (length != null && length != undefined && "undefined" != length
				&& length > 0) {
			var order = orders[0];
			if (order.attending == "1" && order.attended == "0") {
				title = 'Pedido en curso!';
				clas = "notes_in_progress";
			} else if (order.attending == "0" && order.attended == "1") {
				title = 'Pedido preparado!';
				clas = "notes_attended";
			}  else {
				title = 'Pedido recibido';
			}
			getOrderDrinksResponse(order.id, function(weNightListResponse) {
				var drinks = weNightListResponse.drinks;
				var drinksNumber = drinks.length;
				var y;

				for (y = 0; y < drinksNumber; y++) {
					var drink = drinks[y];
					descriptions[y] = drink.description;
				}
				paintPenddingOrder(title, clas, descriptions);
				overlay_off();
				callback();
			});

		} else {
			document.getElementById("notes").style.display = "none";
			callback();
		}
	});
}

function paintPenddingOrder(title, clas, descriptions) {

	document.getElementById("notes").style.display = "block";
	$("#notes").attr('class', clas);
	$("#notes_title").text(title);
	var desc = "Tu pedido de: "
	for (var x = 0; x < descriptions.length; x++) {
		if (x == 0) {
			desc = desc + " " + descriptions[x] + ", ";
		} else {
			desc = desc + ", " + descriptions[x];
		}
	}
	if (clas == "notes_attended") {
		desc = desc + " está listo y esperándote";
	} else if(clas == "notes_in_progress"){
		desc = desc + " está preparándose en este momento";
	} else {
		desc = desc + " ha sido recibido, en seguida nos ponemos manos a la obra";
	}
	$("#notes_descriptions").text(desc);
}

function create_optAreas(rowNumber) {

	var h_toggle = document.createElement("div");
	var h_optDelete = document.createElement("div");
	var h_optEdit = document.createElement("div");

	h_toggle.className = "h_toggle";
	h_toggle.setAttribute("id", "h_toggle" + rowNumber);

	h_optDelete.className = "h_optDelete";
	h_optDelete.setAttribute("id", "h_optDelete" + rowNumber);

	h_optEdit.className = "h_optEdit";
	h_optEdit.setAttribute("id", "h_optEdit" + rowNumber);

	document.getElementById("sel_info_opt_col" + rowNumber).appendChild(
			h_optDelete);
	document.getElementById("sel_info_opt_col" + rowNumber).appendChild(
			h_optEdit);
	document.getElementById("sel_info_opt_col" + rowNumber).appendChild(
			h_toggle);

}

function populate_optAreas(rowNumber) {

	var opt_main = document.createElement("input");
	var opt_aux1 = document.createElement("input");
	var opt_aux2 = document.createElement("input");

	opt_main.setAttribute("id", "opt_main" + rowNumber);
	opt_main.className = "opt_main";
	opt_main.setAttribute("type", "image");
	opt_main.setAttribute("src", "./img/opt_dots_light.png");

	opt_aux1.setAttribute("id", "opt_aux1" + rowNumber);
	opt_aux1.className = "opt_aux1";
	opt_aux1.setAttribute("type", "image");
	opt_aux1.setAttribute("src", "./img/cancelIcon.png");

	opt_aux2.setAttribute("id", "opt_aux2" + rowNumber);
	opt_aux2.className = "opt_aux2";
	opt_aux2.setAttribute("type", "image");
	opt_aux2.setAttribute("src", "./img/fav.png");

	document.getElementById("h_toggle" + rowNumber).appendChild(opt_main);
	document.getElementById("h_optDelete" + rowNumber).appendChild(opt_aux1);
	document.getElementById("h_optEdit" + rowNumber).appendChild(opt_aux2);

}
function action_animateOpts(rowNumber) {

	document.getElementById("opt_main" + rowNumber).onclick = function() {

		$('#h_optDelete' + rowNumber).animate({
			width : 'toggle'
		});
		$('#h_optEdit' + rowNumber).animate({
			width : 'toggle'
		});

	}

	document.getElementById("opt_aux1" + rowNumber).onclick = function() {

		// delete
		delete_card(rowNumber);

	}
	document.getElementById("opt_aux2" + rowNumber).onclick = function() {

		// set default
		defcard = rowNumber;
		defaultCardHasChanged = true;
		isNewCard = false;
		deSelect_cards(defcard);

	}

}
