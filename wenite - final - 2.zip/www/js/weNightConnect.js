var host = "http://151.80.149.226:8080/weNight";
//var host = "http://localhost:8080/WeNight";
var bartenderService = "services/BartenderService";
var productService  = "services/ProductService";
var userService = "services/UserService";
var orderService = "services/OrderService";
var chatService = "services/ChatService";
var placeConnectionService = "services/PlaceConnectionService";
var signUpUserWS = "signUpUser";
var getUserWS = "getUser";
var getDrinkTypesWS = "getDrinkTypes";
var getDrinkBrandsWS = "getDrinkBrands";
var getDrinkSubtypesWS = "getDrinkSubtypes";
var getDrinkHowsWS = "getDrinkHows";
var getDrinkHowPlusesWS = "getDrinkHowPluses";
var getDrinkHowPluses2WS = "getDrinkHowPluses2";
var getDrinkGarnishesWS = "getDrinkGarnishes";

var getDrinkTypeByIdWS = "getDrinkTypeById";
var getDrinkBrandByIdWS = "getDrinkBrandById";
var getDrinkSubtypeByIdWS = "getDrinkSubTypeById";
var getDrinkHowByIdWS = "getDrinkHowById";
var getDrinkHowPlusByIdWS = "getDrinkHowPlusById";
var getDrinkHowPlus2ByIdWS = "getDrinkHowPlus2ById";
var getDrinkGarnishByIdWS = "getDrinkGarnishById";

var getNonAttendedUserOrdersWS = "getNonAttendedUserOrders";

var getAttendedUserOrdersWS = "getAttendedUserOrders";
var getAttendingUserOrdersWS = "getAttendingUserOrders";
var getUserOrdersAtPlaceWS = "getUserOrdersAtPlace";

var getVipOrdersOfUserWS = "getVipOrdersOfUser";

var getOrderedDrinksWS = "getOrderDrinks";

var getPlaceConfigWS = "getPlaceConfig";
var loginWS = "logIn";
var logoutWS = "logOut";
var placeOrderWS = "placeOrder";
var placeReOrderWS = "placeReOrder";

var setUserDevicePushTokenWS  = "setUserDevicePushToken";
var setUserVisibilityWS  = "setUserVisibility";
var setUserDescriptionWS  = "setUserDescription";
var setUserImageLocalPathWS  = "setUserImageLocalPath";
var setUserDefaultCardWS  = "setUserDefaultCreditCard";

var getUserCardsWS = "getUserCreditCards";
var addCreditCardWS = "addCreditCard";
var deleteCreditCardWS  = "deleteCreditCard"
var SendChatPushNotificationPathWS = "sendChatMessage";

var setOrderAsVipWS  = "setOrderAsVip";
var setOrderAsNoVipWS  = "setOrderAsNoVip";

function getWeNightResponse(url, callback) {

	$.ajax({
	
		dataType: 'xml',
		headers: {
			Accept:"application/xml",
			"Access-Control-Allow-Origin": "*"
		},
		type:'GET',
		url:url,
		success: function(data) { 
			
			var rMessage;	
			var rObject;
			
			if(data.children[0].children[1] == undefined) {
				rMessage = data.children[0].children[0];
			} else {
				rMessage = data.children[0].children[1];
				rObject = data.children[0].children[0];
			}

			
			var response = {
				returnMessage : rMessage,
				weNightObject: rObject
			};
			callback(response);
		},
		error: function(data) {
			var rObject;
			var returnMessage = {
					type : 0,
					message: "Error JS"
			};
			var response = {
				returnMessage : returnMessage,
				weNightObject: rObject
			};
			callback(response);
		}
	});
}
	
function getWeNightListResponse(url, callback) {

	$.ajax({
	
		dataType: 'xml',
		headers: {
			Accept:"application/xml",
			"Access-Control-Allow-Origin": "*"
		},
		type:'GET',
		url:url,
		success: function(data) { 
		
			var rMessage = data.children[0].children[1];
			var rObjectsList = data.children[0].children[0];
			
			var response = {
				returnMessage : rMessage,
				weNightObjects: rObjectsList
			};
			callback(response);
		},
		error: function(data) {
			var rObjectsList;
			var returnMessage = {
					type : 0,
					message: "Error JS"
			};
			var response = {
				returnMessage : returnMessage,
				weNightObjects: rObjectsList 
			};
			callback(response);
		}
	});
}

function getWeNightReturnMessageResponse(url, callback) {

	$.ajax({
	
		dataType: 'xml',
		headers: {
			Accept:"application/xml",
			"Access-Control-Allow-Origin": "*"
		},
		type:'GET',
		url:url,
		success: function(data) { 
		
			var rMessage = data.children[0].children[0];			
			var response = {
				returnMessage : rMessage,
			};
			callback(response);
		},
		error: function(data) {
			var returnMessage = {
					type : 0,
					message: "Error JS"
			};
			var response = {
				returnMessage : returnMessage,
			};
			callback(response);
		}
	});
}


function getSetOrderAsVipResponse(idPlacedOrder, callback){
	
	var url = host + "/" + bartenderService + "/" + setOrderAsVipWS + "/" + idPlacedOrder;
	getWeNightResponse(url, function(weNightResponse) {
		
		var returnMessage = parseReturnMessage(weNightResponse);
		callback(returnMessage);
	});
} 

function getSetOrderAsNoVipResponse(idPlacedOrder, callback){
	
	var url = host + "/" + bartenderService + "/" + setOrderAsNoVipWS + "/" + idPlacedOrder;
	getWeNightResponse(url, function(weNightResponse) {
		
		var returnMessage = parseReturnMessage(weNightResponse);
		callback(returnMessage);
	});
} 

function getDrinkTypesResponse(idPlace, callback){
	
	var url = host + "/" + productService + "/" + getDrinkTypesWS + "/" + idPlace;
	getWeNightListResponse(url, function(weNightResponse) {
		
		var weNightDrinkTypesResponse;
		var returnMessage = parseReturnMessage(weNightResponse);
		var drinkTypes;
		if(returnMessage.type == 1) {
			drinkTypes = parseDrinkTypes(weNightResponse);
		}
		weNightDrinkTypesResponse = {
			returnMessage : returnMessage,
			drinkTypes : drinkTypes
		};
		callback(weNightDrinkTypesResponse);
	});

} 

function getDrinkBrandsResponse(idPlace, idDrinkType, callback){
	
	var url = host + "/" + productService + "/" + getDrinkBrandsWS + "/" + idPlace + "/" + idDrinkType;
    
	getWeNightListResponse(url, function(weNightResponse) {
		
		var weNightDrinkBrandsResponse;
		var returnMessage = parseReturnMessage(weNightResponse);
		var drinkBrands;
		if(returnMessage.type == 1) {
			drinkBrands = parseDrinkBrands(weNightResponse);
		}
		weNightDrinkBrandsResponse = {
			returnMessage : returnMessage,
			drinkBrands : drinkBrands
		};
		callback(weNightDrinkBrandsResponse);
	});
}

function getDrinkSubtypesResponse(idPlace, idDrinkType, callback){
	
	var url = host + "/" + productService + "/" + getDrinkSubtypesWS + "/" + idPlace + "/" + idDrinkType;
	getWeNightListResponse(url, function(weNightResponse) {
		
        var weNightDrinkSubtypesResponse;
        var returnMessage = parseReturnMessage(weNightResponse);
        var drinkSubtypes;    
    
        if(returnMessage == undefined){
            
            sessionStorage.setItem("finish", true);
            
        }else{
        
		  if(returnMessage.type == 1) {
              drinkSubtypes = parseDrinkSubtypes(weNightResponse);
		  }
		  weNightDrinkSubtypesResponse = {
             returnMessage : returnMessage,
			 drinkSubtypes : drinkSubtypes
		  };
        }
		  callback(weNightDrinkSubtypesResponse);
	   });
}

function getDrinkHowsResponse(idPlace, idDrinkSubType, callback){
	
	var url = host + "/" + productService + "/" + getDrinkHowsWS + "/" + idPlace + "/" + idDrinkSubType;
	getWeNightListResponse(url, function(weNightResponse) {
  
		var weNightDrinkHowsResponse;
        var returnMessage = parseReturnMessage(weNightResponse);
        var drinkHows;
        
         if(returnMessage == undefined){
            
            sessionStorage.setItem("finish", true);
            
        }else{
		
		  if(returnMessage.type == 1) {
              drinkHows = parseDrinkHows(weNightResponse);
		  }
		  weNightDrinkHowsResponse = {
             returnMessage : returnMessage,
			 drinkHows : drinkHows
		  };
        
        }
		callback(weNightDrinkHowsResponse);
	});
}

function getDrinkHowPlusesResponse(idPlace, idDrinkSubType, callback){
	
	var url = host + "/" + productService + "/" + getDrinkHowPlusesWS + "/" + idPlace + "/" + idDrinkSubType;
	getWeNightListResponse(url, function(weNightResponse) {
		
        var weNightDrinkHowPlusesResponse;
        var returnMessage = parseReturnMessage(weNightResponse);
        var drinkHowPluses;
        
        if(returnMessage == undefined){
            
            sessionStorage.setItem("finish", true);
            
        }else{
		
		  if(returnMessage.type == 1) {
              drinkHowPluses = parseDrinkHowPluses(weNightResponse);
		  }
		  weNightDrinkHowPlusesResponse = {
            returnMessage : returnMessage,
			drinkHowPluses : drinkHowPluses
		  };
        
        }
        callback(weNightDrinkHowPlusesResponse);
	});
}

function getDrinkHowPluses2Response(idPlace, idDrinkSubType, callback){
	
	var url = host + "/" + productService + "/" + getDrinkHowPluses2WS + "/" + idPlace + "/" + idDrinkSubType;
	getWeNightListResponse(url, function(weNightResponse) {
		
		var weNightDrinkHowPluses2Response;
		var returnMessage = parseReturnMessage(weNightResponse);
		var drinkHowPluses2;
        if(returnMessage == undefined){
            
            sessionStorage.setItem("finish", true);
            
        }else{
            
		  if(returnMessage.type == 1) {
              drinkHowPluses2 = parseDrinkHowPluses2(weNightResponse);
		  }
		  weNightDrinkHowPluses2Response = {
              returnMessage : returnMessage,
			 drinkHowPluses2 : drinkHowPluses2
		  };
		  
        }
        
        callback(weNightDrinkHowPluses2Response);
        
	});
}

function getDrinkGarnishesResponse(idPlace, idDrinkType, idDrinkSubType, callback){
	
	var url = host + "/" + productService + "/" + getDrinkGarnishesWS + "/" + idPlace + "/" + idDrinkType + "/" + idDrinkSubType;
	getWeNightListResponse(url, function(weNightResponse) {
	
        var weNightDrinkGarnishesResponse;
        var returnMessage = parseReturnMessage(weNightResponse);
        var drinkGranishes;
        
        if(returnMessage == undefined){
            
            sessionStorage.setItem("finish", true);
            
        }else{

		  if(returnMessage.type == 1) {
              drinkGranishes = parseDrinkGarnishes(weNightResponse);
		  }
		  weNightDrinkGarnishesResponse = {
             returnMessage : returnMessage,
			 drinkGranishes : drinkGranishes
		  };
            
        }
		  callback(weNightDrinkGarnishesResponse);
	});
}


function getUserResponse(idUser, callback){
	
	var url = host + "/" + userService + "/" + getUserWS + "/"+idUser;
	getWeNightResponse(url, function(weNightResponse) {
		
		var weNightUserResponse;
		var returnMessage = parseReturnMessage(weNightResponse);
		var user;
		if(returnMessage.type == 1) {
			user = parseUser(weNightResponse);
		}
		weNightUserResponse = {
			returnMessage : returnMessage,
			user : user
		};
		callback(weNightUserResponse);
	});

} 

function getDrinkTypeByIdResponse(id, callback){
	
	var url = host + "/" + productService + "/" + getDrinkTypeByIdWS + "/" + id;
	getWeNightResponse(url, function(weNightResponse) {
		
		var weNightDrinkTypeResponse;
		var returnMessage = parseReturnMessage(weNightResponse);
		var drinkType;
		if(returnMessage.type == 1) {
			drinkType = parseDrinkType(weNightResponse);
		}
		weNightDrinkTypeResponse = {
			returnMessage : returnMessage,
			drinkType : drinkType
		};
		callback(weNightDrinkTypeResponse);
	});

} 

function getDrinkSubTypeByIdResponse(id, callback){
	
	var url = host + "/" + productService + "/" + getDrinkSubtypeByIdWS + "/" + id;
	getWeNightResponse(url, function(weNightResponse) {
		
		var weNightDrinkSubTypeResponse;
		var returnMessage = parseReturnMessage(weNightResponse);
		var drinkSubType;
		if(returnMessage.type == 1) {
			drinkSubType = parseDrinkSubtype(weNightResponse);
		}
		weNightDrinkSubTypeResponse = {
			returnMessage : returnMessage,
			drinkSubType : drinkSubType
		};
		callback(weNightDrinkSubTypeResponse);
	});
} 

function getDrinkBrandByIdResponse(id, callback){
	
	var url = host + "/" + productService + "/" + getDrinkBrandByIdWS + "/" + id;
	getWeNightResponse(url, function(weNightResponse) {
		
		var weNightDrinkBrandResponse;
		var returnMessage = parseReturnMessage(weNightResponse);
		var drinkBrand;
		if(returnMessage.type == 1) {
			drinkBrand = parseDrinkBrand(weNightResponse);
		}
		weNightDrinkBrandResponse = {
			returnMessage : returnMessage,
			drinkBrand : drinkBrand
		};
		callback(weNightDrinkBrandResponse);
	});

} 

function getDrinkHowByIdResponse(id, callback){
	
	var url = host + "/" + productService + "/" + getDrinkHowByIdWS + "/" + id;
	getWeNightResponse(url, function(weNightResponse) {
		
		var weNightDrinkHowResponse;
		var returnMessage = parseReturnMessage(weNightResponse);
		var how;
		if(returnMessage.type == 1) {
			how = parseDrinkHow(weNightResponse);
		}
		weNightDrinkHowResponse = {
			returnMessage : returnMessage,
			how : how
		};
		callback(weNightDrinkHowResponse);
	});

} 

function getDrinkHowPlusByIdResponse(id, callback){
	
	var url = host + "/" + productService + "/" + getDrinkHowPlusByIdWS + "/" + id;
	getWeNightResponse(url, function(weNightResponse) {
		
		var weNightHowPlusResponse;
		var returnMessage = parseReturnMessage(weNightResponse);
		var howPlus;
		if(returnMessage.type == 1) {
			howPlus = parseDrinkHowPlus(weNightResponse);
		}
		weNightHowPlusResponse = {
			returnMessage : returnMessage,
			howPlus : howPlus
		};
		callback(weNightHowPlusResponse);
	});

} 

function getDrinkHowPlus2ByIdResponse(id, callback){
	
	var url = host + "/" + productService + "/" + getDrinkHowPlus2ByIdWS + "/" + id;
	getWeNightResponse(url, function(weNightResponse) {
		
		var weNightHowPlus2Response;
		var returnMessage = parseReturnMessage(weNightResponse);
		var howPlus2;
		if(returnMessage.type == 1) {
			howPlus2 = parseDrinkHowPlus2(weNightResponse);
		}
		weNightHowPlus2Response = {
			returnMessage : returnMessage,
			howPlus2 : howPlus2
		};
		callback(weNightHowPlus2Response);
	});

} 

function getDrinkGarnishByIdResponse(id, callback){
	
	var url = host + "/" + productService + "/" + getDrinkGarnishByIdWS + "/" + id;
	getWeNightResponse(url, function(weNightResponse) {
		
		var weNightDrinkGarnishResponse;
		var returnMessage = parseReturnMessage(weNightResponse);
		var drinkGarnish;
		if(returnMessage.type == 1) {
			drinkGarnish = parseDrinkGarnish(weNightResponse);
		}
		weNightDrinkGarnishResponse = {
			returnMessage : returnMessage,
			drinkGarnish : drinkGarnish
		};
		callback(weNightDrinkGarnishResponse);
	});

} 

function getSignUpUserResponse(userName, encryptedPassword, telNumber, mail, callback){
	
    var encPassRepl = encryptedPassword.replace(/\//g, '---');
	var url = host + "/" + userService + "/" + signUpUserWS + "/" + userName + "/" + encPassRepl + "/" + telNumber + "/" + mail ;
	getWeNightReturnMessageResponse(url, function(weNightResponse) {
		
		var returnMessage = parseReturnMessage(weNightResponse);
		callback(returnMessage);
	});

} 

function getPlaceConfig(idPlace, callback) {
	var url = host + "/" + placeConnectionService + "/" + getPlaceConfigWS + "/" + idPlace;
	
	getWeNightResponse(url, function(weNightResponse) {
		
		var weNightPlaceConfigResponse;
		var returnMessage = parseReturnMessage(weNightResponse);
		var placeConfig;
		if(returnMessage.type == 1) {
			placeConfig = parsePlaceConfig(weNightResponse);
		}
		weNightPlaceConfigResponse = {
			returnMessage : returnMessage,
			placeConfig : placeConfig
		};
		callback(weNightPlaceConfigResponse);
	});
}

function getLoginResponse(username, encryptedPassword, idPlace, callback) {
	
	var encPassRepl = encryptedPassword.replace(/\//g, '---');
	var url = host + "/" + userService + "/" + loginWS + "/" + username + "/" + encPassRepl + "/" + idPlace;
	
	getWeNightResponse(url, function(weNightResponse) {
		
		var weNightLoginResponse;
		var returnMessage = parseReturnMessage(weNightResponse);
		var userSession;
		if(returnMessage.type == 1) {
			userSession = parseUserSession(weNightResponse);
		}
		weNightLoginResponse = {
			returnMessage : returnMessage,
			userSession : userSession
		};
		callback(weNightLoginResponse);
	});
	
}

function getLogoutResponse(userSession, callback){
	
	var url = host + "/" + userService + "/" + logoutWS + "/" + userSession;
	getWeNightReturnMessageResponse(url, function(weNightResponse) {
		
		var returnMessage = parseReturnMessage(weNightResponse);
		callback(returnMessage);
	});

} 

function getAddCreditCardResponse(encryptedCreditCardNumber, encryptedCvv, encryptedZip, idUser, date, callback){

	encryptedCreditCardNumber = encryptedCreditCardNumber.replace(/\//g, '---');
	encryptedCvv = encryptedCvv.replace(/\//g, '---');
	encryptedZip = encryptedZip.replace(/\//g, '---');

	var url = host + "/" + userService + "/" + addCreditCardWS + "/"+encryptedCreditCardNumber + "/" + encryptedCvv + "/"+encryptedZip + "/"+idUser + "/"+date;
    
	getWeNightReturnMessageResponse(url, function(weNightResponse) {
		
		var returnMessage = parseReturnMessage(weNightResponse);
		callback(returnMessage);
	});

} 

function getUserCardsResponse(idUser, callback){
	
	var url = host + "/" + userService + "/" + getUserCardsWS + "/" + idUser ;
	getWeNightListResponse(url, function(weNightResponse) {
		
		var userCardsResponse;
		var returnMessage = parseReturnMessage(weNightResponse);
		var userCards;
		if(returnMessage.type == 1) {
			userCards = parseCreditCardsHiddenNumber(weNightResponse);
		}
		userCardsResponse = {
			returnMessage : returnMessage,
			userCards : userCards
		};
		callback(userCardsResponse);
	});

} 

function getDeleteCreditCardResponse(idCreditCard, callback){
	
	var url = host + "/" + userService + "/" + deleteCreditCardWS + "/" + idCreditCard;
	getWeNightReturnMessageResponse(url, function(weNightResponse) {
		
		var returnMessage = parseReturnMessage(weNightResponse);
		callback(returnMessage);
	});

} 


function getSetUserDevicePushTokenResponse(idUser, devicePushToken, callback){

    var url = host + "/" + userService + "/" + setUserDevicePushTokenWS + "/" + idUser + "/" + devicePushToken;
    getWeNightReturnMessageResponse(url, function(weNightResponse) {
        var returnMessage = parseReturnMessage(weNightResponse);
        callback(returnMessage);
    });
    
} 

function getSetUserVisibilityResponse(idUser, isVisible, callback){

    var url = host + "/" + userService + "/" + setUserVisibilityWS + "/" + idUser + "/" + isVisible;
    getWeNightReturnMessageResponse(url, function(weNightResponse) {
        var returnMessage = parseReturnMessage(weNightResponse);
        callback(returnMessage);
    });
    
} 

function getSetUserDescriptionResponse(idUser, description, callback){

    var url = host + "/" + userService + "/" + setUserDescriptionWS + "/" + idUser + "/" + description;
    getWeNightReturnMessageResponse(url, function(weNightResponse) {
        var returnMessage = parseReturnMessage(weNightResponse);
        callback(returnMessage);
    });
    
} 

function getSetUserImagePathResponse(idUser, imageLocalPath, callback){
    var pathEdited = imageLocalPath.replace(/\//g, '---');
    var url = host + "/" + userService + "/" + setUserImageLocalPathWS + "/" + idUser + "/" + pathEdited;
    getWeNightReturnMessageResponse(url, function(weNightResponse) {
        var returnMessage = parseReturnMessage(weNightResponse);
        callback(returnMessage);
    });

} 

function getSendChatPushNotificationResponse(idUser, text, callback){
    var url = host + "/" + chatService + "/" + SendChatPushNotificationPathWS + "/" + idUser + "/" + text;
    getWeNightReturnMessageResponse(url, function(weNightResponse) {
        var returnMessage = parseReturnMessage(weNightResponse);
        callback(returnMessage);
    });

} 

function getSetUserDefaultCardResponse(idUser, idCreditCard, callback){
    var url = host + "/" + userService + "/" + setUserDefaultCardWS + "/" + idUser + "/" + idCreditCard;
    getWeNightReturnMessageResponse(url, function(weNightResponse) {
        var returnMessage = parseReturnMessage(weNightResponse);
        callback(returnMessage);
    });

}

function getUserAttendedOrdersResponse(idUser, idPlace, callback){
	
	var url = host + "/" + bartenderService + "/" + getAttendedUserOrdersWS + "/" + idUser + "/" + idPlace;
	getWeNightListResponse(url, function(weNightResponse) {
		
		var weNightOrdersResponse;
		var returnMessage = parseReturnMessage(weNightResponse);
		var placedOrders;
		if(returnMessage.type == 1) {
			placedOrders = parsePlacedOrders(weNightResponse);
		}
		weNightOrdersResponse = {
			returnMessage : returnMessage,
			orders : placedOrders
		};
		callback(weNightOrdersResponse);
	});

} 

function getUserNotAttendedOrdersResponse(idUser, idPlace, callback){
	
	var url = host + "/" + bartenderService + "/" + getNonAttendedUserOrdersWS + "/" + idUser + "/" + idPlace;
	getWeNightListResponse(url, function(weNightResponse) {
		
		var weNightOrdersResponse;
		var returnMessage = parseReturnMessage(weNightResponse);
		var placedOrders;
		if(returnMessage.type == 1) {
			placedOrders = parsePlacedOrders(weNightResponse);
		}
		weNightOrdersResponse = {
			returnMessage : returnMessage,
			orders : placedOrders
		};
		callback(weNightOrdersResponse);
	});

} 

function getUserOrdersAttendingResponse(idUser, idPlace, callback){
	
	var url = host + "/" + bartenderService + "/" + getAttendingUserOrdersWS + "/" + idUser + "/" + idPlace;
	getWeNightListResponse(url, function(weNightResponse) {
		
		var weNightOrdersResponse;
		var returnMessage = parseReturnMessage(weNightResponse);
		var placedOrders;
		if(returnMessage.type == 1) {
			placedOrders = parsePlacedOrders(weNightResponse);
		}
		weNightOrdersResponse = {
			returnMessage : returnMessage,
			orders : placedOrders
		};
		callback(weNightOrdersResponse);
	});

}

function getVipOrdersOfUserResponse(idUser, idPlace, callback){
	
	var url = host + "/" + bartenderService + "/" + getVipOrdersOfUserWS + "/" + idUser + "/" + idPlace;
	getWeNightListResponse(url, function(weNightResponse) {
		
		var weNightOrdersResponse;
		var returnMessage = parseReturnMessage(weNightResponse);
		var placedOrders;
		if(returnMessage.type == 1) {
			placedOrders = parsePlacedOrders(weNightResponse);
		}
		weNightOrdersResponse = {
			returnMessage : returnMessage,
			orders : placedOrders
		};
		callback(weNightOrdersResponse);
	});

}

function getUserOrdersAtPlaceResponse(idUser, idPlace, callback){
	
	var url = host + "/" + bartenderService + "/" + getUserOrdersAtPlaceWS + "/" + idUser + "/" + idPlace;
	getWeNightListResponse(url, function(weNightResponse) {
		
		var weNightOrdersResponse;
		var returnMessage = parseReturnMessage(weNightResponse);
		var placedOrders;
		if(returnMessage.type == 1) {
			placedOrders = parsePlacedOrders(weNightResponse);
		}
		weNightOrdersResponse = {
			returnMessage : returnMessage,
			orders : placedOrders
		};
		callback(weNightOrdersResponse);
	});

} 


function getOrderDrinksResponse(idPlacedOder, callback){
	
	var url = host + "/" + bartenderService + "/" + getOrderedDrinksWS + "/" + idPlacedOder;
	getWeNightListResponse(url, function(weNightResponse) {
		
		var weNightOrderDrinksResponse;
		var returnMessage = parseReturnMessage(weNightResponse);
		var drinks;
		if(returnMessage.type == 1) {
			drinks = parsePlacedOrderDrinks(weNightResponse);
		}
		weNightOrderDrinksResponse = {
			returnMessage : returnMessage,
			drinks : drinks
		};
		callback(weNightOrderDrinksResponse);
	});

} 

function parseCreditCardsHiddenNumber(weNightResponse){
	var ccs = [];
	for(var x=0;x<weNightResponse.weNightObjects.children.length;x++) {

		var dt = weNightResponse.weNightObjects.children[x];
		var cc = {
			isDefault: dt.children[1].textContent,
			hiddenNumber: dt.children[2].textContent,
			ccId: dt.children[0].textContent
		};
		ccs.push(cc);
	}
	return ccs;
}

function parseReturnMessage(weNightResponse) {
    
    var type;
    var mes;
    
    if(weNightResponse.returnMessage != null && weNightResponse.returnMessage.type != undefined) {
        
        mes = weNightResponse.returnMessage.message;
        type = weNightResponse.returnMessage.type; 

    } else if (weNightResponse.returnMessage != undefined && weNightResponse.returnMessage.children != undefined){
        
        mes = weNightResponse.returnMessage.children[0].textContent;
        type = weNightResponse.returnMessage.children[1].textContent;
    
    } else {
    	mes = "Error";
    	type = 0;
    }
	 	
    var returnMessage = {
	   type : type,
	   message: mes
    };
	   
    return returnMessage;  
    
}

function parseUser(weNightResponse) {

    var u = weNightResponse.weNightObject;
    var user = {
        idUser : u.children[2].textContent,
        userName : u.children[11].textContent,
        password : u.children[5].textContent,
        telNumber : u.children[9].textContent,
        mail : u.children[3].textContent,
        qrCode : u.children[7].textContent,
        creditCardId : u.children[0].textContent,
        singUpDate : u.children[8].textContent,
        devicePushToken : u.children[1].textContent,
        isVisible : u.children[12].textContent,
        userDescription : u.children[10].textContent,
        mailVerified : u.children[4].textContent,
        profileImagePath : u.children[4].textContent
    };
    return user;
}

function parsePlaceConfig(weNightResponse) {
	
	var pc = weNightResponse.weNightObject;
	var placeConfig = {
		id: pc.children[1].textContent,
		idPlace: pc.children[2].textContent,
		iv: pc.children[3].textContent,
		encryptKey: pc.children[0].textContent
	};
	
	return placeConfig;
}

function parseUserSession(weNightResponse) {
	var us = weNightResponse.weNightObject;
	var userSession = {
		
		sessionId: us.children[4].textContent,
		idUser: us.children[3].textContent,
		sessionKey: us.children[5].textContent,
		idPlace: us.children[2].textContent,
		startDate: us.children[6].textContent,
		endDate: us.children[1].textContent,
		active: us.children[0].textContent
	};
	return userSession;
}

function parseDrinkTypes(weNightResponse) {

	var drinkTypes = [];
	for(var x=0;x<weNightResponse.weNightObjects.children.length;x++) {

		var dt = weNightResponse.weNightObjects.children[x];
		var drinkType = {
			id: dt.children[1].textContent,
			name : dt.children[5].textContent,
			description : dt.children[0].textContent,
			imagePath : dt.children[4].textContent,
			imageName : dt.children[3].textContent,
			idPlace : dt.children[2].textContent
		};
		drinkTypes.push(drinkType);
	}
	return drinkTypes;
}

function parseDrinkType(weNightResponse) {

		var dt = weNightResponse.weNightObject;
		var drinkType = {
			id: dt.children[1].textContent,
			name : dt.children[5].textContent,
			description : dt.children[0].textContent,
			imagePath : dt.children[4].textContent,
			imageName : dt.children[3].textContent,
			idPlace : dt.children[2].textContent
		};
	
	return drinkType;
}

function parseDrinkBrands(weNightResponse) {
	
    var drinkBrands = [];
	for(var x=0;x<weNightResponse.weNightObjects.children.length;x++) {

		var dt = weNightResponse.weNightObjects.children[x];
		var drinkBrand = {
			id: dt.children[1].textContent,
			name : dt.children[0].textContent,
			description : dt.children[2].textContent,
			imagePath : dt.children[5].textContent,
            price: dt.children[7].textContent,
			imageName : dt.children[4].textContent,
			idPlace : dt.children[3].textContent
		};
		drinkBrands.push(drinkBrand);
	}
	return drinkBrands;
    
}

function parseDrinkBrand(weNightResponse) {
	
	var dt = weNightResponse.weNightObject;
	var drinkBrand = {
		id: dt.children[1].textContent,
		name : dt.children[0].textContent,
		description : dt.children[2].textContent,
		imagePath : dt.children[5].textContent,
        price: dt.children[7].textContent,
		imageName : dt.children[4].textContent,
		idPlace : dt.children[3].textContent
	};
	return drinkBrand;
    
}

function parseDrinkSubtypes(weNightResponse) {
   
    var drinkSubtypes = [];
	for(var x=0;x<weNightResponse.weNightObjects.children.length;x++) {

		var dt = weNightResponse.weNightObjects.children[x];
		var drinkSubtype = {
			id: dt.children[1].textContent,
            idDrinkType: dt.children[2].textContent,
			name : dt.children[6].textContent,
			description : dt.children[0].textContent,
			imagePath : dt.children[5].textContent,
			imageName : dt.children[4].textContent,
			idPlace : dt.children[3].textContent,
            price : dt.children[7].textContent
		};
		drinkSubtypes.push(drinkSubtype);
	}
	return drinkSubtypes;

}

function parseDrinkSubtype(weNightResponse) {
   
		var dt = weNightResponse.weNightObject;
		var drinkSubtype = {
            id: dt.children[1].textContent,
            idDrinkType: dt.children[2].textContent,
			name : dt.children[6].textContent,
			description : dt.children[0].textContent,
			imagePath : dt.children[5].textContent,
			imageName : dt.children[4].textContent,
			idPlace : dt.children[3].textContent,
            price : dt.children[7].textContent
		};
	return drinkSubtype;

}

function parseDrinkHows(weNightResponse) {
	
    var drinkHows = [];
	for(var x=0;x<weNightResponse.weNightObjects.children.length;x++) {

		var dt = weNightResponse.weNightObjects.children[x];
		var drinkHow = {
			id: dt.children[1].textContent,
			name : dt.children[0].textContent,
			description : dt.children[2].textContent,
			imagePath : dt.children[5].textContent,
            price: dt.children[7].textContent,
			imageName : dt.children[4].textContent,
			idPlace : dt.children[3].textContent
		};
		drinkHows.push(drinkHow);
	}
	return drinkHows;

}

function parseDrinkHow(weNightResponse) {
	
		var dt = weNightResponse.weNightObject;
		var drinkHow = {
			id: dt.children[1].textContent,
			name : dt.children[0].textContent,
			description : dt.children[2].textContent,
			imagePath : dt.children[5].textContent,
            price: dt.children[7].textContent,
			imageName : dt.children[4].textContent,
			idPlace : dt.children[3].textContent
		};
	
	return drinkHow;

}

function parseDrinkHowPlus(weNightResponse) {

		var dt = weNightResponse.weNightObject;
		var drinkHowsPlus = {
			id: dt.children[1].textContent,
			name : dt.children[0].textContent,
			description : dt.children[2].textContent,
			imagePath : dt.children[5].textContent,
			imageName : dt.children[4].textContent,
			idPlace : dt.children[3].textContent
		};
	
	return drinkHowsPlus;

}

function parseDrinkHowPluses(weNightResponse) {
  
    var drinkHowsPluses = [];
	for(var x=0;x<weNightResponse.weNightObjects.children.length;x++) {

		var dt = weNightResponse.weNightObjects.children[x];
		var drinkHowsPlus = {
			id: dt.children[1].textContent,
			name : dt.children[0].textContent,
			description : dt.children[2].textContent,
			imagePath : dt.children[5].textContent,
			imageName : dt.children[4].textContent,
			idPlace : dt.children[3].textContent
		};
		drinkHowsPluses.push(drinkHowsPlus);
	}
	return drinkHowsPluses;

}

function parseDrinkHowPlus2(weNightResponse) {
  
		var dt = weNightResponse.weNightObject;
		var drinkHowsPlus2 = {
			id: dt.children[1].textContent,
			name : dt.children[0].textContent,
			description : dt.children[2].textContent,
			imagePath : dt.children[5].textContent,
			imageName : dt.children[4].textContent,
			idPlace : dt.children[3].textContent
		};
	return drinkHowsPlus2;

}

function parseDrinkHowPluses2(weNightResponse) {
  
    var drinkHowsPluses2 = [];
	for(var x=0;x<weNightResponse.weNightObjects.children.length;x++) {

		var dt = weNightResponse.weNightObjects.children[x];
		var drinkHowsPlus2 = {
			id: dt.children[1].textContent,
			name : dt.children[0].textContent,
			description : dt.children[2].textContent,
			imagePath : dt.children[5].textContent,
			imageName : dt.children[4].textContent,
			idPlace : dt.children[3].textContent
		};
		drinkHowsPluses2.push(drinkHowsPlus2);
	}
	return drinkHowsPluses2;

}

function parseDrinkGarnish(weNightResponse) {
 
    var dt = weNightResponse.weNightObject;
    var drinkGarnish = {
        id: dt.children[1].textContent,
        idDrinkSubtype : dt.children[2].textContent,
        idDrinkType : dt.children[3].textContent,
        name : dt.children[7].textContent,
        description : dt.children[0].textContent,
        imagePath : dt.children[6].textContent,
        imageName : dt.children[5].textContent,
        idPlace : dt.children[4].textContent
    };
return drinkGarnish;

}

function parseDrinkGarnishes(weNightResponse) {
 
    var drinkGarnishes = [];
    for(var x=0;x<weNightResponse.weNightObjects.children.length;x++) {

        var dt = weNightResponse.weNightObjects.children[x];
        var drinkGarnish = {
            id: dt.children[1].textContent,
            idDrinkSubtype : dt.children[2].textContent,
            idDrinkType : dt.children[3].textContent,
            name : dt.children[7].textContent,
            description : dt.children[0].textContent,
            imagePath : dt.children[6].textContent,
            imageName : dt.children[5].textContent,
            idPlace : dt.children[4].textContent
        };
    drinkGarnishes.push(drinkGarnish);
    }
return drinkGarnishes;

}

function getPlaceOrderResponse(idUser, idPlace, tipAmount, ids, notes, callback){
    
    
    var url = host + "/" + orderService + "/" + placeOrderWS + "/" +idUser + "/" + idPlace + "/" +tipAmount+ "/"+ids +"/" +notes;
    
    getWeNightResponse(url, function(weNightResponse) {
        
    var weNightPlaceOrderResponse;
        
        var returnMessage = parseReturnMessage(weNightResponse);
        var order;
        
        if(returnMessage.type == 1) {
            order = parseOrder(weNightResponse);
        }
        weNightPlaceOrderResponse = {
            
            returnMessage : returnMessage,
            order : order
        };
        
        callback(weNightPlaceOrderResponse);
    });

} 

function getPlaceReOrderResponse(idOrder, callback){
    
    
    var url = host + "/" + orderService + "/" + placeReOrderWS + "/" +idOrder;
    
    getWeNightResponse(url, function(weNightResponse) {
        
    var weNightPlaceOrderResponse;
        
        var returnMessage = parseReturnMessage(weNightResponse);
        var order;
        
        if(returnMessage.type == 1) {
            order = parseOrder(weNightResponse);
        }
        weNightPlaceOrderResponse = {
            
            returnMessage : returnMessage,
            order : order
        };
        
        callback(weNightPlaceOrderResponse);
    });

} 


function parseOrder(weNightResponse) {
    
    var order = weNightResponse.weNightObject;
    var placedOrder = {
            id: order.children[5].textContent,
            barmanId: order.children[3].textContent,
            creditCardId: order.children[4].textContent,
            orderPrice: order.children[7].textContent,
            paymentMethod: order.children[9].textContent,
            placeId: order.children[11].textContent,
            tip: order.children[13].textContent,
            placementDate: order.children[12].textContent,
            pickedUp: order.children[10].textContent,
            paid: order.children[7].textContent,
            attending: order.children[2].textContent,
            attended: order.children[0].textContent,
            attendedDate: order.children[1].textContent,
            userId: order.children[14].textContent,
            notes: order.children[6].textContent,
            vip: order.children[15].textContent
    };
    
    
        
    return placedOrder;
        
}


function parsePlacedOrderDrinks(weNightResponse) {
	var drinks = [];
	for(var x=0;x<weNightResponse.weNightObjects.children.length;x++) {
	
		var dt = weNightResponse.weNightObjects.children[x];
		var drink = {
			id: dt.children[8].textContent,
			description: dt.children[0].textContent,
			placedOrderId: dt.children[10].textContent,
			placeId: dt.children[9].textContent,
			drinkTypeId: dt.children[7].textContent,
			drinkBrandId: dt.children[2].textContent,
			drinSubtypeId: dt.children[0].textContent,
			drinkHowId: dt.children[4].textContent,
			drinkHowPlusId: dt.children[6].textContent,
			drinkHowPlus2Id: dt.children[5].textContent,
			drinkGarnishId: dt.children[3].textContent
		};
		drinks.push(drink);
	}
	return drinks;

}


function parsePlacedOrders(weNightResponse) {
var orders = [];
	for(var x=0;x<weNightResponse.weNightObjects.children.length;x++) {
	
		var order = weNightResponse.weNightObjects.children[x];
		var placedOrder = {
				id: order.children[5].textContent,
	            barmanId: order.children[3].textContent,
	            creditCardId: order.children[4].textContent,
	            orderPrice: order.children[7].textContent,
	            paymentMethod: order.children[9].textContent,
	            placeId: order.children[11].textContent,
	            tip: order.children[13].textContent,
	            placementDate: order.children[12].textContent,
	            pickedUp: order.children[10].textContent,
	            paid: order.children[7].textContent,
	            attending: order.children[2].textContent,
	            attended: order.children[0].textContent,
	            attendedDate: order.children[1].textContent,
	            userId: order.children[14].textContent,
	            notes: order.children[6].textContent,
	            vip: order.children[15].textContent
		};
		orders.push(placedOrder);
	}
	return orders;
    

}