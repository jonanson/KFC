
/*********************** VARIABLES ****************************/

var card_type;
var card_number;
var card_month;
var card_year;
var card_ccv;
var card_pcode;

var idUser = sessionStorage.getItem("idUser");
//var idUser = 3;
var idPlace = 0;

var currentRow = 0;
var cards = [];

var defcard = 0;

var order;
var goOnBack="";

var isNewCard = false;
var origin;

var defaultCardHasChanged = false;
/*********************** FUNCTIONS ****************************/

$(document).ready(function() {
    order = window.sessionStorage.getItem("placedOrderId");
    var l3 = document.getElementById("l3");
    if(l3 !=null) {
        document.getElementById("l3").innerHTML = order;
    }
    if(sessionStorage.getItem("originPage") !=null) {
        origin = sessionStorage.getItem("originPage");
    }
    if(origin =="checkout") {
        document.getElementById("toggle_data").disabled=true;
        changeTab("cards");
    } else {
        changeTab("data");
    }

    //backbutton management: set app to main menu
    document.addEventListener("backbutton", function(e) {
        e.preventDefault();
        goBackFromData();
    }, false);
    

});

function goBackFromData(){
    if(origin =="checkout") {
        window.location.href = "checkout.html";
    } else {
        window.location.href = "mainMenu.html";
    }
}

function submit_form(){
        overlay_on();
        //card_type = document.getElementById("select_type").value;
        card_number = document.getElementById("card_number").value;        
        card_month = document.getElementById("select_month");
        card_month = card_month.options[card_month.selectedIndex].text;
        card_year = document.getElementById("select_year");
        card_year = card_year.options[card_year.selectedIndex].text;
        card_ccv = document.getElementById("card_ccv").value;
        card_pcode = ""; //document.getElementById("card_pcode").value;
    
        var date = card_month.toString() + card_year.toString();

        encrypt(card_number, idPlace, function(encryptedCardNumber){     
            
            encrypt(card_ccv, idPlace, function(encryptedCcv){  
                
                encrypt(card_pcode, idPlace, function(encryptedZip){ 

                    getAddCreditCardResponse(encryptedCardNumber, encryptedCcv, encryptedZip, idUser, date, function(encryptedCreditCardNumber){  
            
                        var msg = encryptedCreditCardNumber.message;
                        var type = encryptedCreditCardNumber.type;  
            
                        if(type == 1){
                
                            card_type = null;
                            card_number = null;
                            card_month = null;
                            card_year = null;
                            card_ccv = null;
                            card_pcode = null;
                            currentRow = 0;
                            if(cards.length == 0){
                                getUserCardsResponse(idUser,function(WNresponse){
                                
                                var isOk = WNresponse.returnMessage.type;
                                if(isOk==1) {
                                    cards = WNresponse.userCards;
                                    window.sessionStorage.setItem("default_card_id",cards[0].ccId);

                                    if(origin =="checkout") {
                                        window.location="checkout.html";
                                    } 
                                }
                                
                                });
                            }
                            
                            action_showCards();
                            overlay_off();
                            isNewCard = false;
                        }else{
                            overlay_off();
                            alert("Datos incorrectos");
                
                        }   
            
                    });

                });
                
             });
            
        });

    
}

function create_cardRow(rowNumber){
    
    var sel_info_area = document.createElement("div");
    var sel_info_text_col = document.createElement("div");
    var sel_info_cardType_col = document.createElement("div");
    var cardType = document.createElement("img");
    var sel_info_opt_col = document.createElement("div");

    sel_info_area.setAttribute("id", "sel_info_area"+rowNumber);
    sel_info_area.className = "col-xs-8 col-sm-8 sel_info_area";
    
    sel_info_cardType_col.setAttribute("id", "sel_info_quantity"+rowNumber);
    sel_info_cardType_col.className = "col-xs-3 col-sm-3 sel_info_quantity_col";

    cardType.setAttribute("id", "cardType_img"+rowNumber);
    cardType.setAttribute("class", "cardType_img");
    cardType.src = "./img/ccard.png";

    
    sel_info_text_col.setAttribute("id", "sel_info_text"+rowNumber);
    sel_info_text_col.className = "col-xs-9 col-sm-9 sel_info_text_col";
    sel_info_text_col.innerHTML = cards[rowNumber].hiddenNumber;
       
    
    sel_info_opt_col.setAttribute("id", "sel_info_opt_col"+rowNumber);
    sel_info_opt_col.className = "col-xs-4 col-sm-4 sel_info_opt_col";
    
    sel_info_cardType_col.appendChild(cardType);
    
    sel_info_area.appendChild(sel_info_cardType_col);
    sel_info_area.appendChild(sel_info_text_col);

    document.getElementById("infoRow"+rowNumber).appendChild(sel_info_area);
    document.getElementById("infoRow"+rowNumber).appendChild(sel_info_opt_col);
    
    
    
}

function action_loadCards(){
    overlay_on();
    getUserCardsResponse(idUser, function(userCardsResponse){
       
        cards = [];        
        cards = userCardsResponse.userCards;
        if(cards!=null) {
           for (var i=0; i<cards.length; i++){
        
            create_cardInfo(currentRow);
            create_cardRow(currentRow); 
            create_optAreas(currentRow);
            populate_optAreas(currentRow);
            action_animateOpts(currentRow);
        
            currentRow++;
            overlay_off();
            }
        }
        

        
        create_addRow();
        
        find_defaultCard();
        
   }); 
    
    
}

function action_showCards(){
    
    document.getElementById("bodyforms").innerHTML = "";
    
    if(JSON.parse(window.sessionStorage.getItem("default_card")) != null || (window.sessionStorage.getItem("default_card_id") != null  && window.sessionStorage.getItem("default_card_id") != 0)){
        action_loadCards();
        
    } else{
        
        create_cardForm();
        
    }

    
}

function create_cardInfo(rowNumber){
    
    var infoRow = document.createElement("div");
    infoRow.setAttribute("id", "infoRow"+rowNumber);
    infoRow.setAttribute("class", "row infoRow");

  document.getElementById("bodyforms").appendChild(infoRow);
}

function create_addRow(rowNumber){
    
    var addRow = document.createElement("div");
    addRow.setAttribute("class", "row");
    addRow.setAttribute("id", "add_area");
    
    var addButton = document.createElement("input");
    addButton.setAttribute("class", "button_add");
    addButton.setAttribute("type", "button");
    addButton.setAttribute("onclick", "create_cardForm();");
    addButton.setAttribute("value", "(+) Añadir tarjeta");

    addRow.appendChild(addButton);
    document.getElementById("bodyforms").appendChild(addRow);   
 
    
}

function delete_card(rowNumber){
    overlay_on();
    getDeleteCreditCardResponse(cards[rowNumber].ccId, function(returnMessage){  
            
            var msg = returnMessage.message;
            var type = returnMessage.type;  
            overlay_off();
        });
    
    delete_Row(rowNumber);
    
    rearrange_Rows();
}


/*
*
*
*
*/
function create_cardForm(){
    
    document.getElementById("bodyforms").innerHTML = "";
    
    currentRow = 0;
    
    create_formSkeleton();

    isNewCard = true;
    //eliminamos la row preparada para el postal code
    document.getElementById("bodyforms").removeChild(document.getElementById("formRow2"));    
}

function create_formSkeleton(){
    
    
    create_formRow(currentRow);
    currentRow = currentRow + 1;
    create_formRow(currentRow);
    currentRow = currentRow+ 1;
    create_formRow(currentRow);
    currentRow = currentRow +1;
    
    populate_formSkeleton();
    


}

function create_textFields(){
    
    var card_number = document.createElement("input"); 
    card_number.setAttribute("id", "card_number");
    card_number.setAttribute("class", "form_field");
    card_number.setAttribute("type", "text");
    card_number.setAttribute("onkeypress", "return isNumberKey(event);");
    card_number.setAttribute("maxlength", "16"); 
    document.getElementById("content_col_right0").appendChild(card_number);
    
    var card_ccv = document.createElement("input"); 
    card_ccv.setAttribute("type", "text");
    card_ccv.setAttribute("id", "card_ccv");
    card_ccv.setAttribute("class", "form_field");
    card_ccv.setAttribute("onkeypress", "return isNumberKey(event);");  
    card_ccv.setAttribute("maxlength", "4"); 
    
    document.getElementById("content_col_right1").appendChild(card_ccv);

    
    var card_pcode = document.createElement("input");
    card_pcode.setAttribute("id", "card_pcode");
    card_pcode.setAttribute("type", "text");
    card_pcode.setAttribute("class", "form_field");
    card_pcode.setAttribute("onkeypress", "return isNumberKey(event);");
    card_pcode.setAttribute("maxlength", "5"); 
    
    document.getElementById("content_col_right2").appendChild(card_pcode);

    
    
}

function create_typeSelect(){
    
    var select_type = document.createElement("select"); 
    select_type.setAttribute("id", "select_type");
    select_type.setAttribute("class", "form_inner_element form_select form_inner_element_left");

        var opt1 = document.createElement("option"); 
        opt1.setAttribute("value", "visa");
        opt1.innerHTML = "VISA";
    
        select_type.appendChild(opt1);
    
    
        var opt2 = document.createElement("option"); 
        opt2.setAttribute("value", "mcard");
        opt2.innerHTML = "MasterCard";
    
        select_type.appendChild(opt2);

    
        var opt3 = document.createElement("option"); 
        opt3.setAttribute("value", "aexpress");
        opt3.innerHTML = "AmericanExpress";
    
        select_type.appendChild(opt3);

    document.getElementById("content_col_left0").appendChild(select_type);   
    
}

function create_dateSelect(){
    
    var select_month = document.createElement("select"); 
    select_month.setAttribute("id", "select_month");
    select_month.setAttribute("class", "form_inner_element form_select form_inner_subelement_left");
    
    for(var i=0; i<12; i++){
        
        var opt = document.createElement("option"); 
        opt.setAttribute("value", (i+1));
        opt.innerHTML = (i+1);
        
        select_month.appendChild(opt);
    }

    document.getElementById("content_subcol_left1").appendChild(select_month);
    
    
    var select_year = document.createElement("select"); 
    select_year.setAttribute("id", "select_year");
    select_year.setAttribute("class", "form_inner_element form_select form_inner_subelement_right");
    
    for(var i=0; i<8; i++){
        
        var opt = document.createElement("option"); 
        opt.setAttribute("value", 2017+i);
        opt.innerHTML = 17+i;
        
        select_year.appendChild(opt);
    }

    document.getElementById("content_subcol_right1").appendChild(select_year);
    
}

function create_formTitles(){
    
    document.getElementById("title_col_left0").innerHTML = "Card Type";
    document.getElementById("title_col_right0").innerHTML = "Card Number";
    document.getElementById("title_subcol_left1").innerHTML = "Month";
    document.getElementById("title_subcol_right1").innerHTML = "Year";
    document.getElementById("title_col_right1").innerHTML = "CCV";
    document.getElementById("content_col_left2").innerHTML = "Postal Code";

    
}

function populate_formSkeleton(){
    
    create_typeSelect();
    create_dateSelect();
    
    create_textFields();
    
    create_formTitles();
    
}

function create_formRow(rowNumber){
    
    var row_form = document.createElement("div");
    row_form.setAttribute("id", "formRow"+rowNumber);
    row_form.setAttribute("class", "row formRow");  
    
        var col_form_left = document.createElement("div");
        col_form_left.setAttribute("id", "form_col_left"+rowNumber);
        col_form_left.setAttribute("class", "col-xs-4 col-sm-4 form_col form_col_left");
    
        if(currentRow != 2){
            
            var title_row_left = document.createElement("div");
            title_row_left.setAttribute("id", "form_title_row_left"+rowNumber);
            title_row_left.setAttribute("class", "row form_subrow form_title_row form_title_row_left"); 
    
                var title_col_left = document.createElement("div");
                title_col_left.setAttribute("id", "title_col_left"+rowNumber);
                title_col_left.setAttribute("class", "col-xs-12 col-sm-12 title_col title_col_left form_subcol");
    
                if(currentRow == 1){
                        
                    var title_subrow = document.createElement("div");
                    title_subrow.setAttribute("id", "form_title_subrow"+rowNumber);
                    title_subrow.setAttribute("class", "row form_title_subrow form_title_row");
                        
                        var title_subcol_left = document.createElement("div");
                        title_subcol_left.setAttribute("id", "title_subcol_left"+rowNumber);
                        title_subcol_left.setAttribute("class", "col-xs-6 col-sm-6 title_col title_subcol_left form_subsubcol");
                        
                        title_subrow.appendChild(title_subcol_left);
                            
                        
                        var title_subcol_right = document.createElement("div");
                        title_subcol_right.setAttribute("id", "title_subcol_right"+rowNumber);
                        title_subcol_right.setAttribute("class", "col-xs-6 col-sm-6 title_col title_subcol_right form_subsubcol");
                        
                        title_subrow.appendChild(title_subcol_right);  
                    
                    
                    title_col_left.appendChild(title_subrow);

                }
    
                title_row_left.appendChild(title_col_left);
    

            col_form_left.appendChild(title_row_left);
            
        }
    
            var content_row_left = document.createElement("div");
            content_row_left.setAttribute("id", "form_content_row_left"+rowNumber);
            content_row_left.setAttribute("class", "row form_content_row_left form_content_row form_subrow"); 
        
                var content_col_left = document.createElement("div");
                content_col_left.setAttribute("id", "content_col_left"+rowNumber);
                content_col_left.setAttribute("class", "col-xs-12 col-sm-12 content_col content_col_left form_subcol"); 
    
                if(currentRow == 1){
                        
                    var content_subrow = document.createElement("div");
                    content_subrow.setAttribute("id", "form_content_subrow"+rowNumber);
                    content_subrow.setAttribute("class", "row form_content_subrow form_content_row");
                        
                        var content_subcol_left = document.createElement("div");
                        content_subcol_left.setAttribute("id", "content_subcol_left"+rowNumber);
                        content_subcol_left.setAttribute("class", "col-xs-6 col-sm-6 title_col content_subcol_left form_subsubcol");
                        
                        content_subrow.appendChild(content_subcol_left);
                            
                        
                        var content_subcol_right = document.createElement("div");
                        content_subcol_right.setAttribute("id", "content_subcol_right"+rowNumber);
                        content_subcol_right.setAttribute("class", "col-xs-6 col-sm-6 title_col content_subcol_left form_subsubcol");
                        
                        content_subrow.appendChild(content_subcol_right);  
                    
                    
                    content_col_left.appendChild(content_subrow);

                }
    
                content_row_left.appendChild(content_col_left);
    
            col_form_left.appendChild(content_row_left);
        
        row_form.appendChild(col_form_left);
    
    
        var col_form_right = document.createElement("div");
        col_form_right.setAttribute("id", "form_col_right"+rowNumber);
        col_form_right.setAttribute("class", "col-xs-8 col-sm-8 form_col form_col_right");
        
        if(currentRow != 2){
    
            var title_row_right = document.createElement("div");
            title_row_right.setAttribute("id", "form_title_row_right"+rowNumber);
            title_row_right.setAttribute("class", "row form_subrow form_title_row form_title_row_right"); 
    
                var title_col_right = document.createElement("div");
                title_col_right.setAttribute("id", "title_col_right"+rowNumber);
                title_col_right.setAttribute("class", "col-xs-12 col-sm-12 title_col title_col_right form_subcol");
    
                title_row_right.appendChild(title_col_right);
    
    
            col_form_right.appendChild(title_row_right);
            
        }

            var content_row_right = document.createElement("div");
            content_row_right.setAttribute("id", "form_content_row_right"+rowNumber);
            content_row_right.setAttribute("class", "row form_content_row_right form_content_row form_subrow"); 
        
                var content_col_right = document.createElement("div");
                content_col_right.setAttribute("id", "content_col_right"+rowNumber);
                content_col_right.setAttribute("class", "col-xs-12 col-sm-12 content_col content_col_right form_subcol");  
    
                content_row_right.appendChild(content_col_right);
    
            col_form_right.appendChild(content_row_right);

        row_form.appendChild(col_form_right);
    
    document.getElementById("bodyforms").appendChild(row_form);

    
            


    
    
}

function create_footerButton(){
    
    var submit_button = document.createElement("input");  
    submit_button.setAttribute("class", "button_save_changes");
    submit_button.setAttribute("id", "button_checkout");
    submit_button.setAttribute("type", "button");
    submit_button.setAttribute("value", "Guardar cambios");
    submit_button.setAttribute("onclick", "submit();");
    
    document.getElementById("footer").appendChild(submit_button);
    
    
}

function submit() {
    if(selectedTab == "data"){
        submit_changes();
    } else {
        if(isNewCard ==true) {
            submit_newCard();

        } else {
           if(defaultCardHasChanged == true) {
              setDefaultCard();
            } 

        }
    }
    
}


/*
*
*
*
*/
function populate_optAreas(rowNumber){
    
    var opt_main = document.createElement("input");
    var opt_aux1 = document.createElement("input");
    var opt_aux2 = document.createElement("input");


    opt_main.setAttribute("id", "opt_main"+rowNumber);
    opt_main.className = "opt_main";
    opt_main.setAttribute("type", "image");  
    opt_main.setAttribute ("src", "./img/opt_dots_light.png");

    opt_aux1.setAttribute("id", "opt_aux1"+rowNumber);
    opt_aux1.className = "opt_aux1";
    opt_aux1.setAttribute("type", "image"); 
    opt_aux1.setAttribute ("src", "./img/cancelIcon.png");
    
    opt_aux2.setAttribute("id", "opt_aux2"+rowNumber);
    opt_aux2.className = "opt_aux2";
    opt_aux2.setAttribute("type", "image");
    opt_aux2.setAttribute ("src", "./img/fav.png");

   
    document.getElementById("h_toggle"+rowNumber).appendChild(opt_main);
    document.getElementById("h_optDelete"+rowNumber).appendChild(opt_aux1);
    document.getElementById("h_optEdit"+rowNumber).appendChild(opt_aux2);

    
}

function find_defaultCard(){
     
    for(var i=0; i<cards.length; i++){
        
        if(cards[i].isDefault == 1){
            deSelect_cards(i);
            break;
            
        }
        
    }
    
    window.sessionStorage.removeItem("default_card_id");
    
}

/*
*
*
*
*/
function action_animateOpts(rowNumber){

    document.getElementById("opt_main"+rowNumber).onclick = function(){ 
        
        $('#h_optDelete'+rowNumber).animate({width: 'toggle'});
        $('#h_optEdit'+rowNumber).animate({width: 'toggle'});


    }
    
    document.getElementById("opt_aux1"+rowNumber).onclick = function(){
 
        //delete
        delete_card(rowNumber);   
    
    }
    document.getElementById("opt_aux2"+rowNumber).onclick = function(){
 
        //set default
        defcard = rowNumber;
        defaultCardHasChanged = true;
        isNewCard = false;
        deSelect_cards(defcard);

        
    }
    

}

function create_optAreas(rowNumber){
    
    var h_toggle = document.createElement("div");
    var h_optDelete = document.createElement("div");
    var h_optEdit = document.createElement("div");


    h_toggle.className = "h_toggle";
    h_toggle.setAttribute("id", "h_toggle"+rowNumber);

    h_optDelete.className = "h_optDelete";
    h_optDelete.setAttribute("id", "h_optDelete"+rowNumber);
    
    h_optEdit.className = "h_optEdit";
    h_optEdit.setAttribute("id", "h_optEdit"+rowNumber);

     document.getElementById("sel_info_opt_col"+rowNumber).appendChild(h_optDelete);
     document.getElementById("sel_info_opt_col"+rowNumber).appendChild(h_optEdit);
     document.getElementById("sel_info_opt_col"+rowNumber).appendChild(h_toggle);
    

        
}

function submit_newCard(){
    
    submit_form();
    
}

function deSelect_cards(defcard){
    
    var allcards = document.getElementsByClassName("opt_aux2");
    
    if(allcards.length != null){
        
        for(var i=0; i<allcards.length; i++){
            
            if(allcards[i].getAttribute("src") == "./img/sel_fav.png" ){
                
                document.getElementById("opt_aux2"+i).src = "./img/fav.png";
                document.getElementById("infoRow"+i).style.backgroundColor = "transparent";
                
            }
            
        if(i==defcard){
            
            document.getElementById("opt_aux2"+i).src = "./img/sel_fav.png";
            document.getElementById("infoRow"+i).style.backgroundColor = "gray"; 
            window.sessionStorage.setItem("default_card", JSON.stringify([cards[i].ccId , cards[i].hiddenNumber]));
        }
            
            
        }
        
    }
    
    
    
}

/*
*
*
*/
function delete_Row(rowNumber){
    
    var kids = document.getElementById("bodyforms").children;
    
    for(var i=0; i<kids.length; i++){
        
        if(kids[i].getAttribute("id") == ("infoRow"+rowNumber)){
            
            document.getElementById("bodyforms").removeChild(kids[i]);
            break;
            
        }
        
    }
    defcard=0;
    order=0;
    window.sessionStorage.removeItem("default_card_id");
        window.sessionStorage.removeItem("default_card");

    find_defaultCard();
 
    
}

/*
*
*
*/
function rearrange_Rows(){
    
    var kids = document.getElementById("bodyforms").children;
    
    for(var i=0; i<kids.length; i++){
        
            if(kids[i].getAttribute("id") != ("infoRow"+i)){
            
                var newKid =  kids[i];
                newKid.setAttribute("id", "infoRow"+i);
                document.getElementById("bodyforms").replaceChild(newKid, kids[i]);
                break;
            
        }
        
    }
    
}

function isNumberKey(evt){
    var charCode = (evt.which) ? evt.which : event.keyCode
    if (charCode > 31 && (charCode < 48 || charCode > 57))
        return false;
    return true;
}

function setDefaultCard() {
    var cardId  = cards[defcard].ccId;
    overlay_on();
    getSetUserDefaultCardResponse(idUser, cardId, function(returnMessage){
        if(returnMessage.type != 1) {
            createSNAlert("El cambio no se ha guardado, pruebe de nuevo por favor", "red", "fade" , "none");
        }
        
        overlay_off();
    });
}

