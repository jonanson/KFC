/*********************** VARIABLES ****************************/

//var myCart_name = [];
//var myCart_id = [];

var myCart = [];
var originPage;
var idUser = window.sessionStorage.getItem("idUser");

/*********************** FUNCTIONS ****************************/
app_push_chat.initialize();

$(document).ready(function() {
    
    if(JSON.parse(sessionStorage.getItem("temp_item")) != null){
       
        window.sessionStorage.removeItem("temp_item");
 
    }
    
    if(window.sessionStorage.getItem("originPage") !=null) {
        originPage = window.sessionStorage.getItem("originPage");
    }
    window.sessionStorage.removeItem("originPage");
     window.sessionStorage.setItem("originPage", "chat.html");
    if(JSON.parse(sessionStorage.getItem("myCart")) != null) {
        myCart = JSON.parse(sessionStorage.getItem("myCart"));
        if(myCart.length>0) {
            setCartImage(true);

        } else {
            setCartImage(false);

        }

    } else {
        myCart = [];
        setCartImage(false);

    }
    
    //backbutton management: set app to main menu
    document.addEventListener("backbutton", function(e) {
        e.preventDefault();
        window.location.href = originPage;      

    }, false);
});



var me = {};
me.avatar = "./img/User-48.png";

var you = {};
you.avatar = "./img/User-48.png";

function formatAMPM(date) {
    var hours = date.getHours();
    var minutes = date.getMinutes();
    var ampm = hours >= 12 ? 'PM' : 'AM';
    hours = hours % 12;
    hours = hours ? hours : 12; // the hour '0' should be '12'
    minutes = minutes < 10 ? '0'+minutes : minutes;
    var strTime = hours + ':' + minutes + ' ' + ampm;
    return strTime;
}            

//-- No use time. It is a javaScript effect.
function insertChat(who, text, time = 0){
    var control = "";
    var date = formatAMPM(new Date());
    
    if (who == "me"){
        
        control = '<li style="width:100%">' +
                        '<div class="msj macro">' +
                        '<div class="avatar">ME:'+'</div>' +
                            '<div class="text text-l">' +
                                '<p>'+ text +'</p>' +
                                '<p><small>'+date+'</small></p>' +
                            '</div>' +
                        '</div>' +
                    '</li>';                    
    } else{
        control = '<li style="width:100%;">' +
                        '<div class="msj-rta macro">' +
                            '<div class="text text-r">' +
                                '<p>'+text+'</p>' +
                                '<p><small>'+date+'</small></p>' +
                            '</div>' +
                        '<div class="avatar" style="padding:0px 0px 0px 10px !important">'+who+'</div>' +                                
                  '</li>';
    }
    setTimeout(
        function(){                        
            $("ul").append(control);

        }, time);
    
}

function resetChat(){
    $("ul").empty();
}

$(".mytext").on("keyup", function(e){
    if (e.which == 13){
        var text = $(this).val();
        if (text !== ""){
            insertChat("me", text);              
            $(this).val('');
        }
    }
});

//-- Clear Chat
resetChat();

function sumbit_message() {
    var text = $(".mytext").val();
    if (text !== ""){
        sendPushChatNotification(text);
        insertChat("me", text);              
        $(".mytext").val('');
    }  
}

function sendPushChatNotification (text) {
    
    getSendChatPushNotificationResponse(idUser, text, function (returnMessage){
        
    });      
    
}

function go_toCart() {
    
    var temp_item = JSON.parse(sessionStorage.getItem("temp_item"));
    var myCart = [];
    if(sessionStorage.getItem("myCart") != null) {
        myCart = JSON.parse(sessionStorage.getItem("myCart"));
    };
    
    if(temp_item != null){
        
        myCart.push(temp_item);    
        window.sessionStorage.setItem("myCart", JSON.stringify(myCart));
        
    }
    
    window.location.href = "cart.html";
    
}
//-- Print Messages
//insertChat("me", "Hello Tom...", 0);  
//insertChat("you", "Hi, Pablo", 1500);
//insertChat("me", "What would you like to talk about today?", 3500);
//insertChat("you", "Tell me a joke",7000);
//insertChat("me", "Spaceman: Computer! Computer! Do we bring battery?!", 9500);
//insertChat("you", "LOL", 12000);


//-- NOTE: No use time on insertChat.