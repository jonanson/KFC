var host = "http://151.80.149.226:8080/kfc";
//var host = "http://localhost:8080/kfc";
var bartenderService = "BartenderService";
var productService  = "ProductService";
var userService = "UserService";
var orderService = "OrderService";
var placeConnectionService = "PlaceConnectionService";
var signUpUserWS = "signUpUser";
var getUserWS = "getUser";
var getProductMenusWS = "getProductMenus";
var getProductTypesWS = "getProductTypes";
var getProductOptionsWS = "getProductOptions";
var getProductAdditionsWS = "getProductAdditions";
var getProductDrinksWS = "getProductDrinks";
var getProductDrinkSizesWS = "getProductDrinksSizes";
var getProductDessertsWS = "getProductDesserts";

var getProductAdditionsChildrenWS = "getProductAdditionsForChildren";
var getProductDessertsChildrenWS = "getProductDessertsForChildren";


var getProductMenuByIdWS = "getProductMenuById";
var getProductTypeByIdWS = "getProductTypeById";
var getProductOptionByIdWS = "getProductOptionById";
var getProductAdditionByIdWS = "getProductAdditionById";
var getProductDrinkByIdWS = "getProductDrinkById";
var getProductDrinkSizeByIdWS = "getProductDrinksSizeById";
var getProductDessertByIdWS = "getProductDessertById";

var getNonAttendedUserOrdersWS = "getNonAttendedUserOrders";

var getAttendedUserOrdersWS = "getAttendedUserOrders";
var getAttendingUserOrdersWS = "getAttendingUserOrders";
var getUserOrdersAtPlaceWS = "getUserOrdersAtPlace";

var getVipOrdersOfUserWS = "getVipOrdersOfUser";

var getOrderedDrinksWS = "getOrderDrinks";

var getPlaceConfigWS = "getPlaceConfig";
var loginWS = "logIn";
var logoutWS = "logOut";
var placeOrderWS = "placeOrder";
var placeReOrderWS = "placeReOrder";

var setUserDevicePushTokenWS  = "setUserDevicePushToken";
var setUserVisibilityWS  = "setUserVisibility";
var setUserDescriptionWS  = "setUserDescription";
var setUserImageLocalPathWS  = "setUserImageLocalPath";
var setUserDefaultCardWS  = "setUserDefaultCreditCard";

var getUserCardsWS = "getUserCreditCards";
var addCreditCardWS = "addCreditCard";
var deleteCreditCardWS  = "deleteCreditCard"
var SendChatPushNotificationPathWS = "sendChatMessage";

var setOrderAsVipWS  = "setOrderAsVip";
var setOrderAsNoVipWS  = "setOrderAsNoVip";

function getResponse(url, callback) {

	$.ajax({
	
		dataType: 'json',
		headers: {
			Accept:"application/json",
			"Access-Control-Allow-Origin": "*"
		},
		type:'GET',
		url:url,
		success: function(data) { 
			
			var rMessage;	
			
			if(data == undefined || data == null) {
				rMessage = {
						type:0,
						message:'Incorrect input',
						object:null
				};
			} else {
				rMessage = {
						type:1,
						object:data,
						message:null
				};
			}
			callback(rMessage);
		},
		error: function(data) {
			var rObject;
			rObject = {
					type : 0,
					message: "Error JS"
			};
			
			callback(rObject);
		}
	});
}
	
function getSetOrderAsVipResponse(idPlacedOrder, callback){
	
	var url = host + "/" + bartenderService + "/" + setOrderAsVipWS + "/" + idPlacedOrder;
	getWeNightResponse(url, function(weNightResponse) {
		
		var returnMessage = parseReturnMessage(weNightResponse);
		callback(returnMessage);
	});
} 

function getSetOrderAsNoVipResponse(idPlacedOrder, callback){
	
	var url = host + "/" + bartenderService + "/" + setOrderAsNoVipWS + "/" + idPlacedOrder;
	getWeNightResponse(url, function(weNightResponse) {
		
		var returnMessage = parseReturnMessage(weNightResponse);
		callback(returnMessage);
	});
} 

function getProductMenuRest(idPlace, callback){
	
	var url = host + "/" + productService + "/" + getProductMenusWS + "/" + idPlace;
	getResponse(url, function(response) {
		callback(response);
	});

} 
function getProductMenuByIdRest(id, callback){
	
	var url = host + "/" + productService + "/" + getProductMenuByIdWS + "/" + id;
	getResponse(url, function(response) {
		callback(response);
	});

} 
function getProductTypeByIdRest(id, callback){
	
	var url = host + "/" + productService + "/" + getProductTypeByIdWS + "/" + id;
	getResponse(url, function(response) {
		callback(response);
	});

}

function getProductTypesRest(idPlace, productMenuId, callback){
	
	var url = host + "/" + productService + "/" + getProductTypesWS + "/" + idPlace + "/" + productMenuId;
	getResponse(url, function(response) {
		callback(response);
	});

} 

function getProductOptionByIdRest(id, callback){
	
	var url = host + "/" + productService + "/" + getProductOptionByIdWS + "/" + id;
	getResponse(url, function(response) {
		callback(response);
	});

}

function getProductOptionsRest(idPlace, productTypeId, callback){
	
	var url = host + "/" + productService + "/" + getProductOptionsWS + "/" + idPlace + "/" + productTypeId;
	getResponse(url, function(response) {
		callback(response);
	});

} 

function getProductAdditionByIdRest(id, callback){
	
	var url = host + "/" + productService + "/" + getProductAdditionByIdWS + "/" + id;
	getResponse(url, function(response) {
		callback(response);
	});

}

function getProductAdditionsRest(idPlace, callback){
	
	var url = host + "/" + productService + "/" + getProductAdditionsWS + "/" + idPlace;
	getResponse(url, function(response) {
		callback(response);
	});

} 
function getProductAdditionsChildrenRest(idPlace, callback){
	
	var url = host + "/" + productService + "/" + getProductAdditionsChildrenWS + "/" + idPlace;
	getResponse(url, function(response) {
		callback(response);
	});

} 

function getProductDrinkByIdRest(id, callback){
	
	var url = host + "/" + productService + "/" + getProductDrinkByIdWS + "/" + id;
	getResponse(url, function(response) {
		callback(response);
	});

}

function getProductDrinksRest(idPlace, callback){
	
	var url = host + "/" + productService + "/" + getProductDrinksWS + "/" + idPlace;
	getResponse(url, function(response) {
		callback(response);
	});

} 


function getProductDrinkSizeByIdRest(id, callback){
	
	var url = host + "/" + productService + "/" + getProductDrinkSizeByIdWS + "/" + id;
	getResponse(url, function(response) {
		callback(response);
	});

}

function getProductDrinkSizesRest(idPlace, productDrinkId, callback){
	
	var url = host + "/" + productService + "/" + getProductDrinkSizesWS + "/" + idPlace + "/" + productDrinkId;
	getResponse(url, function(response) {
		callback(response);
	});

} 


function getProductDessertsRest(idPlace, callback){
	
	var url = host + "/" + productService + "/" + getProductDessertsWS + "/" + idPlace;
	getResponse(url, function(response) {
		callback(response);
	});getProductAdditionsRest

} 

function getProductDessertsChildrenRest(idPlace, callback){
	
	var url = host + "/" + productService + "/" + getProductDessertsChildrenWS + "/" + idPlace;
	getResponse(url, function(response) {
		callback(response);
	});getProductAdditionsRest

} 

function getProductDessertByIdRest(id, callback){
	
	var url = host + "/" + productService + "/" + getProductDessertByIdWS + "/" + id;
	getResponse(url, function(response) {
		callback(response);
	});

}

function getUserResponse(idUser, callback){
	
	var url = host + "/" + userService + "/" + getUserWS + "/"+idUser;
	getWeNightResponse(url, function(weNightResponse) {
		
		var weNightUserResponse;
		var returnMessage = parseReturnMessage(weNightResponse);
		var user;
		if(returnMessage.type == 1) {
			user = parseUser(weNightResponse);
		}
		weNightUserResponse = {
			returnMessage : returnMessage,
			user : user
		};
		callback(weNightUserResponse);
	});

} 

function getSignUpUserResponse(userName, encryptedPassword, telNumber, mail, callback){
	
    var encPassRepl = encryptedPassword.replace(/\//g, '---');
	var url = host + "/" + userService + "/" + signUpUserWS + "/" + userName + "/" + encPassRepl + "/" + telNumber + "/" + mail ;
	getWeNightReturnMessageResponse(url, function(weNightResponse) {
		
		var returnMessage = parseReturnMessage(weNightResponse);
		callback(returnMessage);
	});

} 

function getPlaceConfig(idPlace, callback) {
	var placeConfig = {
			id: 0,
			idPlace: 0,
			iv: '5be4926f40478232',
			encryptKey: '4ad3815e3936712191397cc337496f31'
		};
	callback(placeConfig);
}

function loginRest(username, encryptedPassword, idPlace, callback) {
	
	var encPassRepl = encryptedPassword.replace(/\//g, '---');
	var url = host + "/" + userService + "/" + loginWS + "/" + username + "/" + encPassRepl + "/" + idPlace;
	
	getResponse(url, function(response) {
		callback(response);
	});
}

function getLogoutRest(userSession, callback){
	
	var url = host + "/" + userService + "/" + logoutWS + "/" + userSession;
	getResponse(url, function(response) {
		callback(response);
	});

} 

function getAddCreditCardResponse(encryptedCreditCardNumber, encryptedCvv, encryptedZip, idUser, date, callback){

	encryptedCreditCardNumber = encryptedCreditCardNumber.replace(/\//g, '---');
	encryptedCvv = encryptedCvv.replace(/\//g, '---');
	encryptedZip = encryptedZip.replace(/\//g, '---');

	var url = host + "/" + userService + "/" + addCreditCardWS + "/"+encryptedCreditCardNumber + "/" + encryptedCvv + "/"+encryptedZip + "/"+idUser + "/"+date;
    
	getWeNightReturnMessageResponse(url, function(weNightResponse) {
		
		var returnMessage = parseReturnMessage(weNightResponse);
		callback(returnMessage);
	});

} 

function getUserCardsResponse(idUser, callback){
	
	var url = host + "/" + userService + "/" + getUserCardsWS + "/" + idUser ;
	getResponse(url, function(response) {
		callback(response);
	});

} 

function getDeleteCreditCardResponse(idCreditCard, callback){
	
	var url = host + "/" + userService + "/" + deleteCreditCardWS + "/" + idCreditCard;
	getWeNightReturnMessageResponse(url, function(weNightResponse) {
		
		var returnMessage = parseReturnMessage(weNightResponse);
		callback(returnMessage);
	});

} 


function getSetUserDevicePushTokenResponse(idUser, devicePushToken, callback){

    var url = host + "/" + userService + "/" + setUserDevicePushTokenWS + "/" + idUser + "/" + devicePushToken;
    getResponse(url, function(response) {
        callback(response);
    });
    
} 

function getSetUserVisibilityResponse(idUser, isVisible, callback){

    var url = host + "/" + userService + "/" + setUserVisibilityWS + "/" + idUser + "/" + isVisible;
    getWeNightReturnMessageResponse(url, function(weNightResponse) {
        var returnMessage = parseReturnMessage(weNightResponse);
        callback(returnMessage);
    });
    
} 

function getSetUserDescriptionResponse(idUser, description, callback){

    var url = host + "/" + userService + "/" + setUserDescriptionWS + "/" + idUser + "/" + description;
    getWeNightReturnMessageResponse(url, function(weNightResponse) {
        var returnMessage = parseReturnMessage(weNightResponse);
        callback(returnMessage);
    });
    
} 

function getSetUserImagePathResponse(idUser, imageLocalPath, callback){
    var pathEdited = imageLocalPath.replace(/\//g, '---');
    var url = host + "/" + userService + "/" + setUserImageLocalPathWS + "/" + idUser + "/" + pathEdited;
    getWeNightReturnMessageResponse(url, function(weNightResponse) {
        var returnMessage = parseReturnMessage(weNightResponse);
        callback(returnMessage);
    });

} 

function getSendChatPushNotificationResponse(idUser, text, callback){
    var url = host + "/" + chatService + "/" + SendChatPushNotificationPathWS + "/" + idUser + "/" + text;
    getWeNightReturnMessageResponse(url, function(weNightResponse) {
        var returnMessage = parseReturnMessage(weNightResponse);
        callback(returnMessage);
    });

} 

function getSetUserDefaultCardResponse(idUser, idCreditCard, callback){
    var url = host + "/" + userService + "/" + setUserDefaultCardWS + "/" + idUser + "/" + idCreditCard;
    getWeNightReturnMessageResponse(url, function(weNightResponse) {
        var returnMessage = parseReturnMessage(weNightResponse);
        callback(returnMessage);
    });

}

function getUserAttendedOrdersResponse(idUser, idPlace, callback){
	
	var url = host + "/" + bartenderService + "/" + getAttendedUserOrdersWS + "/" + idUser + "/" + idPlace;
	getWeNightListResponse(url, function(weNightResponse) {
		
		var weNightOrdersResponse;
		var returnMessage = parseReturnMessage(weNightResponse);
		var placedOrders;
		if(returnMessage.type == 1) {
			placedOrders = parsePlacedOrders(weNightResponse);
		}
		weNightOrdersResponse = {
			returnMessage : returnMessage,
			orders : placedOrders
		};
		callback(weNightOrdersResponse);
	});

} 

function getUserNotAttendedOrdersResponse(idUser, idPlace, callback){
	
	var url = host + "/" + bartenderService + "/" + getNonAttendedUserOrdersWS + "/" + idUser + "/" + idPlace;
	getWeNightListResponse(url, function(weNightResponse) {
		
		var weNightOrdersResponse;
		var returnMessage = parseReturnMessage(weNightResponse);
		var placedOrders;
		if(returnMessage.type == 1) {
			placedOrders = parsePlacedOrders(weNightResponse);
		}
		weNightOrdersResponse = {
			returnMessage : returnMessage,
			orders : placedOrders
		};
		callback(weNightOrdersResponse);
	});

} 

function getUserOrdersAttendingResponse(idUser, idPlace, callback){
	
	var url = host + "/" + bartenderService + "/" + getAttendingUserOrdersWS + "/" + idUser + "/" + idPlace;
	getWeNightListResponse(url, function(weNightResponse) {
		
		var weNightOrdersResponse;
		var returnMessage = parseReturnMessage(weNightResponse);
		var placedOrders;
		if(returnMessage.type == 1) {
			placedOrders = parsePlacedOrders(weNightResponse);
		}
		weNightOrdersResponse = {
			returnMessage : returnMessage,
			orders : placedOrders
		};
		callback(weNightOrdersResponse);
	});

}

function getVipOrdersOfUserResponse(idUser, idPlace, callback){
	
	var url = host + "/" + bartenderService + "/" + getVipOrdersOfUserWS + "/" + idUser + "/" + idPlace;
	getWeNightListResponse(url, function(weNightResponse) {
		
		var weNightOrdersResponse;
		var returnMessage = parseReturnMessage(weNightResponse);
		var placedOrders;
		if(returnMessage.type == 1) {
			placedOrders = parsePlacedOrders(weNightResponse);
		}
		weNightOrdersResponse = {
			returnMessage : returnMessage,
			orders : placedOrders
		};
		callback(weNightOrdersResponse);
	});

}

function getUserOrdersAtPlaceResponse(idUser, idPlace, callback){
	
	var url = host + "/" + bartenderService + "/" + getUserOrdersAtPlaceWS + "/" + idUser + "/" + idPlace;
	getWeNightListResponse(url, function(weNightResponse) {
		
		var weNightOrdersResponse;
		var returnMessage = parseReturnMessage(weNightResponse);
		var placedOrders;
		if(returnMessage.type == 1) {
			placedOrders = parsePlacedOrders(weNightResponse);
		}
		weNightOrdersResponse = {
			returnMessage : returnMessage,
			orders : placedOrders
		};
		callback(weNightOrdersResponse);
	});

} 


function getOrderDrinksResponse(idPlacedOder, callback){
	
	var url = host + "/" + bartenderService + "/" + getOrderedDrinksWS + "/" + idPlacedOder;
	getWeNightListResponse(url, function(weNightResponse) {
		
		var weNightOrderDrinksResponse;
		var returnMessage = parseReturnMessage(weNightResponse);
		var drinks;
		if(returnMessage.type == 1) {
			drinks = parsePlacedOrderDrinks(weNightResponse);
		}
		weNightOrderDrinksResponse = {
			returnMessage : returnMessage,
			drinks : drinks
		};
		callback(weNightOrderDrinksResponse);
	});

} 

function placeOrderRest(idUser, idPlace, tipAmount, ids, notes, callback){
    
    
    var url = host + "/" + orderService + "/" + placeOrderWS + "/" +idUser + "/" + idPlace + "/" +tipAmount+ "/"+ids +"/" +notes + "/" ;
    
    getResponse(url, function(response) {        
        callback(response);
    });

} 

function getPlaceReOrderResponse(idOrder, callback){
    
    
    var url = host + "/" + orderService + "/" + placeReOrderWS + "/" +idOrder;
    
    getWeNightResponse(url, function(weNightResponse) {
        
    var weNightPlaceOrderResponse;
        
        var returnMessage = parseReturnMessage(weNightResponse);
        var order;
        
        if(returnMessage.type == 1) {
            order = parseOrder(weNightResponse);
        }
        weNightPlaceOrderResponse = {
            
            returnMessage : returnMessage,
            order : order
        };
        
        callback(weNightPlaceOrderResponse);
    });

} 


function parseOrder(weNightResponse) {
    
    var order = weNightResponse.weNightObject;
    var placedOrder = {
            id: order.children[5].textContent,
            barmanId: order.children[3].textContent,
            creditCardId: order.children[4].textContent,
            orderPrice: order.children[7].textContent,
            paymentMethod: order.children[9].textContent,
            placeId: order.children[11].textContent,
            tip: order.children[13].textContent,
            placementDate: order.children[12].textContent,
            pickedUp: order.children[10].textContent,
            paid: order.children[7].textContent,
            attending: order.children[2].textContent,
            attended: order.children[0].textContent,
            attendedDate: order.children[1].textContent,
            userId: order.children[14].textContent,
            notes: order.children[6].textContent,
            vip: order.children[15].textContent
    };
    
    
        
    return placedOrder;
        
}


function parsePlacedOrderDrinks(weNightResponse) {
	var drinks = [];
	for(var x=0;x<weNightResponse.weNightObjects.children.length;x++) {
	
		var dt = weNightResponse.weNightObjects.children[x];
		var drink = {
			id: dt.children[8].textContent,
			description: dt.children[0].textContent,
			placedOrderId: dt.children[10].textContent,
			placeId: dt.children[9].textContent,
			drinkTypeId: dt.children[7].textContent,
			drinkBrandId: dt.children[2].textContent,
			drinSubtypeId: dt.children[0].textContent,
			drinkHowId: dt.children[4].textContent,
			drinkHowPlusId: dt.children[6].textContent,
			drinkHowPlus2Id: dt.children[5].textContent,
			drinkGarnishId: dt.children[3].textContent
		};
		drinks.push(drink);
	}
	return drinks;

}


function parsePlacedOrders(weNightResponse) {
var orders = [];
	for(var x=0;x<weNightResponse.weNightObjects.children.length;x++) {
	
		var order = weNightResponse.weNightObjects.children[x];
		var placedOrder = {
				id: order.children[5].textContent,
	            barmanId: order.children[3].textContent,
	            creditCardId: order.children[4].textContent,
	            orderPrice: order.children[7].textContent,
	            paymentMethod: order.children[9].textContent,
	            placeId: order.children[11].textContent,
	            tip: order.children[13].textContent,
	            placementDate: order.children[12].textContent,
	            pickedUp: order.children[10].textContent,
	            paid: order.children[7].textContent,
	            attending: order.children[2].textContent,
	            attended: order.children[0].textContent,
	            attendedDate: order.children[1].textContent,
	            userId: order.children[14].textContent,
	            notes: order.children[6].textContent,
	            vip: order.children[15].textContent
		};
		orders.push(placedOrder);
	}
	return orders;
    

}