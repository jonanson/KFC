
/*********************** VARIABLES ****************************/

var idUser = window.sessionStorage.getItem("idUser");
var username = window.sessionStorage.getItem("username");
var myCart = [];
var opened = false;
/*********************** FUNCTIONS ****************************/
app_push_menu.initialize();

$(document).ready(function() {

    if(JSON.parse(sessionStorage.getItem("myCart")) != null) {
        myCart = JSON.parse(sessionStorage.getItem("myCart"));
        if(myCart.length>0) {
            setCartImage(true);

        } else {
            setCartImage(false);

        }

    } else {
        myCart = [];
        setCartImage(false);

    }
    var token = window.sessionStorage.getItem("pushToken");
    //we save teh origin for coming back
    if(sessionStorage.getItem("originPage") !=null) {
        window.sessionStorage.removeItem("originPage");
    }
    window.sessionStorage.setItem("originPage", "mainMenu.html");

    sendToken(idUser, token);

    //backbutton management: set app to background run
    document.addEventListener("backbutton", function(e) {
        e.preventDefault();
        navigator.Backbutton.goHome(function() {
            console.log('success')
        }, function() {
            console.log('fail')
        });
    }, false);
    
});
   
function go_toOrders(){
    
    var temp_item = JSON.parse(sessionStorage.getItem("temp_item"));
    var myCart = [];
    if(sessionStorage.getItem("myCart") != null) {
        myCart = JSON.parse(sessionStorage.getItem("myCart"));
    };
    
    if(temp_item != null){
        
        myCart.push(temp_item);    
        window.sessionStorage.setItem("myCart", JSON.stringify(myCart));
        
    }
    
    window.location.href = "userOrders.html";
    
}

function go_toCart() {
    
    var temp_item = JSON.parse(sessionStorage.getItem("temp_item"));
    var myCart = [];
    if(sessionStorage.getItem("myCart") != null) {
        myCart = JSON.parse(sessionStorage.getItem("myCart"));
    };
    
    if(temp_item != null){
        
        myCart.push(temp_item);    
        window.sessionStorage.setItem("myCart", JSON.stringify(myCart));
        
    }
    
    window.location.href = "cart.html";
    
}

function openOrCloseNav() {
    if(opened == true) {
       closeNav();
    } else {
        openNav();
    }
}

function sendToken(idUser, token) {
    token = ""+token; 
    getSetUserDevicePushTokenResponse(idUser, token, function(returnMessage){});
}

function goToWeniteWeb(){
    window.location="https://jaorue.wixsite.com/weniteapp";
}