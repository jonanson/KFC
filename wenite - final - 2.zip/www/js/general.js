
/*********************** VARIABLES ****************************/


/*********************** FUNCTIONS ****************************/



/**
*
*This function will create an alert displaying a message.
*
*@msgText    - The String variable you want the alert to show in its text.
*@alertColor - The color you want the alert to be. We will use 4 types:
*                 - Green: Successful alerts.
*                 - Red: Error alerts.
*                 - Yellow: Warning alerts.
*                 - Blue: Informative alerts.
*@fading     - This variable is a String that we set beforehand. 
*              It's used in the styling of the alert to determine the behaviour:
*                 - fade: The alert will fade afer a time, you can also close it hitting the "x".
*                 - nofade: The alert won't fade and you have to click the "x" to make it disappear.
*@url        - The page you will be redirected to after pressing the "x".
*
**/
function createSNAlert(msgText, alertColor, fading, url){
    
        var alert = document.createElement("div");       /*Creation of the alert*/
       
        alert.className="alert"+fading;             
        alert.innerHTML = msgText;
        alert.style.backgroundColor=alertColor;
    
        var span = document.createElement("span");       /*Creation of the "x" and adding it to the alert*/
        span.className="closebtn";
    
        if(alertColor == "green"){
    
            span.onclick= function(){
            
                this.parentElement.style.display='none';
                if(url != "none"){ 
                    window.location = 'mainMenu.html';
                }
            };
            
        }else{
            
            span.onclick= function(){this.parentElement.style.display='none';};     
            
        }
    
        span.innerHTML = "&times;";
        alert.appendChild(span);
    
        document.getElementById("content").appendChild(alert); /*Add the alert to the document*/
        
}


function processNotification(data) {
     
    if(data.title == "Pedido recibido") {
        alert(data.message);
    } else if(data.aps.title == "Pedido en marcha") {
        alert(data.aps.message);
    } else if(data.title == "Pedido en marcha") {
        alert(data.message);
    } else if(data.title == "Hecho!") {
    
        var text = data.message;
        text = text+"\n"+"Quiere preparar el código para recogerlo?"
        if(confirm(text) == true) {
           window.location = "userQR.html";
        } 
    } else if (data.title == "Chat") {
        var l = window.location+'';
        var loc =l.split("/");
        var locText = loc[loc.length-1];
        if(locText == "chat.html") {
            
           var user=data.message.split(":")[0];
           var message=data.message.split(":");
            var text="";
            for(var x=1;x<message.length;x++) {
                if(x!=1) {
                   text = text+":"+message[x];
                } else {
                    text = text+message[x];
                }
                
            }
           insertChat(user, text);  
        }       
    }
    
}

function setCartImage(isFull) {
    var imageSrc = "";
  
    if(isFull == true) {
        imageSrc = "./img/full_basket_icon.png";
    } else {
       imageSrc = "./img/basketIcon.png";
    }
   
    
    document.getElementById("button_cart").src = imageSrc;
}

/**
*
*This function sends the logout message to the server using the user session and deals with the response.
*
**If the response from the server is affirmative, the user will log out correctly and be redirected to the login page.
*
**In case of a negative response from the server there will be an error handling function to deal with this.
*
**/
function logOut(){
    
    var session = window.sessionStorage.getItem("sessionKey");
            
    getLogoutResponse(session, function(weNightReturnMessageResponse){
    
        var msg = weNightReturnMessageResponse.message;
        var type = weNightReturnMessageResponse.type;
        
        window.sessionStorage.clear();
        window.location = 'login.html';   
    });   
}

function overlay_on() {
    document.getElementById("overlay").style.display = "block";
}

function overlay_off() {
    document.getElementById("overlay").style.display = "none";
}

Element.prototype.remove = function() {
    this.parentElement.removeChild(this);
}
NodeList.prototype.remove = HTMLCollection.prototype.remove = function() {
    for(var i = this.length - 1; i >= 0; i--) {
        if(this[i] && this[i].parentElement) {
            this[i].parentElement.removeChild(this[i]);
        }
    }
}
