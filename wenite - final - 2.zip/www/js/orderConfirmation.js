/*********************** VARIABLES ****************************/
var idUser = sessionStorage.getItem("idUser");
//var idUser = 3;
var idPlace = 0;

var order;
var goOnBack="";

var origin;

var defaultCardHasChanged = false;
/*********************** FUNCTIONS ****************************/

$(document).ready(function() {
    order = window.sessionStorage.getItem("placedOrderId");
    var l3 = document.getElementById("l3");
    if(order !=null) {
        document.getElementById("order_area").innerHTML = order;
    }
    if(sessionStorage.getItem("originPage") !=null) {
        origin = sessionStorage.getItem("originPage");
    }
    

    //backbutton management: set app to main menu
    document.addEventListener("backbutton", function(e) {
        e.preventDefault();
        window.location.href = "mainMenu.html";
    }, false);
    

});