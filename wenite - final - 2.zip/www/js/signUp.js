
/*********************** VARIABLES ****************************/

var path_img = "./img/";

var username_ok = false;
var passwords_ok = false;
var phone_ok = false;
var email_ok = false;

var default_usernameField = "e.g   JohnW1ck_32";
var default_passwordField = "e.g  DdandDell10n$$";
var default_passwordConfirmField = "Confirm Password";
var default_phoneNumField = "2025550174";
var default_emailField = "e.g  johnw32@gmail.com";

var username_value;
var password_value;
var confirmPassword_value;
var phoneNumber_value;
var email_value;

var msg_emtpy = "This field is empty!";
var msg_noConfirmation = "Please confirm password";
var msg_passwordsUnequal = "Password and confirmation have to be equal";
var msg_weakPassword = "Password not strong enough!";
var msg_not9digits = "Insert a 9 digit phone number";
var msg_incompleteInputs = "Please fix the field contents";


/*********************** FUNCTIONS ****************************/


/**
*
*This function is used to register a new user.
*It encrypts the form's data and sends it using getSignUpResponse.
*Then an alert will be created with the message from the server.
*
*@username    - In this case we will use the value from the username field.
*
*@password    - We will use the value from the password field.
*
*@phoneNumber - In this case the value from the phone number field.
*
*@email       - We will use the value from the email field.
*
*@idPlace     - The id number of the local.
*
**/
function signUp(username, password, phoneNumber, email, idPlace) {

    encrypt(password,idPlace,function(encryptedPassword){
    
        getSignUpUserResponse(username, encryptedPassword, phoneNumber, email, function(weNightResponse){
    
        var msg = weNightResponse.message;
        var type = weNightResponse.type;
    
        if(type == 1){
            createSNAlert(msg, "green", "nofade");
        }else{
            createSNAlert(msg, "red", "nofade"); 
        }
        });
    });
}

/**
*
*This function resets the form in a few steps:
*It clears the form of check images next to the textboxes (correct and incorrect).
*It resets the style of the textboxes (the border changes color when it's wrong).
*Empties the textboxes (content changes, showing the error message if wrong).
*Sets the default value again showing the examples on how to fill the textboxes.
*
**/
function clear_Fields(){
    
    clear_checkImgs("area_username");
    clear_checkImgs("area_password");
    clear_checkImgs("area_passwordConfirmation");
    clear_checkImgs("area_phoneNumber");
    clear_checkImgs("area_email");
    
    resetFieldStyling("usernameField");
    resetFieldStyling("passwordField");
    resetFieldStyling("passwordConfirmField");
    resetFieldStyling("phoneNumField");
    resetFieldStyling("emailField"); 


    document.getElementById("signUp_form").reset();
    
    resetFieldValue("usernameField");
    resetFieldValue("passwordField");
    resetFieldValue("passwordConfirmField");
    resetFieldValue("phoneNumField");
    resetFieldValue("emailField");

    var username_ok = false;
    var passwords_ok = false;
    var phone_ok = false;
    var email_ok = false;
    
}

/**
*
*This function resets the value of the textfield to the default one.
*
*@fieldName - The Id name of the textfield
*
**/
function resetFieldValue(fieldName){
    
     document.getElementById(fieldName).placeholder = default_ + fieldName;
    
}

/**
*
*It resets the style of the field to the default parameters.
*
*@fieldName - The Id name of the textfield.
*
**/
function resetFieldStyling(fieldName){
    
    document.getElementById(fieldName).style.color = "black";
    document.getElementById(fieldName).style.border = "1px solid #adadad ";
    
}

/**
*
*This function checks all the variables of the inputs (they change everytime the value of the inputs change).
*If all the input booleans are set to true, it will do the signUp action. 
*Otherwise it will create an alert asking the user to fix the inputs.
*
**/
function check_Inputs(){
    
    if(username_ok && passwords_ok && phone_ok && email_ok){    
    
        username_value = document.getElementById("usernameField").value;
        password_value = document.getElementById("passwordField").value;
        phoneNumber_value = document.getElementById("phoneNumField").value;
        email_value = document.getElementById("emailField").value;
        
        signUp(username_value, password_value, phoneNumber_value, email_value, 0);
        
    }else{   
        createSNAlert(msg_incompleteInputs, "red", "nofade");
    }  
}

/**
*
*This function checks the fieldtext of the form reserved for the username.
*It does these checkings and otherwise it will pass to an error state:
*   - The field is not empty.
*
**/
function check_Username(){

    username_value = document.getElementById("usernameField").value;
    
    if(!username_value){
        
            username_ok = false;
            clear_checkImgs("area_username");
            add_checkImg("area_username", "redWrong", "usernameField");
            fieldError("usernameField", msg_emtpy);
    }else{
            
            username_ok = true;
            clear_checkImgs("area_username");
            add_checkImg("area_username", "greenOK", "usernameField");
    }
}

/**
*
*This function checks the fieldtext of the form reserved for the password confirmation.
*It does these checkings and otherwise it will pass to an error state:
*   - Password and confirmation are equal.
*   - The field is not empty.
*
**/
function check_PasswordConfirmation(){
    
    password_value = document.getElementById("passwordField").value;
    confirmPassword_value = document.getElementById("passwordConfirmField").value;

    if(!confirmPassword_value){
        
            passwords_ok = false;
            clear_checkImgs("area_passwordConfirmation");
            add_checkImg("area_passwordConfirmation", "redWrong", "passwordConfirmField");
            fieldError("passwordConfirmField", msg_noConfirmation);
    }else{ 
            
            if(password_value!=confirmPassword_value){
            
                passwords_ok = false;     
                clear_checkImgs("area_passwordConfirmation");
                add_checkImg("area_passwordConfirmation", "redWrong", "passwordConfirmField");
                fieldError("passwordConfirmField", msg_passwordsUnequal);
            }else{
                    
                    passwords_ok = true;     
                    clear_checkImgs("area_passwordConfirmation");
                    add_checkImg("area_passwordConfirmation", "greenOK", "passwordConfirmField");
            }
    }
}

/**
*
*This function checks the fieldtext of the form reserved for the password.
*It does these checkings and otherwise it will pass to an error state:
*   - It has a character in uppercase.
*   - It has a character in lowercase.
*   - It has a number.
*   - The field is not empty.
*
**/
function check_Password(){
    
    password_value = document.getElementById("passwordField").value;
    
    var upperCase = false;
    var lowerCase = false;
    var hasNumber = false;
    var pass_valid = false;
    
    if(!password_value){
        
        clear_checkImgs("area_password");
        add_checkImg("area_password", "redWrong", "passwordField");
        fieldError("passwordField", msg_emtpy);
        
    }else{ 
            
            var i=0;
            var character='';
        
            while (i <= password_value.length){
                
                character = password_value.charAt(i);
                
                if (!isNaN(character * 1)){
                    hasNumber = true;
                    }else{
                        
                        if (character == character.toUpperCase()){ upperCase = true; }
                        if (character == character.toLowerCase()){ lowerCase = true; }
                    }
            
                if(hasNumber && upperCase && lowerCase){
                    
                    pass_valid=true;
                    break;
                } 
                i++;
            }
            
            if(pass_valid){
            
                clear_checkImgs("area_password");
                add_checkImg("area_password", "greenOK", "passwordField");
            
            }else{
                
                    clear_checkImgs("area_password");
                    add_checkImg("area_password", "redWrong", "passwordField");
                    fieldError("passwordField", msg_weakPassword);     
            }
    } 
}

/**
*
*This function checks the fieldtext of the form reserved for the phone number.
*It does these checkings and otherwise it will pass to an error state:
*   - The value is 9 characters long.
*   - The value is an integer.
*   - The field is not empty.
*
**/
function check_Phone(){

    phoneNumber_value = document.getElementById("phoneNumField").value;
    
    if(phoneNumber_value.length==9 && !isNaN(phoneNumber_value)){
        
        phone_ok = true; 
        clear_checkImgs("area_phoneNumber");
        add_checkImg("area_phoneNumber", "greenOK", "phoneNumField");
        
    }else{ 
        
        if(!phoneNumber_value){
            
            phone_ok = false;
            clear_checkImgs("area_phoneNumber");
            add_checkImg("area_phoneNumber", "redWrong", "phoneNumField");
            fieldError("phoneNumField", msg_emtpy);
            
        }else{ 
            
            if(isNaN(phoneNumber_value)){
            
                phone_ok = false;
                clear_checkImgs("area_phoneNumber");
                add_checkImg("area_phoneNumber", "redWrong", "phoneNumField");
                fieldError("phoneNumField", msg_not9digits);
            
            }else{ 
                
                if(phoneNumber_value.length<9){
            
                    phone_ok = false;
                    msg = "Insert a 9 digit phone number";
                    clear_checkImgs("area_phoneNumber");
                    add_checkImg("area_phoneNumber", "redWrong", "phoneNumField");
                    fieldError("phoneNumField", msg_not9digits);
            
                } 
            }
        }
    }  
}
    
/**
*
*This function checks the fieldtext of the form reserved for the email.
*It does these checkings and otherwise it will pass to an error state:
*   - The field contains the @ sign.
*   - There is something before and after the @ sign.
*   - The field is not empty.
*
**/
function check_eMail(){
    
    email_value = document.getElementById("emailField").value;
    
      /* if(email_value.includes("@")){
           
           if(email_value.split("@")[0]!="" && email_value.split("@")[1]!=""){
               
                email_ok = true;   
                clear_checkImgs("area_email");
                add_checkImg("area_email", "greenOK", "emailField");
            }
        }else{ 
            
            if(!email_value){
                
                email_ok = false;
                msg = "This field is empty!";
                clear_checkImgs("area_email");
                add_checkImg("area_email", "redWrong", "emailField");
                fieldError("emailField", msg);
            }else{
                
                email_ok = false;
                msg = "That's not an email!";
                clear_checkImgs("area_email");
                add_checkImg("area_email", "redWrong", "emailField");
                fieldError("emailField", msg);
            }
       }*/
    
                email_ok = true;   
                clear_checkImgs("area_email");
                add_checkImg("area_email", "greenOK", "emailField");
}

/**
*
*With this function we clear all the images next to the textfield of the form (both correct and incorrect check images).
*
*@areaName   - As the image is set in the area and not in the textfield, this makes reference to the area where the textfield belongs.
*
**/
function clear_checkImgs(areaName){
    
    area = document.getElementById(areaName);
    
    var images = area.getElementsByClassName("checkedImage");
    var l = images.length;
    
    for (var i = 0; i < l; i++) {
        images[i].parentNode.removeChild(images[i]);
    }  
}

/**
*
*This function adds an image next to the texfield in the form (correct or incorrect).
*This also changes the textfields border and text color in case we come from an error state.
*
*@areaName   - As the image is set in the area and not in the textfield, this makes reference to the Id of the area where the textfield belongs.
*
*@imageName  - The name will determinate which image we add:
*                   - If it's correct: We add a green check image 
*                   - If it's incorrect: We add a red cross image
*
*@fieldName  - The Id name of the textfield we want to change into this error state. 
*
**/
function add_checkImg(areaName, imageName, fieldName){
    
        resetFieldStyling(fieldName);                    /* Reset the style of the textfield */
    
        check_img = document.createElement("img");       /* Create the img in the document */
        check_img.src = path_img + imageName + ".png";
        check_img.className = "checkedImage";            /* We put the classname "checkedImage" so it follows the style for these images */
    
        document.getElementById(areaName).appendChild(check_img );
    
}

/**
*
*This function sets the the fieldtext selected to an error state, with the error message we choose.
*It changes the border color to red and the field value to the error message.
*
*@fieldname - The Id name of the textfield we want to change into this error state. 
*
*@errorMsg  - The message we want the textfield to display as error message.
*
**/
function fieldError(fieldName, errorMsg){
    
    var field = document.getElementById(fieldName);
    
    field.style.borderColor="red";  /* Changing the styling of the border */ 
    field.style.border="solid";
    
    field.value="";                 /* Changing the value and the color of the text */ 
    field.placeholder = errorMsg;
    field.style.color="red";
    
}

/**
*
*This function will create an alert displaying a message.
*
*@msgText    - The String variable you want the alert to show in its text.
*@alertColor - The color you want the alert to be. We will use 4 types:
*                 - Green: Successful alerts.
*                 - Red: Error alerts.
*                 - Yellow: Warning alerts.
*                 - Blue: Informative alerts.
*@fading     - This variable is a String that we set beforehand. 
*              It's used in the styling of the alert to determine the behaviour:
*                 - fade: The alert will fade afer a time, you can also close it hitting the "x".
*                 - nofade: The alert won't fade and you have to click the "x" to make it disappear.
*
**/
function createSNAlert(msgText, alertColor, fading){
    
        var alert = document.createElement("div");       /*Creation of the alert*/
        alert.className="alert"+fading;             
        alert.innerHTML = msgText;
        alert.style.backgroundColor=alertColor;
    
        var span = document.createElement("span");       /*Creation of the "x" and adding it to the alert*/
        span.className="closebtn";
    
        if(alertColor == "green"){
    
            span.onclick= function(){
            
                this.parentElement.style.display='none'; 
                window.location = 'login.html';
            
                if(url != "none"){ 
                    window.location = 'login.html';
                }
            };
            
        }else{
            
            span.onclick= function(){this.parentElement.style.display='none';};     
            
        }
        span.innerHTML = "&times;";
        alert.appendChild(span);
        
        document.getElementById("signUp_form").appendChild(alert); /*Add the alert to the document*/
        
}