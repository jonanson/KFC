
/*********************** VARIABLES ****************************/

var name = "";
var description = "";
var email = "";
var photo = "";
var visibility = true;
var selectedTab;
var currentRow = 0;

var pictureSource;   // picture source
var destinationType; // sets the format of returned value

var idUser = sessionStorage.getItem("idUser");
//var idUser = 3;

profile_picture = sessionStorage.getItem("profile_picture");

var origin;
/*********************** FUNCTIONS ****************************/

app_push_user_data.initialize();

$(document).ready(function() {
    if(sessionStorage.getItem("originPage") !=null) {
        origin = sessionStorage.getItem("originPage");
    }
    if(origin =="checkout") {
        changeTab("cards");
    } else {
        changeTab("data");
    }
    create_footerButton();

});

/*
*
*
*
*/
function changeTab(tab){
      

    document.getElementById("bodyforms").innerHTML = "";
    currentRow = 0;
    
    if(tab == "cards"){
                
        //document.getElementById("toggle_data").disabled = false;
        document.getElementById("toggle_cards").className  = "selected_tablinks";
        document.getElementById("toggle_data").className  = "tablinks";

        action_showCards();
        selectedTab = "cards";
       //eliminamos la row preparada para el postal code
        //document.getElementById("bodyforms").removeChild(document.getElementById("formRow2"));
    }else{
        
        if(tab == "data"){
            
            document.getElementById("toggle_cards").className  = "tablinks";
            document.getElementById("toggle_data").className  = "selected_tablinks";
            create_data();
            getInfo();
            selectedTab = "data";
           
           //Eliminamos la row preparada para la imagen de usuarios y el check
            document.getElementById("bodyforms").removeChild(document.getElementById("form_row4"));
            document.getElementById("bodyforms").removeChild(document.getElementById("form_row2"));
            //document.getElementById("button_checkout").onclick = 'submit_changes()';

        }
        
    }
      
      
  }     

function populate_fields(){
    
    document.getElementById("form_col_right0").innerHTML = name;
    document.getElementById("form_email").placeholder = email;
    document.getElementById("form_email").disabled = true;

    document.getElementById("form_description").placeholder = description;
    //if(visibility ==true) {
    //    document.getElementById("form_toggle").checked = visibility;
//
//    }
    //document.getElementById("form_toggle").checked = visibility;
   // document.getElementById("num4").placeholder = photo;
    
    
}

/*
*
*
*
*/
function create_dataRow(){
    
    var form_row = document.createElement("div");
    form_row.setAttribute("id", "form_row" + currentRow);
    form_row.setAttribute("class", "row form_row");  
  
    var form_col_left = document.createElement("div"); 
    form_col_left.setAttribute("id", "form_col_left" + currentRow);
    form_col_left.setAttribute("class", "col-xs-4 col-sm-4 form_col form_col_left");

    form_row.appendChild(form_col_left);

    var form_col_right = document.createElement("div"); 
    form_col_right.setAttribute("id", "form_col_right" + currentRow);
    form_col_right.setAttribute("class", "col-xs-8 col-sm-8 form_col form_col_right");
    
    if(currentRow == 5){

        var form_subrow = document.createElement("div");
        form_subrow.setAttribute("id", "form_subrow" + currentRow);
        form_subrow.setAttribute("class", "row form_subrow"); 

        var form_subcol_left = document.createElement("div"); 
        form_subcol_left.setAttribute("id", "form_subcol_left" + currentRow);
        form_subcol_left.setAttribute("class", "col-xs-5 col-sm-5 form_subcol form_subcol_left");

        form_subrow.appendChild(form_subcol_left);


        var form_subcol_right = document.createElement("div"); 
        form_subcol_right.setAttribute("id", "form_subcol_right" + currentRow);
        form_subcol_right.setAttribute("class", "col-xs-7 col-sm-7 form_subcol form_subcol_right");

        form_subrow.appendChild(form_subcol_right);


        form_col_right.appendChild(form_subrow);            

    }
    
    form_row.appendChild(form_col_right);
    
    document.getElementById("bodyforms").appendChild(form_row);

    
    
}

function create_data(){
    
  for(var i=0; i<6; i++){
      
      create_dataRow();
      currentRow += 1;
      
  }  
   
    create_tags();
    create_content();
    
    //create_footerButton();
    
    //document.getElementById("button_checkout").setAttribute("onclick" ,"submit_changes();");
   
}

function create_tags(){
    
    document.getElementById("form_col_left0").innerHTML = "Usuario";
    document.getElementById("form_col_left1").innerHTML = "Email";
    //document.getElementById("form_col_right2").innerHTML = "Recibir notificaciones";
    document.getElementById("form_col_left3").innerHTML = "Descripción";
    //document.getElementById("form_col_left4").innerHTML = "Imagen";
    document.getElementById("form_col_left5").innerHTML = "QR Code"; 
    
}

function create_content(){    
    
    var form_email = document.createElement("input"); 
    form_email.setAttribute("id", "form_email");
    form_email.setAttribute("type", "text");
    form_email.setAttribute("class", "form_field form_content");
    
    document.getElementById("form_col_right1").appendChild(form_email);
    
    
    //var push_toggle = document.createElement("input");
    //push_toggle.setAttribute("id", "form_toggle");
    //push_toggle.setAttribute("type", "checkbox");
    //push_toggle.setAttribute("class", "form_content");
    
    //document.getElementById("form_col_left2").appendChild(push_toggle);
    
    
    var form_description = document.createElement("textarea");
    form_description.setAttribute("id", "form_description");
    form_description.setAttribute("class", "form_content");
    form_description.setAttribute("rows", "2");
    form_description.setAttribute("cols", "25");

    document.getElementById("form_col_right3").appendChild(form_description);
    
    
    //var form_profilepic = document.createElement("img"); 
    //form_profilepic.setAttribute("id", "form_profilepic");
    ////form_profilepic.setAttribute("type", "image");
    //form_profilepic.setAttribute("class", "form_content");
    //form_profilepic.setAttribute("onclick", "get_profilePic();");
    //
    //if(profile_picture != null){
    //    
    //    form_profilepic.setAttribute.src = profile_picture;
    //    
    //}else{
    //    
    //    form_profilepic.setAttribute("src", "./img/logsignup.png");
    //    
    //}    
    
    //document.getElementById("form_col_right4").appendChild(form_profilepic);
    
    var form_qr = document.createElement("input"); 
    form_qr.setAttribute("id", "form_qr");
    form_qr.setAttribute("type", "image");
    form_qr.setAttribute("class", "form_content");
    form_qr.setAttribute("src", "./img/qr.png");
    
    document.getElementById("form_subcol_left5").appendChild(form_qr);

    
    var form_button_qr = document.createElement("input"); 
    form_button_qr.setAttribute("id", "form_button_qr");
    form_button_qr.setAttribute("type", "button");
    form_button_qr.setAttribute("class", "form_content btn");
    form_button_qr.value = "Use Code";
    form_button_qr.setAttribute("onclick", "window.location.href = 'userQR.html'");
    
    document.getElementById("form_subcol_right5").appendChild(form_button_qr);
    
}


/*
*
*
*/
function submit_changes(){
    overlay_on();    
    var newName = document.getElementById("form_email");
    //var newVisibility = document.getElementById("form_toggle").checked;
    var newDescription = document.getElementById("form_description").value;
    //var newPhoto = document.getElementById("form_profilepic").getAttribute("src");
    
    set_userChanges(newDescription, null, "");
    
}

function set_userChanges(newDescription, newVisibility, newPhoto){
       
    if(newDescription != "" && newDescription != description && newDescription != null) {
       
        getSetUserDescriptionResponse(idUser, newDescription,function(returnMessage) {
            overlay_off();    
        });
    }
    if(newVisibility != visibility && newVisibility != null) {
        
        var visibilityInt = 0;
        if(newVisibility == true) {
            
            visibilityInt = 1;
            visibility  = true;
        } else if(newVisibility == false) {
            
            visibilityInt = 0;
            visibility  = false;

        }
        getSetUserVisibilityResponse(idUser, visibilityInt, function(returnMessage){
            overlay_off();   
        });        
    }
    if(newPhoto !="" && newPhoto != photo && newPhoto!= null) {
            
        getSetUserImagePathResponse(idUser, newPhoto, function(returnMessage){
            overlay_off();   
        });        
    }

    //getInfo();
       
}

function getInfo(){
    
    getUserResponse(idUser, function(weNightUserResponse){
                    
        var user = [] 
        user = weNightUserResponse.user;

        if(user.creditCardId == null){
            
            action_showCards();
            
        }else{
        
            name = user.userName;
            description = user.userDescription;
            email = user.mail;
            visibility = user.isVisible;
            if(visibility == "true") {
               visibility = true;
            } else if(visibility == "false") {
               visibility = false;
            }
            photo = user.profileImagePath;
                    
            if(window.sessionStorage.getItem("default_card") == null){
            
                window.sessionStorage.setItem("default_card_id", user.creditCardId);
            
            }
        
            populate_fields();
            
        }
                    
    });
    
}


function getPhoto(source) {
      // Retrieve image file location from specified source
      navigator.camera.getPicture(onPhotoURISuccess, onFail, {       quality: 50,
        //destinationType: destinationType.FILE_URI,
        sourceType: source,
        destinationType: Camera.DestinationType.DATA_URL,
        //allowEdit: true,
        encodingType: Camera.EncodingType.JPEG,
        //targetWidth: 500,
        //targetHeight: 500,
       // popoverOptions: CameraPopoverOptions,
        saveToPhotoAlbum: false,
        correctOrientation: true                                                    
        });
}

    // Called if something bad happens.
    //
function onFail(message) {
    alert('Failed because: ' + message);
}


function onPhotoURISuccess(imageURI) {

      // Get image handle
      //
      
    // var photo_split=imageURI.split("%3A");
    //imageURI="content://media/external/images/media/"+photo_split[1]; 
     
    document.getElementById('form_profilepic').src = "data:image/jpeg;base64," + imageURI;
    sessionStorage.setItem("profile_picture", "data:image/jpeg;base64," + imageURI);
    
    }

function cameraError(message) {
    // Show a helpful message
}

    // device APIs are available
    //
function onDeviceReady() {
        pictureSource=navigator.camera.PictureSourceType;
        destinationType=navigator.camera.DestinationType;
    
    }


function get_profilePic(){
    
    try{
        
        //getPhoto(pictureSource.PHOTOLIBRARY);
        getPhoto(pictureSource.SAVEDPHOTOALBUM);
    }catch(err){
        
        alert(err);
        
    }
    
}

