
/*********************** VARIABLES ****************************/

var i_touche;
var i_x; 
var i_y;
var e_touche;
var e_x; 
var e_y;

var width = (window.innerWidth > 0) ? window.innerWidth : screen.width;
var height = (window.innerHeight > 0) ? window.innerHeight : screen.height;

var cell_width = (width*28)/100;
var cell_height = (width*32)/100;
var sl_height = (width*38)/100;
var cell_padding = (width*1)/100;


var currentRow = 1;
var quantity = 1;
var price = 0;
var priceBrand = 0;
var priceSubtype = 0;

var priceHow = 0;

var end = false;

var types;
var subtypes;
var brands;
var how1;
var how2;
var how3;
var garnishes;
var cartImagePath = "./img/icon_basket_limegreen.png";
var cartImagePathFull = "./img/full_basket_icon.png";
var kalimotxo = false;
var Sinalcohol = false;
//var allTemp;
var allId;
var sel_id = [];
var sel_names = [];

var myCart = [];
var temp_item = JSON.parse(sessionStorage.getItem("temp_item"));

if(sessionStorage.getItem("myCart") != null) {
   myCart = JSON.parse(sessionStorage.getItem("myCart"));
}

app_push_drinks.initialize();

$(document).ready(function() {
    if(JSON.parse(sessionStorage.getItem("myCart")) != null) {
        myCart = JSON.parse(sessionStorage.getItem("myCart"));
        if(myCart.length>0) {
            setCartImage(true);

        } else {
            setCartImage(false);

        }

    } else {
        myCart = [];
        setCartImage(false);
    }
    if(sessionStorage.getItem("originPage") !=null) {
        window.sessionStorage.removeItem("originPage");
    }
    window.sessionStorage.setItem("originPage", "drinkType.html");
    //backbutton management: set app to main menu
    document.addEventListener("backbutton", function(e) {
        e.preventDefault();
        go_toMenu();
        window.location.href = "mainMenu.html";

    }, false);
});
    
/*********************** FUNCTIONS ****************************/

/**VAMOS A HACER ESTO UN POQUITO MENOS TOCHO**
** dIVIDIR EN VARIOS JS LO MAS QUE SE PUEDA QUE ME DA SIDA VER MAS DE MIL LINEAS.
*Implementar que se vea el precio de lo que estamos seleccionando abajo en el botón de add
*comprobar que se pueda hacer una clase general con lo dividido y el cart y checkout
*(funciones similares que pueden ser generalizadas aunque sea mucho curro)
*alerts
*funcion para editar y crear el entorno viniendo del cart (TEMP)
*FUTURO:Posible dropdown con info de fila
*/ 

/***** SLIDER CREATION (JQUERY) ******/

/*
*
*
*
*/
touchslider = {
    
    /**
     * We start by creating the sliding grid out of the specified
     * element.  We'll look for each child with a class of cell when
     * we create the slide panel.
     */
    createSlidePanel: function(/*string*/ gridid, /*int*/ cellWidth, /*int*/ padding) {
        var x = 0;
        
        $(gridid).each(function() {
            
            $(this).children('.cell').each(function() {
                $(this).css({
                    left: x + '%',
                });

                x += 30;
            });
            
            var all_cells= $('.cell').toArray();
            var long = all_cells.length;
            var last= all_cells[long-1];

            
            var fin = get_cellLeft();
            fin=fin.split(0,-1);
            var fin2=parseInt(fin);
            var width = (window.innerWidth > 0) ? window.innerWidth : screen.width;
            var quanfin= (fin2*width)/100;
            
            /*
               Many of the mobile browsers resize the screen and therefore
               don't give accurate information about the size of the window.
               We need to save this information so we can use it later when
               we're sliding the grid.
             */
            touchslider.width = quanfin;
            touchslider.colWidth = cellWidth + padding;
            
            try {
                document.createEvent('TouchEvent');
                /*
                   Now that we've finished the layout we'll make our panel respond
                   to all of the touch events.
                 */
                touchslider.makeTouchable(gridid);
            } catch (e) {
                /*
                 * Then we aren't on a device that supports touch
                 */
            }
        });
    },
    
    /**
     * This function just binds the touch functions for the grid.
     * It is very important to stop the default, stop the
     * propagation, and return false.  If we don't then the touch
     * events might cause the regular browser behavior for touches
     * and the screen will start sliding around.
     */
    makeTouchable: function(/*string*/ gridid) {
         $(gridid).each(function() {
            this.ontouchstart = function(e) {
                touchslider.touchStart($(this), e);
                //e.preventDefault();
                //e.stopPropagation();
                return true;
            };
            
            this.ontouchend = function(e) {
                e.preventDefault();
                e.stopPropagation();
                
                if (touchslider.sliding) {
                    touchslider.sliding = false;
                    touchslider.touchEnd($(this), e);
                    return false;
                } else {
                    /*
                       We never slid so we can just return true
                       and perform the default touch end
                     */
                    return true;
                }
            };
            
            this.ontouchmove = function(e) {
                touchslider.touchMove($(this), e);
                e.preventDefault();
                e.stopPropagation();
                return false;
            };
        });
    },
    
    /**
     * A little helper to parse off the 'px' at the end of the left
     * CSS attribute and parse it as a number.
     */
    getLeft: function(/*JQuery*/ elem) {
         return parseInt(elem.css('left').substring(0, elem.css('left').length), 10);
    },
    
    /**
     * When the touch starts we add our sliding class a record a few
     * variables about where the touch started.  We also record the
     * start time so we can do momentum.
     */
    touchStart: function(/*JQuery*/ elem, /*event*/ e) {
         elem.css({
             '-webkit-transition-duration': '0'
         });
         
         touchslider.startX = e.targetTouches[0].clientX;
         touchslider.startLeft = touchslider.getLeft(elem);
         touchslider.touchStartTime = new Date().getTime();
         
    },
    
    /**
     * When the touch ends we need to adjust the grid for momentum
     * and to snap to the grid.  We also need to make sure they
     * didn't drag farther than the end of the list in either
     * direction.
     */
    touchEnd: function(/*JQuery*/ elem, /*event*/ e) {
         if (touchslider.getLeft(elem) > 0) {
             /*
              * This means they dragged to the right past the first item
              */
             touchslider.doSlide(elem, 0, '0.4s');
             
             elem.parent().removeClass('sliding');
             touchslider.startX = null;
         } else if ((Math.abs(touchslider.getLeft(elem)) + elem.parent().width()) > touchslider.width) {
             /*
              * This means they dragged to the left past the last item
              */
             touchslider.doSlide(elem, '-' + (touchslider.width - elem.parent().width()), '0.4s');
             
             elem.parent().removeClass('sliding');
             touchslider.startX = null;
         } else {
             /*
                This means they were just dragging within the bounds of the grid
                and we just need to handle the momentum and snap to the grid.
              */
             touchslider.slideMomentum(elem, e);
         }
    },
    
    /**
     * If the user drags their finger really fast we want to push 
     * the slider a little farther since they were pushing a large 
     * amount. 
     */
    slideMomentum: function(/*jQuery*/ elem, /*event*/ e) {
         var slideAdjust = (new Date().getTime() - touchslider.touchStartTime) * 10;
         var left = touchslider.getLeft(elem);
         
         /*
            We calculate the momentum by taking the amount of time they were sliding
            and comparing it to the distance they slide.  If they slide a small distance
            quickly or a large distance slowly then they have almost no momentum.
            If they slide a long distance fast then they have a lot of momentum.
          */
         
         var changeX = 20000 * (Math.abs(touchslider.startLeft) - Math.abs(left));
         
         slideAdjust = Math.round(changeX / slideAdjust);
         
         var newLeft = slideAdjust + left;
         
         /*
          * We need to calculate the closest column so we can figure out
          * where to snap the grid to.
          */
         var t = newLeft % touchslider.colWidth;
         
         if ((Math.abs(t)) > ((touchslider.colWidth / 2))) {
             /*
              * Show the next cell
              */
             newLeft -= (touchslider.colWidth - Math.abs(t));
         } else {
             /*
              * Stay on the current cell
              */
             newLeft -= t;
         }
         
         if (touchslider.slidingLeft) {
             var maxLeft = parseInt('-' + (touchslider.width - elem.parent().width()), 10);
             /*
              * Sliding to the left
              */
             touchslider.doSlide(elem, Math.max(maxLeft, newLeft), '0.4s');
         } else {
             /*
              * Sliding to the right
              */
             touchslider.doSlide(elem, Math.min(0, newLeft), '0.4s');
         }
         
         elem.parent().removeClass('sliding');
         touchslider.startX = null;
    },
    
    doSlide: function(/*jQuery*/ elem, /*int*/ x, /*string*/ duration) {
         elem.css({
             left: x + 'px',
             '-webkit-transition-property': 'left',
             '-webkit-transition-duration': duration
         });
    },
    
    /**
     * While they are actively dragging we just need to adjust the
     * position of the grid using the place they started and the
     * amount they've moved.
     */
    touchMove: function(/*JQuery*/ elem, /*event*/ e) {
         if (!touchslider.sliding) {
             elem.parent().addClass('sliding');
         }
         
         touchslider.sliding = true;
         
         if (touchslider.startX > e.targetTouches[0].clientX) {
             /*
              * Sliding to the left
              */
             elem.css('left', '-' + (touchslider.startX - e.targetTouches[0].clientX - touchslider.startLeft) + 'px');
             touchslider.slidingLeft = true;
         } else {
             /*
              * Sliding to the right
              */
             var left = (e.targetTouches[0].clientX - touchslider.startX + touchslider.startLeft);
             elem.css('left', left + 'px');
             touchslider.slidingLeft = false;
         }
         
    }
};

/*
function onLoad() {
                
    document.addEventListener("deviceready", onDeviceReady, false);
}

function onDeviceReady() {
 
    alert("hols"); 
    
    var win_myCart = JSON.parse(sessionStorage.getItem("myCart"));

    if(win_myCart != null){
        
         myCart = win_myCart;
        
    }

    if(temp_item != null){   
        
        create_editEnvironment();
        
    }else{
        alert("sal");
        
        load_drinkTypes(0);
        showQuant();
        
    }
}*/

$(document).ready(function() {
    
    var win_myCart = JSON.parse(sessionStorage.getItem("myCart"));

    if(win_myCart != null){
        
         myCart = win_myCart;
        
    }

    if(temp_item != null){   
        
        create_editEnvironment();
        
    }else{
        
        load_drinkTypes(0);
        showQuant();
        
    }
    
});


/**
*
*This function requests all the beverage types to the server. 
*Then populates the local array with the response (an array of beverages) and creates the current Caroussel row with its slider and its cells.
*
*@idPlace    - The id of the establishment. Depending on this parameter the server will return some beverages or others.
*
**/
function load_drinkTypes(idPlace){
   
   getDrinkTypesResponse(idPlace, function(weNightListResponse){
       
        types = [];
        types = weNightListResponse.drinkTypes;
        
        create_carousselRow(currentRow);
        create_content(currentRow);
   });    
   
}

/**
*
*This function requests all the beverage subTypes to the server. 
*Then populates the local array with the response (an array of beverages) and creates the current Caroussel row with its slider and its cells.
*
*@idPlace    - The id of the establishment. Depending on this parameter the server will return some beverages or others.
*
*@idDrinkType    - The drink type we have selected previously.
*Since this function can only be triggered after selecting a type, the beverages the server will return depend on the id we pass as a parameter.
*
**/
function load_drinkSubtypes(idPlace, idDrinkType){
   
   getDrinkSubtypesResponse(idPlace, idDrinkType, function(weNightListResponse){
                           
       if(sessionStorage.getItem("finish") ==  "true"){
           
           end = true;
           show_price();
           
       }else{
            
        subtypes = [];
           
        /*Special behaviour for beers in spain
            TODO: OJO cuidado con los ids de draft y bottled que pueden cambiar    
        */
        var tempSubsForBeers= [];
        var tempSubsForWines= [];
           
        if(idDrinkType == 0) {
           tempSubsForBeers  = weNightListResponse.drinkSubtypes;
           if(sel_id[1]==227) {
              for(var a=0;a<tempSubsForBeers.length;a++){
                  var temp = tempSubsForBeers[a];
                  if(temp.imagePath.includes("draft")) {
                     subtypes.push(temp);
                   }
              }
            } else if(sel_id[1]==228) {
              for(var a=0;a<tempSubsForBeers.length;a++){
                  var temp = tempSubsForBeers[a];
                  if(temp.imagePath.includes("bottl")) {
                     subtypes.push(temp);
                   }
              }
            }
        } else if(idDrinkType == 1) {
           tempSubsForWines  = weNightListResponse.drinkSubtypes;
           if(sel_id[1]==229) {
              for(var a=0;a<tempSubsForWines.length;a++){
                  var temp = tempSubsForWines[a];
                  if(temp.imagePath.includes("white")) {
                     subtypes.push(temp);
                   }
              }
            } else if(sel_id[1]==230) {
              for(var a=0;a<tempSubsForWines.length;a++){
                  var temp = tempSubsForWines[a];
                  if(temp.imagePath.includes("red")) {
                     subtypes.push(temp);
                   }
              }
            }
        } else {
            
            subtypes = weNightListResponse.drinkSubtypes;
 
        }
        
        create_carousselRow(currentRow);
        create_content(currentRow); 
           
       }
    
       
   });
}

/**
*
*This function requests all the brands of a certain beverage type to the server. 
*Then populates the local array with the response (an array of beverages) and creates the current Caroussel row with its slider and its cells.
*
*@idPlace    - The id of the establishment. Depending on this parameter the server will return some beverages or others.
*
*@idDrinkType    - The drink type we have selected previously.
*Since this function can only be triggered after selecting a type, the beverages the server will return depend on the id we pass as a parameter.
*
**/
function load_drinkBrands(idPlace, idDrinkType){
   
   getDrinkBrandsResponse(idPlace, idDrinkType, function(weNightListResponse){
       
       if(sessionStorage.getItem("finish") ==  "true"){
           
           end = true;
           show_price();
           
       }else{
            
        brands = [];
        brands = weNightListResponse.drinkBrands;
        create_carousselRow(currentRow);
        create_content(currentRow); 
           
       }
       
   });
}

/**
*
*This function requests all the first-step ways to serve the desired drink to the server. 
*Then populates the local array with the response (an array of beverages) and creates the current Caroussel row with its slider and its cells.
*
*@idPlace    - The id of the establishment. Depending on this parameter the server will return some beverages or others.
*
*@idDrinkSubType   - The drink subtype we have selected previously.
*Since this function can only be triggered after selecting a subtype, the beverages the server will return depend on the id we pass as a parameter.
*
**/
function load_drinkHow1(idPlace, idDrinkSubType){
   
   getDrinkHowsResponse(idPlace, idDrinkSubType, function(weNightListResponse){

              
       if(sessionStorage.getItem("finish") ==  "true"){
           
           end = true;
           show_price();
           
       }else{
                
        how1 = [];
        how1 = weNightListResponse.drinkHows;
        create_carousselRow(currentRow);
        create_content(currentRow); 
           
       }
       
   });
}

/**
*
*This function requests all the second-step ways to serve the desired drink to the server. 
*Then populates the local array with the response (an array of beverages) and creates the current Caroussel row with its slider and its cells.
*
*@idPlace    - The id of the establishment. Depending on this parameter the server will return some beverages or others.
*
*@idDrinkSubType   - The drink subtype we have selected previously.
*Since this function can only be triggered after selecting a subtype, the beverages the server will return depend on the id we pass as a parameter.
*
**/
function load_drinkHow2(idPlace, idDrinkSubType){
    
   getDrinkHowPlusesResponse(idPlace, idDrinkSubType, function(weNightListResponse){
           
       if(sessionStorage.getItem("finish") ==  "true"){
           
           end = true;
           show_price();
           
       }else{
            
        how2 = [];
        how2 = weNightListResponse.drinkHowPluses;
        create_carousselRow(currentRow);
        create_content(currentRow); 
           
       }
       
    });

}

/**
*
*This function requests all the third-step ways to serve the desired drink to the server. 
*Then populates the local array with the response (an array of beverages) and creates the current Caroussel row with its slider and its cells.
*
*@idPlace    - The id of the establishment. Depending on this parameter the server will return some beverages or others.
*
*@idDrinkSubType   - The drink subtype we have selected previously.
*Since this function can only be triggered after selecting a subtype, the beverages the server will return depend on the id we pass as a parameter.
*
**/
function load_drinkHow3(idPlace, idDrinkSubType){
  
   getDrinkHowPluses2Response(idPlace, idDrinkSubType, function(weNightListResponse){
       
       if(sessionStorage.getItem("finish") ==  "true"){
           
           end = true;
           show_price();
           
       }else{
            
        how3 = [];
        how3 = weNightListResponse.drinkHowPluses2;
        create_carousselRow(currentRow);
        create_content(currentRow); 
           
       }

   });

}

/**
*
*This function requests all the ways to garnish the desired drink to the server. 
*Then populates the local array with the response (an array of beverages) and creates the current Caroussel row with its slider and its cells.
*
*@idPlace    - The id of the establishment. Depending on this parameter the server will return some beverages or others.
*
*@idDrinkType   - The drink type we have selected previously.
*
*
*@idDrinkSubType   - The drink subtype we have selected previously.
*
*The beverages the server will return depend on the IDs we pass as a parameter.
*
**/
function load_drinkGarnishes(idPlace, idDrinkType, idDrinkSubType){
   
   getDrinkGarnishesResponse(idPlace, idDrinkType, idDrinkSubType, function(weNightListResponse){
       
        garnishes = [];
        garnishes = weNightListResponse.drinkGranishes;
           
        create_carousselRow(currentRow);
        create_content(currentRow);  
       
   });
}

/**
*
*This function created the bootstrap row and column for the slider and drink choices displayed in cells. 
*
*The creation is dynamic so this function allows to set a unique id depending on the row we are currently in. This creates only the skeleton of the slider.
*
*@rowNumber  - The local variable that holds the row number we are currently handling.
*
**/
function create_carousselRow(rowNumber){
    
    var currentRow = document.createElement("div");
    currentRow.setAttribute("id", "row"+rowNumber);
    //currentRow.className = "row";
        
    var rowContent = document.createElement("div");
    rowContent.setAttribute("id", "row_content"+rowNumber);
    rowContent.className = "col-xs-12 col-sm-12 row_content";
    
    document.getElementById("drink_forms").appendChild(currentRow);
    document.getElementById("row"+rowNumber).appendChild(rowContent);

    
}

/*
*
*This function resets the content of the row and creates:
*
**A new header for the slider row.
**A new slider for the slider row which will contain the cells.
*
*@rowNumber  - The local variable that holds the row number we are currently handling
*
*/
function create_content(rowNumber){
   var button = $('#button_add');
    if(button.is(':disabled')) { 
        document.getElementById("row_content"+rowNumber).innerHTML="";
    
        create_areaHeader(rowNumber);
    
        create_areaSlider(rowNumber);
     } else {
        for(var x = 0; x< sel_names.length;x++) {
            var num = rowNumber-1;
            if(x>=num){
               sel_names[num] = '';
               sel_id [num]= null;
            }
        }
     }
}

/*
*
*
*
*/
function create_areaHeader(rowNumber){
    
      var area_head = document.createElement("div");
      area_head.className="row area_head";
      area_head.setAttribute("id", "area_head"+rowNumber);
    
      var rowTitle = document.createElement("div");
      rowTitle.className="col-xs-12 col-sm-12 rowTitle";
      rowTitle.setAttribute("id", "rowTitle"+rowNumber);
      rowTitle.style.color = "white";
      rowTitle.innerHTML = get_rowTitle();
    
      area_head.appendChild(rowTitle);
    
      document.getElementById("row_content"+rowNumber).appendChild(area_head); 
    
    
    
}

/*
*
*
*
*/
function create_areaSlider(rowNumber){
    
    var area_body = document.createElement("div");
    area_body.setAttribute("id", "area_body"+rowNumber);
    area_body.className = "row area_body";
        
    var slider_area = document.createElement("div");
    slider_area.setAttribute("id", "slider_area"+rowNumber);
    slider_area.className = "col-xs-12 col-sm-12 slider_area";
    
    document.getElementById("row_content"+rowNumber).appendChild(area_body);
    document.getElementById("area_body"+rowNumber).appendChild(slider_area);    
    
    create_slider(rowNumber);
    
}

/*
*
*
*
*/
function create_slider(rowNumber){
    
    var slider_inner = document.createElement("div");
    slider_inner.className = "slider_inner";
    slider_inner.setAttribute("id", "slider_inner"+rowNumber);

    var slider_outer = document.createElement("div");
    slider_outer.setAttribute("id", "slider_outer"+rowNumber);
    slider_outer.className = "slider_outer";
    slider_outer.style.border = "solid 1px white";
    
    slider_outer.appendChild(slider_inner);
    document.getElementById("slider_area"+rowNumber).appendChild(slider_outer);
    document.getElementById("slider_inner"+rowNumber).style.height= cell_height + 'px';
    document.getElementById("slider_outer"+rowNumber).style.height= sl_height + 'px';
    
    var cArray;
    
    cArray = select_currentArray();
    var length = 0; 
    if(cArray != undefined) {
    	length = cArray.length;
    }
    create_nCells(length, rowNumber);
    
    touchslider.createSlidePanel("#slider_inner"+rowNumber, cell_width, cell_padding);
    
    add_sliderResize(rowNumber);
    
}

/*
*
*
*
*/
function create_nCells(n, rowNumber){
   
    var i;
    var name;
    
    for(i=0; i<n; i++){
        name = "cell" + (i+1);
        create_cell(name, rowNumber);
    }
    
    
}

/*
*
*
*
*/
function create_cell(cellId, rowNumber){
    
    var cell = document.createElement("div");
    var cellContainer = document.createElement("div");
    
    var tag = document.createElement("div");
    var cell_img = document.createElement("input");
    var cellNumb = (cellId.replace("cell",""))-1;
    var srcArray = select_currentArray();
    tag.className = "tag";
    tag.innerHTML = srcArray[cellNumb].name;
    
    var imagepath = images(cellNumb);
    cell.className="cell";
    cell.setAttribute("id", cellId);
    cell_img.className = "cell_img";
    cell_img.setAttribute("type", "image");  
    cell_img.setAttribute ("src", imagepath);
    cell.style.border = "none";

    cell.onclick =function(e) { action_selectCell(cell, rowNumber);}

    cell.ontouchstart = function(e) {
        i_touche = e.touches[0];
        i_x = i_touche.clientX; 
        i_y = i_touche.clientY;
        var dif_x = i_x-e_x;
        var dif_y = i_y-e_y;
        if(dif_x<0) {
           dif_x = dif_x*-1;
        }
        if(dif_y<0) {
           dif_y = dif_y*-1;
        }
        
        if(dif_x <= 10 && dif_y <= 10){
            action_selectCell(cell, rowNumber); 
        }
    };
    cell.ontouchend = function(e) {
        e_touche = e.changedTouches[0];
        e_x = e_touche.clientX; 
        e_y = e_touche.clientY;
        var dif_x = i_x-e_x;
        var dif_y = i_y-e_y;
        if(dif_x<0) {
           dif_x = dif_x*-1;
        }
        if(dif_y<0) {
           dif_y = dif_y*-1;
        }
        
        if(dif_x <= 10 && dif_y <= 10){
            action_selectCell(cell, rowNumber); 
        }
        

    }
    
    cell.appendChild(cell_img);
    cell.appendChild(tag);
    document.getElementById("slider_inner"+rowNumber).appendChild(cell);
   // $('#'+cellId).on('click touchend',function(){action_selectCell($(this).parentElement, rowNumber); };
    
}

/*
*
*
*
*/
function create_lockedRow(rowNumber, cellId){
    
    var sel_info_area = document.createElement("div");
    var sel_info_img = document.createElement("img");
    var sel_info_img_col = document.createElement("div");
    var sel_info_name_col = document.createElement("div");
    var sel_info_opt_col = document.createElement("div");
    var cArray = select_currentArray();

    sel_info_area.setAttribute("id", "sel_info_area"+rowNumber);
    sel_info_area.className = "col-xs-6 col-sm-6 sel_info_area";
    
    sel_info_img_col.setAttribute("id", "sel_info_img_col"+rowNumber);
    sel_info_img_col.className = "col-xs-4 col-sm-4 sel_info_img_col";
    
    sel_info_name_col.setAttribute("id", "sel_info_name"+rowNumber);
    sel_info_name_col.className = "col-xs-8 col-sm-8 sel_info_name_col";
    sel_info_name_col.innerHTML = cArray[cellId].name;
    
    sel_info_img.setAttribute("id", "sel_info_img" + rowNumber);
    sel_info_img.className = "sel_info_img";
   
    var imagepath = images(cellId);
    
    sel_info_img.setAttribute("src", imagepath); 
       
    
    sel_info_opt_col.setAttribute("id", "sel_info_opt_col"+rowNumber);
    sel_info_opt_col.className = "col-xs-6 col-sm-6 sel_info_opt_col";
    
    sel_info_img_col.appendChild(sel_info_img);
    sel_info_area.appendChild(sel_info_img_col);
    sel_info_area.appendChild(sel_info_name_col);

    document.getElementById("row_content"+rowNumber).appendChild(sel_info_area);
    document.getElementById("row_content"+rowNumber).appendChild(sel_info_opt_col);
    
    document.getElementById("row_content"+rowNumber).style.border =  "solid 1px white";

    document.getElementById("row_content"+rowNumber).style.backgroundColor =  "transparent";
    
    width = (window.innerWidth > 0) ? window.innerWidth : screen.width;
    
    var lockedH = (width*16)/100;
    document.getElementById("row_content"+rowNumber).style.height = lockedH + 'px' ;
}

/*
*
*
*
*/
function create_optAreas(rowNumber){
      
    var h_toggle = document.createElement("div");
    var h_optEdit = document.createElement("div");
    

    h_toggle.className = "col-xs-6 col-sm-6 h_toggle";
    h_toggle.setAttribute("id", "h_toggle"+rowNumber);

    h_optEdit.className = "col-xs-6 col-sm-6 h_optEdit";
    h_optEdit.setAttribute("id", "h_optEdit"+rowNumber);
    document.getElementById("sel_info_opt_col"+rowNumber).appendChild(h_optEdit);
    document.getElementById("sel_info_opt_col"+rowNumber).appendChild(h_toggle);
        
}

/*
*
*
*
*/
function action_lockCarousselRow(cellId, rowNumber){
    
    document.getElementById("row_content"+rowNumber).innerHTML=''; 
    
    create_lockedRow(rowNumber, cellId);
    
    create_optAreas(rowNumber);
    
    populate_optAreas(rowNumber);
    
    action_animateOpts(rowNumber);
    
    window.removeEventListener("resize", action_slideResize);
    
    goToByScroll("row"+rowNumber);
    
    
}

/*
*
*
*
*/
function action_animateOpts(rowNumber){

    document.getElementById("opt_main"+rowNumber).onclick = function(){ 
        
        $('#h_optEdit'+rowNumber).animate({width: 'toggle'});
    }
    
    document.getElementById("opt_aux"+rowNumber).onclick = function(){

        end = false;
        sessionStorage.removeItem("finish");
        
        action_deleteRows(rowNumber);
            
        load_rowDrinks();

    }
            
}

/*
*
*
*
*/
function action_slideResize(rowNumber){
    
    width = (window.innerWidth > 0) ? window.innerWidth : screen.width;
    height = (window.innerHeight > 0) ? window.innerHeight : screen.height;

    cell_height = (width*28)/100;
    sl_height = (width*36)/100;
    
    document.getElementById("slider_inner"+rowNumber).style.height= cell_height + 'px';
    document.getElementById("slider_outer"+rowNumber).style.height= sl_height + 'px';  
    
}

/*
*
*
*
*/
function action_selectCell(cell, rowNumber){
    
    var id ;
    
    id = cell.id;
    
    load_selectedInArray(id.substring(4)-1);   

    action_lockCarousselRow(id.substring(4)-1, rowNumber); 
    
    currentRow = currentRow+1;
    
    load_rowDrinks();
    
}

/*
*
*
*
*/
function action_deleteRows(rowNumber){
    
    if(rowNumber<=2){
        
        priceBrand = 0;
        
    }
    if(rowNumber<=3){
        
        priceSubtype = 0;
        
    }
    
    if(rowNumber<=4){
        
        priceHow = 0;
        
    }
    
    document.getElementById("button_add").disabled = true;
    document.getElementById("button_plus").disabled = true;
    document.getElementById("button_minus").disabled = true;
    document.getElementById("button_add").value = "Añadir al pedido";
    
    var myRow = document.getElementById("opt_aux"+rowNumber).id;
        
    myRow = myRow.replace("opt_aux", "");
        
    var locked_rows = document.getElementsByClassName("row_content");

    for(i=locked_rows.length; i>0; i--){
            
        if(i>=myRow){
                
            document.getElementById("row_content"+(i)).remove();
                
        }
            
    }
        
    currentRow = parseInt(myRow);
    
    
}

/*
*
*
*
*/
function populate_optAreas(rowNumber){
    
    var opt_main = document.createElement("input");
    var opt_aux = document.createElement("input");

    opt_main.setAttribute("id", "opt_main"+rowNumber);
    opt_main.className = "opt_main";
    opt_main.setAttribute("type", "image");  
    opt_main.setAttribute ("src", "./img/opt_dots_light.png");

    opt_aux.setAttribute("id", "opt_aux"+rowNumber);
    opt_aux.className = "opt_aux";
    opt_aux.setAttribute("type", "image"); 
    opt_aux.setAttribute ("src", "./img/editIcon.png");

    document.getElementById("h_toggle"+rowNumber).appendChild(opt_main);
    document.getElementById("h_optEdit"+rowNumber).appendChild(opt_aux);
    
}

/*
*
*
*
*/
function add_sliderResize(rowNumber){

    window.addEventListener('resize', action_slideResize(rowNumber));
    
}

/*
*
*
*
*/
function get_cellLeft(){
    
    cellA=document.getElementsByClassName("cell");
    cellAL=cellA.length;
    
    cell_last = cellA[cellAL-1];
    
    raw_left = cell_last.style.left;
    
    return raw_left;
    
}

/*
*
*
*
*/
function load_rowDrinks(){

    switch(currentRow){
            
        case 1: {
            
            load_drinkTypes(0);
            break;
        }    
        case 2: {

            load_drinkBrands(0, sel_id[0]);
            break;
        }
        case 3: {
            if(kalimotxo == false && Sinalcohol==false) {
                load_drinkSubtypes(0, sel_id[0]);
            }else {
                end=true;
                show_price(); 
            }
            break;
        }   
        case 4: {
            
            load_drinkHow1(0, sel_id[2]);
            break;
        }   
        case 5: {
            
            load_drinkHow2(0, sel_id[2]);
            break;
        }   
        case 6: {
            
            load_drinkHow3(0, sel_id[2]);
            break;
        }
        case 7: {
            
            load_drinkGarnishes(0, sel_id[0], sel_id[2]);
            break;
        }

    }

    
}

/*
*
*
*
*/
function load_selectedInArray(id){
   switch(currentRow) {
                
            case 1: {
                end=false;
                subtypes = [];
                brands = [];
                how1 = [];
                how2 = [];
                how3 = [];
                garnishes = [];
            }break;
            case 2:{
                subtypes = [];
                how1 = [];
                how2 = [];
                how3 = [];
                garnishes = [];
            }break;
            case 3:{
                how1 = [];
                how2 = [];
                how3 = [];
                garnishes = [];
            }break;
            case 4: {
                how2 = [];
                how3 = [];
                garnishes = [];
            }break;
            case 5:{
                how3 = [];
                garnishes = [];
            }break;
            case 6:{
                garnishes = [];
            }break;
        }    
    switch(currentRow){
            
        case 1: { 
            
            sel_id[currentRow-1] = types[id].id;
            sel_names[currentRow-1] = '';
            sel_names[currentRow-1] = types[id].name;
            break; 
        }  
        case 2: {
            
            sel_id[currentRow-1] = brands[id].id;
            sel_names[currentRow-1] = '';
            sel_names[currentRow-1] = brands[id].name;
            priceBrand = parseFloat(brands[id].price);
            if(brands[id].name == "Kalimotxo"){
                kalimotxo = true;

            } else {
                kalimotxo = false;
            }
            if(brands[id].name == "Sin alcohol"){
                Sinalcohol = true;

            } else {
                Sinalcohol = false;
            }
            if(subtypes==undefined || subtypes.length == 0){
                end=true;
				show_price(); 
			}
            break;
        }
        case 3: {
            
            sel_id[currentRow-1] = subtypes[id].id;
            sel_names[currentRow-1] = '';
            sel_names[currentRow-1] = subtypes[id].name;
            priceSubtype = parseFloat(subtypes[id].price);
            if(how1==undefined || how1.length == 0){
                end=true;
				show_price(); 
			}
            break; 
        }
        case 4: {
            
				sel_id[currentRow-1] = how1[id].id;
                sel_names[currentRow-1] = '';
				sel_names[currentRow-1] = how1[id].name;
				priceHow = parseFloat(how1[id].price);
			if(how2==undefined || how2.length == 0){
                end=true;
				show_price(); 
			} 
            break; 
        }
        case 5: {
            
            sel_id[currentRow-1] = how2[id].id;
            sel_names[currentRow-1] = how2[id].name;
            if(how3==undefined || how3.length == 0){
                end=true;
				show_price(); 
			}
            break; 
        }
        case 6: {
            
            sel_id[currentRow-1] = how3[id].id;
            sel_names[currentRow-1] = '';
            sel_names[currentRow-1] = how3[id].name;
            if(garnishes==undefined){
                end=true;
				show_price(); 
			} 
            break; 
        }
        case 7: {
            
            sel_id[currentRow-1] = garnishes[id].id;
            sel_names[currentRow-1] = '';
            sel_names[currentRow-1] = garnishes[id].name;
            end=true;
            show_price();
            break; 
        }
  
    }
        
}

/*
*
*
*
*/
function select_currentArray(){
    
    var currentArray;
    
    switch(currentRow){
            
        case 1:     currentArray = types; break; 
            
        case 2:     currentArray = brands; break;

        case 3:     currentArray = subtypes; break; 
            
        case 4:     currentArray = how1; break;
            
        case 5:     currentArray = how2; break;
            
        case 6:     currentArray = how3; break; 
 
        case 7:     currentArray = garnishes; break; 
    }
    
    return currentArray;
}

/*
*
*
*
*/
function images(cellNumb){
    
        var imgPath;
        var imgName;
        var imgTotal; 
    
    switch(currentRow){
            
        case 1: {
            
            imgPath = types[cellNumb].imagePath.replace("www/","");
            imgPath = imgPath.replace("Types", "types");
            imgName = types[cellNumb].imageName;
            break;
            
        }      
        case 2: {
            
            imgPath = brands[cellNumb].imagePath.replace("www/","");
            imgPath = imgPath.replace("Brands", "brands");
            imgName = brands[cellNumb].imageName;
            break;
            
        }
        case 3: {
            
            imgPath = subtypes[cellNumb].imagePath.replace("www/","");
            imgPath = imgPath.replace("Subtypes", "subtypes");
            imgName = subtypes[cellNumb].imageName;
            break;
            
        }    
        case 4: {
            
            imgPath = how1[cellNumb].imagePath.replace("www/","");
            imgPath = imgPath.replace("Hows", "hows");
            imgName = how1[cellNumb].imageName;
            break;
        }     
        case 5: {
            
            imgPath = how2[cellNumb].imagePath.replace("www/","");
            imgPath = imgPath.replace("HowPluses", "howPluses");
            imgName = how2[cellNumb].imageName;
            break;

        }     
        case 6: {
            
            imgPath = how3[cellNumb].imagePath.replace("www/","");
            imgPath = imgPath.replace("HowPluses2", "howPluses2");
            imgName = how3[cellNumb].imageName;
            break;

        } 
        case 7: {
        
            imgPath = garnishes[cellNumb].imagePath.replace("www/","");
            imgPath = imgPath.replace("Garnishes", "garnishes");
            imgName = garnishes[cellNumb].imageName;
            break;

        } 
            
    }
    
    imgTotal = (imgPath).concat(imgName);
    return imgTotal;
    
}

/*
*
*
*
*/
function get_rowTitle(){
    
    var strTitle;
    
    switch(currentRow){
            
        case 1: {
            
            strTitle = "What drink do you want?"
            break;
        }    
        case 2: {
            
            strTitle = "Wich brand?"
            break;
        }
        case 3: {
            
            strTitle = "How do you want your drink?"
            break;
        }   
        case 4: {
            
            strTitle = "How do you want your drink?"            
            break;
        }   
        case 5: {
            
            strTitle = "How do you want your drink?"            
            break;
        }   
        case 6: {
            
            strTitle = "How do you want your drink?"            
            break;
        }
        case 7: {
            
            strTitle = "Do you want any kind of garnish?"            
            break;
        }

    }
    return strTitle;
}

/*
*
*
*
*/
function add_toCart(){
    overlay_on();    
    var arranging_array;
    if(isNaN(priceHow)) {
        arranging_array = [quantity, sel_id, sel_names, (priceSubtype + priceBrand)];
    } else {
        arranging_array = [quantity, sel_id, sel_names, (priceSubtype + priceBrand + priceHow)];
    }
    
    if(sel_names != null){
    
        
        myCart.push(arranging_array);
    
        window.sessionStorage.setItem("myCart", JSON.stringify(myCart));

        if(temp_item != null){
        
            window.location.href = "cart.html";
        
        }else{
    
            window.location.href = "drinkType.html";
//        end = false;
//        sessionStorage.removeItem("finish");
//        sel_id = [];
//        sel_names = [];
//
//        currentRow=1;
//        document.getElementById("drink_forms").innerHTML=''; 
//
//        create_carousselRow(currentRow);
//        create_content(currentRow);
//
//        quantity = 1;
//        setCartImage(true);
//        price=0;
//       
//        quantity=1;
//        showQuant();
//        show_price();
//        
        }
    
    }
}

/*
*
*
*
*/
function sum_quantity(){
    
    if(quantity<9) {
        quantity = quantity + 1;
        showQuant();
    
        if(end == true){
        
        price = (priceBrand + priceHow + priceSubtype) * quantity;
        
        /*if(priceHow == 0 && priceHow == null && priceHow == undefined){
                
            price = priceBrand * quantity;
                
        }*/
        
        document.getElementById("button_add").value = "Añadir al pedido "+ "(" + price + " $)";
        
        }
    }
}

/*
*
*
*
*/
function dif_quantity(){
    
    
    if(quantity > 1){
       
        quantity = quantity - 1;
        
        if(end == true){
            
            price = (priceBrand + priceHow + priceSubtype) * quantity;
            
        /* if(priceHow == 0 && priceHow == null && priceHow == undefined){
                
                price = priceBrand * quantity;
                
            }*/
            
            document.getElementById("button_add").value = "Añadir al pedido "+ "(" + price + " $)";

        
        }
        
    }
    
    showQuant();
    
}

/*
*
*
*
*/
function showQuant(){
    
    document.getElementById("txt_quantity").innerHTML = quantity;

    
}

/*
*
*
*
*/
function goToByScroll(id){
          // Scroll
        $('html,body').animate({
            scrollTop: $("#"+id).offset().top},
            'slow');
}

/*
*
*
*
*/
function clearForm(){
    
    end=false;
    sessionStorage.removeItem("finish");
    
    action_deleteRows('1');
    
    load_rowDrinks();
    
    
}


/*
*
*
*
*/
function create_editEnvironment(){

    
    allId = temp_item[1];
    var quant = temp_item[0];
    
    sel_id = temp_item[1];
    sel_names = temp_item[2];
    
    quantity = quant;
    
    showQuant();
    
    search_byId(allId, (currentRow-1));
 
}

function search_byId(arr, num){
    
    switch(currentRow){
            
        case 1:   drinkType_byId(arr[num]); break;
        case 2:   drinkBrand_byId(arr[num]); break;
        case 3:   drinksubType_byId(arr[num]); break;
        case 4:   drinkHow1_byId(arr[num]); break;
        case 5:   drinkHow2_byId(arr[num]); break;
        case 6:   drinkHow3_byId(arr[num]); break;
        case 7:   drinkGarnish_byId(arr[num]); break;             
    }
    
}

function finish_editRow(){
    
        create_optAreas(currentRow);
        populate_optAreas(currentRow);
        action_animateOpts(currentRow);
        window.removeEventListener("resize", action_slideResize);
        goToByScroll("row"+currentRow);
        //load_selectedInArray(id.substring(4)-1);
         
}


function drinkType_byId(id){
    
    getDrinkTypeByIdResponse(id, function(weNightDrinkTypeResponse){
       
        create_carousselRow(currentRow);
        types = [];
        subtypes = [];
        brands = [];
        how1 = [];
        how2 = [];
        how3 = [];
        garnishes = [];
        types.push(weNightDrinkTypeResponse.drinkType);
        create_lockedRow(currentRow, 0);
        finish_editRow();
        currentRow = currentRow+1;
        search_byId(allId, (currentRow-1));

   });    
   
    
}

function drinksubType_byId(id){
        
    getDrinkSubTypeByIdResponse(id, function(weNightDrinkSubtypeResponse){
        
        create_carousselRow(currentRow);
        subtypes = [];
        brands = [];
        how1 = [];
        how2 = [];
        how3 = [];
        garnishes = [];
        subtypes.push(weNightDrinkSubtypeResponse.drinkSubType);
        create_lockedRow(currentRow, 0);
        finish_editRow(); 
        currentRow = currentRow+1;
        search_byId(allId, (currentRow-1));

   });  
    
}

function drinkBrand_byId(id){
    
    getDrinkBrandByIdResponse(id, function(weNightDrinkBrandResponse){
       
        create_carousselRow(currentRow);
        brands = [];
        how1 = [];
        how2 = [];
        how3 = [];
        garnishes = [];
        brands.push(weNightDrinkBrandResponse.drinkBrand);
        create_lockedRow(currentRow, 0);
        finish_editRow(); 
        currentRow = currentRow+1;
        search_byId(allId, (currentRow-1));

   });  
    
    
}

function drinkHow1_byId(id){
    
    getDrinkHowByIdResponse(id, function(weNightDrinkHowResponse){
    
        create_carousselRow(currentRow);
        how1 = [];
        how2 = [];
        how3 = [];
        garnishes = [];
        how1.push(weNightDrinkHowResponse.how);
        create_lockedRow(currentRow, 0);
        finish_editRow(); 
        currentRow = currentRow+1;
        search_byId(allId, (currentRow-1));
   });  
    
}

function drinkHow2_byId(id){
    
    getDrinkHowPlusByIdResponse(id, function(weNightHowPlusResponse){
       
        create_carousselRow(currentRow);
        how2 = [];
        how3 = [];
        garnishes = [];
        how2.push(weNightHowPlusResponse.howPlus);
        create_lockedRow(currentRow, 0);
        finish_editRow();
        currentRow = currentRow+1;
        search_byId(allId, (currentRow-1));
        
   }); 
    
}

function drinkHow3_byId(id){
   
    getDrinkHowPlus2ByIdResponse(id, function(weNightHowPlus2Response){
       
        create_carousselRow(currentRow);
        how3 = [];
        garnishes = [];
        how3.push(weNightHowPlus2Response.howPlus2);
        create_lockedRow(currentRow, 0);
        finish_editRow(); 
        currentRow = currentRow+1;
        search_byId(allId, (currentRow-1));
        
   }); 
    
}

function drinkGarnish_byId(id){
    
    getDrinkGarnishByIdResponse(id, function(weNightDrinkGarnishResponse){
       
        create_carousselRow(currentRow);
        garnishes = [];
        garnishes.push(weNightDrinkGarnishResponse.drinkGarnish);
        create_lockedRow(currentRow, 0);
        finish_editRow(); 
        currentRow = currentRow+1;
        search_byId(allId, (currentRow-1));
   }); 
    
}

function go_toCart(){
    
    sessionStorage.removeItem("finish");

    
    if(temp_item != null){
        
        myCart.push(temp_item);    
        window.sessionStorage.setItem("myCart", JSON.stringify(myCart));
        
        
    }
    
    window.location.href = "cart.html";
    
}

function go_toMenu(){
    
     sessionStorage.removeItem("finish");

     if(JSON.parse(sessionStorage.getItem("temp_item")) != null){
       
        window.sessionStorage.removeItem("temp_item");
 
    }
    window.location.href = "mainMenu.html";
}


//
function show_price(){
    
    if(end==true){
        
        price = (priceBrand + priceHow + priceSubtype)*quantity;
        if(price>0) {
            document.getElementById("button_add").disabled = false;
            document.getElementById("button_plus").disabled = false;
            document.getElementById("button_minus").disabled = false;

            document.getElementById("button_add").value = "Añadir al pedido "+ "(" + (price * quantity) + " $)"; 
        } else {
            document.getElementById("button_add").disabled = true;
            document.getElementById("button_plus").disabled = true;
            document.getElementById("button_minus").disabled = true;

            document.getElementById("button_add").value = "Añadir al pedido"; 
        }
        
        
    } else {
            document.getElementById("button_add").disabled = true;
            document.getElementById("button_plus").disabled = true;
            document.getElementById("button_minus").disabled = true;

            document.getElementById("button_add").value = "Añadir al pedido"; 
    }
    
    
}

