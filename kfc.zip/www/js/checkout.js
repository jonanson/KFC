/** ********************* VARIABLES *************************** */

var gratuity_percentage = 15;
var gratuity_price;
var total;

var idUser = sessionStorage.getItem("idUser");
// var idUser = 3;
var idPlace = "0";
var idCard;// = JSON.parse(sessionStorage.getItem("default_card"));
var defaultCardNumber;
var subTotal = parseFloat(sessionStorage.getItem("subtotal"));
var origin;
var reOrderId;
var notes;

/** ********************* FUNCTIONS *************************** */

app_push_checkout.initialize();

$(document).ready(function() {

	// setGratuity(gratuity_percentage);
	setTotal();
	populate_check(0);

	show_defaultCard();
	if (sessionStorage.getItem("notes") != null) {
		notes = sessionStorage.getItem("notes");
		document.getElementById("notes").value = notes;
	}
	if (sessionStorage.getItem("originPage") != null) {
		origin = sessionStorage.getItem("originPage");
		window.sessionStorage.removeItem("originPage");
	}
	if (sessionStorage.getItem("reOrderId") != null) {
		reOrderId = sessionStorage.getItem("reOrderId");
		window.sessionStorage.removeItem("reOrderId");
	}

	// backbutton management: set app to main menu
	document.addEventListener("backbutton", function(e) {
		e.preventDefault();
		if (origin == "orders.html") {
			window.location.href = "orders.html";

		} else {
			window.location.href = "cart.html";
		}

	}, false);

});

function goBackfromCheckout() {
	if (origin == "orders.html") {
		window.location = "orders.html";

	} else {
		window.location = "cart.html";
	}
}

function getUserDefaultCardHiddenNumber(callback) {
	var card;
	getUserCardsResponse(idUser, function(response) {
		var cards = response.object;
		if (cards.length == 1) {
			card = cards[0];
		} else {
			for (i = 0; i < cards.length; i++) {
				var tem = cards[i];
				if (tem.isDefault == 1) {
					card = tem;
				}
			}
		}
		callback(card.number);

	});
}
/*
 * 
 * 
 * 
 */
function setGratuity(percentage) {

	gratuity_percentage = percentage;
	gratuity_price = (subTotal * gratuity_percentage) / 100;

	setTotal();

	populate_check(0);

}

/*
 * 
 * 
 * 
 */
function setTotal() {

	total = subTotal;// + gratuity_price;

}

/*
 * 
 * 
 * 
 */
function populate_check(type) {

	/*
	 * if(type==0){
	 * 
	 * document.getElementById("gratuityField").value = null;
	 * document.getElementById("gratuityField").placeholder = "$ " +
	 * gratuity_price;
	 * 
	 * }else{
	 * 
	 * gratuity_price = document.getElementById("gratuityField").value;
	 * document.getElementById("gratuityField").value = "$ " + gratuity_price;
	 * gratuity_percentage = (100 * gratuity_price) / subTotal;
	 *  }
	 */

	// document.getElementById("subtotal_price").innerHTML = "$ " + subTotal;
	// document.getElementById("gratuity_tag").innerHTML = "Gratuity (" +
	// gratuity_percentage + "%)";
	// document.getElementById("gratuity_price").innerHTML = "$ " +
	// gratuity_price;
	document.getElementById("total_price").innerHTML = total + " €";

	// document.getElementById("gTitle_text").innerHTML = "Gratuity ("+
	// gratuity_percentage + "%)";
	// document.getElementById("gratuityField").placeholder = "$ " +
	// gratuity_price;

}

/*
 * 
 * 
 * 
 */
function placeOrder() {

	// Check if it is a new order or a repited one
	window.sessionStorage.removeItem("notes");
	notes = document.getElementById("notes").value;
	if(notes.trim() == '' || notes.trim() == undefined) {
		notes = 'empty';
	}
	if (reOrderId != null) {
		overlay_on();
		getPlaceReOrderResponse(reOrderId, function(weNightPlaceOrderResponse) {

			var msg = weNightPlaceOrderResponse.returnMessage.type;
			var order = weNightPlaceOrderResponse.order;
			if (msg == 1) {

				window.sessionStorage.setItem("placedOrderId", order.id);
				window.location.href = "orderConfirmation.html";
				myCart = [];
				window.sessionStorage.removeItem("myCart");

			} else {

				alert(weNightPlaceOrderResponse.returnMessage.message);

			}
			overlay_off();
		});

	} else {
		overlay_on();
		var fullOrder = sessionStorage.getItem("order");

		var gratuity_price = 0;
		placeOrderRest(idUser, idPlace, gratuity_price, fullOrder,
				notes, function(response) {

					var order = response.object;
					if (order != null && order != undefined) {

						window.sessionStorage
								.setItem("placedOrderId", order.id);
						window.location.href = "orderConfirmation.html";
						myCart = [];
						window.sessionStorage.removeItem("myCart");

					} else {

						alert('error');

					}
					overlay_off();
				});
	}

}

/*
 * 
 * 
 * 
 */
function show_defaultCard() {
	overlay_on();
	getUserDefaultCardHiddenNumber(function(defaultNumber) {

		defaultCardNumber = defaultNumber;
		document.getElementById("card_num").innerHTML = defaultNumber;
		if (defaultCardNumber == 0 || defaultCardNumber == null) {
			document.getElementById("changeb").textContent = "Añadir";
			document.getElementById("button_checkout_end").disabled = true;
			document.getElementById("button_checkout_end").value = "";
		} else {
			document.getElementById("button_checkout_end").disabled = false;
			document.getElementById("button_checkout_end").value = "Finalizar pedido";
			document.getElementById("changeb").textContent = "Cambiar";
		}
		document.getElementById("changeb").onclick = function(e) {
			add_change_card();
		}
		overlay_off();
	});

}

function add_change_card() {
	window.sessionStorage.setItem("originPage", "checkout");
	window.location = "userData.html";
}