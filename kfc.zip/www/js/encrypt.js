//var key = "4ad3815e3936712191397cc337496f31";
//var iv  = "5be4926f40478232"; 

var key = "";
var iv = "";

var initParams = { iv: iv,  mode: CryptoJS.mode.CBC, padding: CryptoJS.pad.Pkcs7};

function encrypt(textForEncrypting, idPlace, callback) {
	initPlaceConfig(idPlace, function () {
		var encrypted = encryptText(textForEncrypting); 
		var encryptedText = ''+encrypted;
		callback(encryptedText);
	});

}

function decrypt(textForDecrypting, idPlace, callback) {
	initPlaceConfig(idPlace, function () {
		var decryptedText = decryptText(textForDecrypting); 
		callback(decryptedText);
	});
}

/**
 * It is necessary to call this method at the start of the encryption/decryption proccess
 */
function initPlaceConfig (idPlace, callback) {
	
	if(key=="" || iv =="" || initParams==null ) {
		getPlaceConfig(idPlace, function(placeConfig) {
			
			key = placeConfig.encryptKey;
			key = CryptoJS.enc.Utf8.parse(key);
			iv = placeConfig.iv;
			iv = CryptoJS.enc.Utf8.parse(iv);
			initParams = { iv: iv,  mode: CryptoJS.mode.CBC, padding: CryptoJS.pad.Pkcs7};
			callback();
		});	
	} else {
		callback();
	}
	
}

/**
 * this method does not return a String, for getting the cipherDataString just
 * do : ''+cipherData
 * @param text
 * @returns cipherData (NOT STRING)
 */
function encryptText(text) {
	var cipherData = CryptoJS.AES.encrypt(text, key, initParams);
	return cipherData;
}

/**
 * Method that return a string representation of a decrypted object
 * @param encryptedData
 * @returns String decryptedText
 */
function decryptText(encryptedData){
	
	var data = CryptoJS.AES.decrypt(encryptedData, key, initParams);
	var decryptedText = data.toString(CryptoJS.enc.Utf8);
	return decryptedText;
}
