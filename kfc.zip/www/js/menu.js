
/*********************** FUNCTIONS ****************************/
app_push_menu.initialize();
var idUser = window.sessionStorage.getItem("idUser");
var username = window.sessionStorage.getItem("username");

app_push_menu.initialize();

$(document).ready(function() {

    //document.getElementById("link0").innerHTML = username;
    completeInfoSideNav();
    var token = window.sessionStorage.getItem("pushToken");
    //we save teh origin for coming back
    if(sessionStorage.getItem("originPage") !=null) {
        window.sessionStorage.removeItem("originPage");
    }
    window.sessionStorage.setItem("originPage", "menu.html");

    sendToken(idUser, token);

    //backbutton management: set app to background run
    document.addEventListener("backbutton", function(e) {
        e.preventDefault();
        navigator.Backbutton.goHome(function() {
            console.log('success')
        }, function() {
            console.log('fail')
        });
    }, false);
    
});
   
function sendToken(idUser, token) {
    token = ""+token;
    getSetUserDevicePushTokenResponse(idUser, token, function(response){});
}

function goToWeniteWeb(){
    window.location="https://jaorue.wixsite.com/weniteapp";
}

function goToBouchers() {
    window.location="http://www.kfc.es/ofertas/";
}

function goToSlider() {
    window.location="products.html";
}