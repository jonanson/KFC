/** ********************* VARIABLES *************************** */

var username_value;
var password_value;
var sessionKey;
var user_id;
var myAlertURL;
var url_menu = "../www/menu.html";

$(document).ready(function() {
	app.initialize();
	if(sessionStorage.getItem('username') != undefined && sessionStorage.getItem('username') != null) {
		window.location = 'menu.html';
	}
	// backbutton management:closeApp();
	document.addEventListener("backbutton", function(e) {
		e.preventDefault();
		navigator.app.exitApp();
	}, false);
});

/** ********************* FUNCTIONS *************************** */

/**
 * 
 * This function sends the parameters to the server and deals with the response,
 * letting the user log in or not.
 * 
 * @username - The value of the username field.
 * 
 * @pass - The value of the password field.
 * 
 * @idPlace - The id of the place to log in.
 * 
 */
function login(username, pass, idPlace) {
	overlay_on();
	encrypt(pass, idPlace, function(encryptedPassword) {
		loginRest(username, encryptedPassword, idPlace, function(response) {
			//response.object-->userSession
			if (response.type == 0) {
				alert(response.message);
			} else {
				sessionKey = response.object.sessionKey;
				user_id = response.object.idUser;
				setUservars();
				window.location = 'menu.html';
			}
			overlay_off();
		});

	});
}

/**
 * 
 * This function gets the values of the username and password and calls the
 * login function.
 * 
 */
function loginAction() {

	username_value = document.getElementById("usernameField").value;

	password_value = document.getElementById("passwordField").value;
	
	if(username_value == undefined || username_value == null || username_value == "") {
	} else {
		login(username_value, password_value, 0);
	}
}

/*
 * 
 * 
 * 
 */
function setUservars() {

	window.sessionStorage.setItem("username", username_value);
	window.sessionStorage.setItem("idUser", user_id);
	window.sessionStorage.setItem("sessionKey", sessionKey);

}
