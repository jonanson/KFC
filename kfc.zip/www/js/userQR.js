
/*********************** VARIABLES ****************************/

var idUser = sessionStorage.getItem("idUser");

$(document).ready(function() {
   document.getElementById("idUserCode").textContent=''+idUser;

});
