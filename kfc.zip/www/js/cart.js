/** ********************* VARIABLES *************************** */

// var myCart_name = [];
// var myCart_id = [];
var myCart = [];

// var empty = false;
var currentRow = 0;

var totalPrice = 0;
var originPage = "products.html";
var notes = "";
/** ********************* FUNCTIONS *************************** */

/*
 * parsear string a array son , o . o - o / Hacer un array por fila o por
 * elemento del pedido usando assray+num mostrar solo info relevante de cada
 * elemento del pedido (mirar si es tipo y marca o cual) implementar dropdown
 * para info entera sobre el pedido. cantidad siempre el primero del array, asi
 * siempre cambiar arra+num[0] independientemente de numero de pasos si se
 * elimina, se elimina el array completo ***Para esto podría estar bien una
 * funcion que renombra filas y ordena array cuando uno se elimina, asi todo
 * sigue funcionando bien y los id no son un lio. si se edita, cargar el array
 * como temp en sessionstorage para que lo lea drinktype. eliminar del array
 * para que aparezca en null y detectarlo posteriormente. (al salir de drinktype
 * si null-> cambiar por lo editado). siempre al pasar a checkout, parsear cada
 * array en el string como pide y proceder. Mantener los arrays en
 * sessionstorage hasta la finalizacion de pedido por si al usuario le da por
 * volver atrás. IMPLEMENTAR PRECIO DE CADA ELEMENTO DEL PEDIDO EN LA FILA
 */
app_push_cart.initialize();

$(document).ready(
		function() {

			if (sessionStorage.getItem("notes") != null) {
				notes = sessionStorage.getItem("notes");
				document.getElementById("notes").value = notes;
			}
			if (JSON.parse(sessionStorage.getItem("temp_item")) != null) {

				window.sessionStorage.removeItem("temp_item");

			}

			if (window.sessionStorage.getItem("originPage") != null) {
				originPage = window.sessionStorage.getItem("originPage");
			}
			myCart = JSON.parse(sessionStorage.getItem("myCart"));

			if (myCart != null && myCart.length != 0) {

				lf_rows();
				change_totalPrice();
				// document.getElementById("button_clear").disabled=false;
				document.getElementById("checkB").value = "Realizar pedido "
						+ "(" + totalPrice + " €)";
				document.getElementById("checkB").disabled = false;
			} else {
//				document.getElementById("button_clear").disabled = true;

				create_emptyRow();

			}
			// backbutton management: set app to main menu
			document.addEventListener("backbutton", function(e) {
				e.preventDefault();
				window.location.href = 'products.html';

			}, false);
		});

/*
 * 
 * 
 * 
 */
function create_infoRowContent(rowNumber) {

	var names = getProductDescription(myCart[rowNumber]);

	var quantity = myCart[rowNumber];
	quantity = quantity[0];

	var price = myCart[rowNumber];
	price = parseFloat(price[3]) * parseFloat(quantity);

	var sel_info_area = document.createElement("div");
	var sel_info_text_col = document.createElement("div");
	var sel_info_quantity_col = document.createElement("div");
	var sel_info_opt_col = document.createElement("div");

	sel_info_area.setAttribute("id", "sel_info_area" + rowNumber);
	sel_info_area.className = "sel_info_area";

	sel_info_quantity_col.setAttribute("id", "sel_info_quantity" + rowNumber);
	sel_info_quantity_col.className = "sel_info_quantity_col";
	sel_info_quantity_col.innerHTML = quantity;

	sel_info_text_col.setAttribute("id", "sel_info_text" + rowNumber);
	sel_info_text_col.className = "sel_info_text_col";
	sel_info_text_col.innerHTML = names + " (" + price + " €)";

	sel_info_opt_col.setAttribute("id", "sel_info_opt_col" + rowNumber);
	sel_info_opt_col.className = "sel_info_opt_col";

	sel_info_area.appendChild(sel_info_quantity_col);
	sel_info_area.appendChild(sel_info_text_col);

	document.getElementById("infoRow" + rowNumber).appendChild(sel_info_area);
	document.getElementById("infoRow" + rowNumber)
			.appendChild(sel_info_opt_col);

	width = (window.innerWidth > 0) ? window.innerWidth : screen.width;

	/*
	 * var lockedH = (width*12)/100;
	 * document.getElementById("infoRow"+rowNumber).style.height = lockedH +
	 * 'px' ;
	 */

}

/*
 * 
 * 
 * 
 */
function create_infoRow(rowNumber) {

	var rowContent = document.createElement("div");
	rowContent.setAttribute("id", "infoRow" + rowNumber);
	rowContent.className = "infoRow";

	document.getElementById("drink_forms").appendChild(rowContent);

	create_infoRowContent(rowNumber);
	create_optAreas(rowNumber);
	populate_optAreas(rowNumber);
	action_animateOpts(rowNumber);

}

/*
 * 
 * 
 * 
 */
function lf_rows() {

	for (var i = 0; i < myCart.length; i++) {
		if (myCart[i] != null) {
			create_infoRow(i);
		}
	}

}

/*
 * 
 * 
 * 
 */
function create_emptyRow() {

	var rowContent = document.createElement("div");
	rowContent.setAttribute("id", "infoRow0");
	rowContent.className = "row infoRow";

	document.getElementById("drink_forms").appendChild(rowContent);

	var empty1 = document.createElement("div");
	var sel_info_text_col = document.createElement("div");
	var empty2 = document.createElement("div");

	empty1.setAttribute("id", "sel_info_area");
	empty1.className = "empty_col";

	sel_info_text_col.setAttribute("id", "sel_info_text");
	sel_info_text_col.className = "sel_info_text_col";
	sel_info_text_col.innerHTML = "El carro est&aacute; vac&iacute;o!";

	empty2.setAttribute("id", "sel_info_opt_col");
	empty2.className = "empty_col";

	//document.getElementById("infoRow0").appendChild(empty1);
	//document.getElementById("infoRow0").appendChild(sel_info_text_col);

	document.getElementById("infoRow0").appendChild(empty2);

	width = (window.innerWidth > 0) ? window.innerWidth : screen.width;

	var lockedH = (width * 12) / 100;
	document.getElementById("infoRow0").style.height = lockedH + 'px';

}

/*
 * 
 * 
 * 
 */
function create_optAreas(rowNumber) {

	var h_toggle = document.createElement("div");
	var h_optDelete = document.createElement("div");
	// var h_optEdit = document.createElement("div");
	var h_optPlus = document.createElement("div");
	var h_optMinus = document.createElement("div");

	h_toggle.className = "h_toggle";
	h_toggle.setAttribute("id", "h_toggle" + rowNumber);

	// h_optEdit.className = "col-xs-2 col-sm-2 h_optEdit";
	// h_optEdit.setAttribute("id", "h_optEdit"+rowNumber);

	h_optDelete.className = "h_optDelete";
	h_optDelete.setAttribute("id", "h_optDelete" + rowNumber);

	h_optPlus.className = "h_optPlus";
	h_optPlus.setAttribute("id", "h_optPlus" + rowNumber);

	h_optMinus.className = "h_optMinus";
	h_optMinus.setAttribute("id", "h_optMinus" + rowNumber);

	document.getElementById("sel_info_opt_col" + rowNumber).appendChild(
			h_optDelete);
	// document.getElementById("sel_info_opt_col"+rowNumber).appendChild(h_optEdit);
	document.getElementById("sel_info_opt_col" + rowNumber).appendChild(
			h_optPlus);
	document.getElementById("sel_info_opt_col" + rowNumber).appendChild(
			h_optMinus);
	document.getElementById("sel_info_opt_col" + rowNumber).appendChild(
			h_toggle);

}

/*
 * 
 * 
 * 
 */
function action_lockCarousselRow(cellId, rowNumber) {

	document.getElementById("row_content" + rowNumber).innerHTML = '';

	create_lockedRow(rowNumber, cellId);

	create_optAreas(rowNumber);

	populate_optAreas(rowNumber);

	action_animateOpts(rowNumber);

	window.removeEventListener("resize", action_slideResize);

}

/*
 * 
 * 
 * 
 */
function populate_optAreas(rowNumber) {

	var opt_main = document.createElement("input");
	var opt_aux1 = document.createElement("input");
	var opt_aux2 = document.createElement("input");
	var opt_aux3 = document.createElement("input");
	var opt_aux4 = document.createElement("input");

	opt_main.setAttribute("id", "opt_main" + rowNumber);
	opt_main.className = "opt_main";
	opt_main.setAttribute("type", "image");
	opt_main.setAttribute("src", "./img/opt_dots_light_negro_h.png");

	// opt_aux1.setAttribute("id", "opt_aux1"+rowNumber);
	// opt_aux1.className = "opt_aux1";
	// opt_aux1.setAttribute("type", "image");
	// opt_aux1.setAttribute ("src", "./img/editIcon.png");

	opt_aux3.setAttribute("id", "opt_aux3" + rowNumber);
	opt_aux3.className = "opt_aux3";
	opt_aux3.setAttribute("type", "image");
	opt_aux3.setAttribute("src", "./img/minusIcon.png");

	opt_aux4.setAttribute("id", "opt_aux4" + rowNumber);
	opt_aux4.className = "opt_aux4";
	opt_aux4.setAttribute("type", "image");
	// opt_aux4.setAttribute("style", "margin-top:19%");

	opt_aux4.setAttribute("src", "./img/plusIcon.png");

	opt_aux2.setAttribute("id", "opt_aux2" + rowNumber);
	opt_aux2.className = "opt_aux2";
	opt_aux2.setAttribute("type", "image");
	opt_aux2.setAttribute("src", "./img/cancelIcon.png");

	document.getElementById("h_toggle" + rowNumber).appendChild(opt_main);
	document.getElementById("h_optDelete" + rowNumber).appendChild(opt_aux2);
	// document.getElementById("h_optEdit"+rowNumber).appendChild(opt_aux1);
	document.getElementById("h_optPlus" + rowNumber).appendChild(opt_aux4);
	document.getElementById("h_optMinus" + rowNumber).appendChild(opt_aux3);

}

/*
 * 
 * 
 * 
 */
function action_animateOpts(rowNumber) {

	document.getElementById("opt_main" + rowNumber).onclick = function() {

		// $('#h_optEdit'+rowNumber).animate({width: 'toggle'});
		$('#h_optDelete' + rowNumber).animate({
			width : 'toggle'
		});
		$('#h_optPlus' + rowNumber).animate({
			width : 'toggle'
		});
		$('#h_optMinus' + rowNumber).animate({
			width : 'toggle'
		});
	}

	// document.getElementById("opt_aux1"+rowNumber).onclick = function(){
	//
	// //edit
	// ///trat de vars
	// editItem(rowNumber);
	//    
	// }

	document.getElementById("opt_aux2" + rowNumber).onclick = function() {

		// delete
		rearrange_Rows();
		myCart.splice(rowNumber, 1);
		delete_Row(rowNumber);
		window.sessionStorage.setItem("myCart", JSON.stringify(myCart));

		if (myCart == null) {
			create_emptyRow();
		}

		// rearrange_Rows();
		change_totalPrice();

	}

	document.getElementById("opt_aux3" + rowNumber).onclick = function() {

		// minus quantity
		var element = myCart[rowNumber];
		var quantity = element[0];

		if (quantity > 1) {

			quantity--;
			element[0] = quantity;
			myCart[rowNumber] = element;
			window.sessionStorage.setItem("myCart", JSON.stringify(myCart));

			var quantity = myCart[rowNumber];
			quantity = quantity[0];
			document.getElementById("sel_info_quantity" + rowNumber).innerHTML = quantity;

			var names = getProductDescription(myCart[rowNumber]);

			var price = myCart[rowNumber];
			price = round(price[3],quantity);
			document.getElementById("sel_info_text" + rowNumber).innerHTML = names
					+ " (" + price + " €)";

			change_totalPrice();

		}

	}

	document.getElementById("opt_aux4" + rowNumber).onclick = function() {

		// plus quantity
		var element = myCart[rowNumber];
		var quantity = element[0];
		quantity++;
		element[0] = quantity;
		myCart[rowNumber] = element;
		window.sessionStorage.setItem("myCart", JSON.stringify(myCart));

		var quantity = myCart[rowNumber];
		quantity = quantity[0];
		document.getElementById("sel_info_quantity" + rowNumber).innerHTML = quantity;

		var names = getProductDescription(myCart[rowNumber]);

		var price = myCart[rowNumber];
		price = round(price[3],quantity);
		document.getElementById("sel_info_text" + rowNumber).innerHTML = names
				+ " (" +price+ " €)";

		change_totalPrice();

	}
}
function round(a,b) {
    return Math.round((a * b) * 100)/100;
};
/*
 * 
 * 
 * 
 */
function package_order() {

	var fullOrder = "";
	var item = [];
	notes = document.getElementById("notes").value.trim();
	for (i = 0; i < myCart.length; i++) {

		item = myCart[i];
		fullOrder = fullOrder + item[0] + "," + item[1] + "-";

	}

	sessionStorage.setItem("order", fullOrder);
	sessionStorage.setItem("subtotal", totalPrice);
	sessionStorage.setItem("notes", notes);

	window.location.href = "checkout.html"

}

/*
 * 
 * 
 * 
 */
function addMore() {

	window.location.href = "drinkType.html";

}

/*
 * 
 * 
 * 
 */
function editItem(id) {

	window.sessionStorage.setItem("temp_item", JSON.stringify(myCart[id]));
	myCart.splice(id, 1);
	window.sessionStorage.setItem("myCart", JSON.stringify(myCart));

	window.location.href = "drinkType.html";

}

/*
 * 
 * 
 */
function delete_Row(rowNumber) {

	var kids = document.getElementById("drink_forms").children;

	for (var i = 0; i < kids.length; i++) {

		if (kids[i].getAttribute("id") == ("infoRow" + rowNumber)) {

			document.getElementById("drink_forms").removeChild(kids[i]);
			break;

		}

	}

}

/*
 * 
 * 
 */
function rearrange_Rows() {

	window.location = "cart.html";
}

function change_totalPrice() {

	var allQ = [];
	var allP = [];
	totalPrice = 0;

	for (var i = 0; i < myCart.length; i++) {

		var price = parseFloat(myCart[i][3]);
		var quantity = myCart[i][0];

		allQ.push(round(price , quantity));

	}

	for (var n = 0; n < allQ.length; n++) {

		// totalPrice = totalPrice + (allP[n] * allQ[n]);
		// se comenta la anterior para kitar lo de gratuity
		totalPrice = totalPrice + (allQ[n]);

	}

	if (totalPrice < 0.1) {
		document.getElementById("checkB").value = "Añada bebidas a su pedido";
		document.getElementById("checkB").disabled = true;
	} else {
		document.getElementById("checkB").value = "Realizar pedido " + "("
				+ totalPrice + " €)";
		document.getElementById("checkB").disabled = false;

	}

}

function getProductDescription(cartLine) {

	names = cartLine[2];

	var drinkDescription = "";
	for (var a = 1; a < names.length; a++) {

		if (names[a] != null) {
			if (drinkDescription == "") {
				drinkDescription = names[a];
			} else {
				drinkDescription = drinkDescription + "<br/>" + names[a];
			}
			if (a == names.length - 1) {
				drinkDescription = drinkDescription + "<br/>"
			}
		}
	}

	return drinkDescription;
}

function clearForm() {
	var kids = document.getElementById("drink_forms").children;

	for (var i = 0; i < kids.length; i++) {

		document.getElementById("drink_forms").removeChild(kids[i]);
		break;

	}

	myCart = [];
	window.sessionStorage.removeItem("myCart");
	window.location = "cart.html";

}

function goToPlaceOrder() {
	package_order();
}
