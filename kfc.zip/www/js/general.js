var opened = false;
/** ********************* VARIABLES *************************** */

/** ********************* FUNCTIONS *************************** */

/**
 * 
 * This function will create an alert displaying a message.
 * 
 * @msgText - The String variable you want the alert to show in its text.
 * @alertColor - The color you want the alert to be. We will use 4 types: -
 *             Green: Successful alerts. - Red: Error alerts. - Yellow: Warning
 *             alerts. - Blue: Informative alerts.
 * @fading - This variable is a String that we set beforehand. It's used in the
 *         styling of the alert to determine the behaviour: - fade: The alert
 *         will fade afer a time, you can also close it hitting the "x". -
 *         nofade: The alert won't fade and you have to click the "x" to make it
 *         disappear.
 * @url - The page you will be redirected to after pressing the "x".
 * 
 */

function createSNAlert(msgText, alertColor, fading, url) {

	var alert = document.createElement("div"); /*
												 * Creation of the alert
												 */

	alert.className = "alert" + fading;
	alert.innerHTML = msgText;
	alert.style.backgroundColor = alertColor;

	var span = document.createElement("span"); /*
												 * Creation of the "x" and
												 * adding it to the alert
												 */
	span.className = "closebtn";

	if (alertColor == "green") {

		span.onclick = function() {

			this.parentElement.style.display = 'none';
			if (url != "none") {
				window.location = 'mainMenu.html';
			}
		};

	} else {

		span.onclick = function() {
			this.parentElement.style.display = 'none';
		};

	}

	span.innerHTML = "&times;";
	alert.appendChild(span);

	document.getElementById("content").appendChild(alert); /*
															 * Add the alert to
															 * the document
															 */

}

function completeInfoSideNav() {

	var userName = sessionStorage.getItem("username");
	$("#userNameText").text(userName);
}

function processNotification(data) {
	var title = ('' + data.title).trim();
	var msg = ('' + data.message).trim();
	if (title === 'Pedido recibido') {
		customAlert(title, msg)
	} else if (title === 'Pedido en marcha') {
		customAlert(title, msg)
	} else if (title === 'Hecho!') {

		var text = data.message;
		text = text + "\n" + "Quiere preparar el código para recogerlo?"
		customConfirmAlert(title, msg);
	}
}

function setCartImage(isFull) {
	var imageSrc = "";

	if (isFull == true) {
		imageSrc = "./img/full_basket_icon.png";
	} else {
		imageSrc = "./img/icon_basket_limegreen.png";
	}

	document.getElementById("button_cart").src = imageSrc;
}

/**
 * 
 * This function sends the logout message to the server using the user session
 * and deals with the response.
 * 
 * *If the response from the server is affirmative, the user will log out
 * correctly and be redirected to the login page.
 * 
 * *In case of a negative response from the server there will be an error
 * handling function to deal with this.
 * 
 */
function logOut() {

	var session = window.sessionStorage.getItem("sessionKey");

	getLogoutRest(session, function(response) {
		window.sessionStorage.clear();
		window.location = 'login.html';
	});
}

function overlay_on() {
	document.getElementById("overlay").style.display = "block";
}

function overlay_off() {
	document.getElementById("overlay").style.display = "none";
}

/*
 * This function changes the sidebar's width for it to open to the user.
 * 
 */
function openNav() {
	opened = true;
	document.getElementById("mySidenav").style.width = "70%";
	document.getElementById("mySidenav").style.border = "solid 2px ghostwhite";
}

/*
 * This function changes the sidebar's width for it to close to the user.
 * 
 */
function closeNav() {
	opened = false;
	document.getElementById("mySidenav").style.width = "0";
	document.getElementById("mySidenav").style.border = "none";
}

function customAlert(title, msg) {
	var btn = $(this), theme = "red";
	$.jAlert({
		'title' : title,
		'content' : msg,
		'theme' : theme,
		'closeOnClick' : true,
		'backgroundColor' : 'white',
	});
}

function customConfirmAlert(title, msg) {
	var btn = $(this), theme = "red";
	var alert = $.jAlert({
		'title' : title,
		'content' : msg,
		'theme' : theme,
		'closeOnClick' : true,
		'backgroundColor' : 'white',
		'btns' : [ {
			'text' : 'OK',
			'theme' : theme,
		} ]
	});
}
function goToQr() {
	window.location.href ='menu.html';
}
function openOrCloseNav() {
	if (opened == true) {
		closeNav();
	} else {
		openNav();
	}
}

Element.prototype.remove = function() {
	this.parentElement.removeChild(this);
}
NodeList.prototype.remove = HTMLCollection.prototype.remove = function() {
	for (var i = this.length - 1; i >= 0; i--) {
		if (this[i] && this[i].parentElement) {
			this[i].parentElement.removeChild(this[i]);
		}
	}
}
